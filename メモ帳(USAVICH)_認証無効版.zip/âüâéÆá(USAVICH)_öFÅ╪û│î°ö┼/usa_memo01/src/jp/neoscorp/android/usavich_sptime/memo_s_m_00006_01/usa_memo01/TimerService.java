package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;



import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

public class TimerService extends Service {
	public TimerReceiver mTimerReceiver;
	public static String TIMER_UPDATE_ACTION = "jp.neoscorp.android.action.usa.TIMER_UPDATE_ACTION";
	public static String TIMER_START_ACTION = "jp.neoscorp.android.action.usa.TIMER_START_ACTION";
	public static String TIMER_STOP_ACTION = "jp.neoscorp.android.action.usa.TIMER_STOP_ACTION";
	private MemoApplication memoApp;
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	public void onCreate() 
	{
		super.onCreate();
		memoApp = (MemoApplication)this.getApplication();
		mTimerReceiver = new TimerReceiver(this,memoApp);
		mTimerReceiver.register();
	}
	public void onStart(Intent intent, int startId) 
	{
		super.onStart(intent, startId);
	}
	
	public void onDestroy() 
	{
		super.onDestroy();
		mTimerReceiver.unRegister();
	}
	
	
	
	
}
