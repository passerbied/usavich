package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.timer;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.R;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class TimerAlert extends Activity 
{
	public static String TIMER_STOP_ACTION = "com.taiyo.clock.action.TIMER_STOP_ACTION";
	private MediaPlayer mMediaPlayer;
	private TextView mTimerTitle;
	private Button mTimerCancelBtn;
	private Vibrator mVibrator;
	private Typeface tf0, tf;
	private TelephonyManager mTelephonyManager;
	private ImageView alertImageView;
	private AlarmReceiver mAlarmReceiver;
	
    //アニメ
    private Thread AnimationThread;
    private boolean AnimationStatus = false;
    private AnimationPlayHandler mAnimationPlay;
    private int popupPos = 0;
    
    //アニメ　popup
    private int popup_timecount = 0;
    private int[] popup = new int[]
		{
			R.drawable.popup_anime01,
			R.drawable.popup_anime02,
			R.drawable.popup_anime03,
			R.drawable.popup_anime04			
		};
    private int[] popup_time = new int[]{ 100, 100, 100, 100 };

	 private class AnimationPlayHandler extends Handler 
	 {
	        public void handleMessage(Message msg) 
	        {
	            super.handleMessage(msg);
	            alertImageView.setImageResource(popup[popupPos - 1]);  
	    	}	
	 }
	    
   private void AnimationStart()
   {
   	 mAnimationPlay = new AnimationPlayHandler();
   	 AnimationStatus = true;
   	 AnimationThread = new Thread(new Runnable()
   	 {
          public void run () {
          	while(AnimationStatus)
          	{
          		if(popup_timecount == 0)
       			{
	           		if(popupPos == popup.length)
	           			popupPos = 0;
	           		popupPos++ ;
	               	mAnimationPlay.sendMessage(mAnimationPlay.obtainMessage());
	               	popup_timecount = popup_time[popupPos - 1];
       			}
          		popup_timecount = popup_timecount - 100;
       			
          		try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}	
          	}
          }
      });
	   AnimationThread.start();
   }
   
   private void AnimationStop()
   {
	   	AnimationStatus = false;
	   	AnimationThread.interrupt();
	   	AnimationThread = null;
	   	mAnimationPlay = null;    	
   }
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);  
		getWindow().setBackgroundDrawableResource(R.color.alertbgcolor);
		setContentView(R.layout.timeralertpopview);
        
		mAlarmReceiver = new AlarmReceiver();
		mAlarmReceiver.register();
		
		tf0 = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/clock_SHOWG.ttf");
		tf = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/clock_A-OTF-ShinMGoPro-Light.otf");
			
        mTelephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        mTelephonyManager.listen(mPhoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
		
        AnimationStart();
		
		if(!Utils.TIMER_SOUNDPATH.equals(""))
		{
			AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);  
			am.adjustStreamVolume (AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_PLAY_SOUND); 
			
	        Uri sound = Utils.getRingtoneByUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE, Utils.TIMER_SOUNDPATH);
			mMediaPlayer = MediaPlayer.create(getApplicationContext(), sound);            
			mMediaPlayer.setLooping(true);
			mMediaPlayer.start();
		}
		
		if(Utils.TIMER_VIBRATE.equals("ON"))
		{
			mVibrator = (Vibrator) getApplication().getSystemService(Service.VIBRATOR_SERVICE);  
	        mVibrator.vibrate(new long[]{100,10,100,1000}, 0);  
		}
        
        mTimerTitle = (TextView)findViewById(R.id.timerTitle);
        mTimerCancelBtn = (Button)findViewById(R.id.timercancelBtn);
        alertImageView  = (ImageView)findViewById(R.id.alertImageView);
        mTimerCancelBtn.setTypeface(tf);
        mTimerTitle.setTypeface(tf0);
        
        mTimerCancelBtn.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				sendBroadcast(new Intent(TIMER_STOP_ACTION));
				stopTimer();
				TimerAlert.this.finish();
			}
		});
    }
	
	protected void onStop()
	{
		super.onStop();
		stopTimer();
		TimerAlert.this.finish();
	}
	
	protected void onDestroy() 
	{  
        super.onDestroy();  
        mAlarmReceiver.unRegister();
        AnimationStop();
		alertImageView.setImageDrawable(null);
	} 
	
	private void stopTimer()
	{
		if(!Utils.TIMER_SOUNDPATH.equals("")){ mMediaPlayer.stop();}
		if(Utils.TIMER_VIBRATE.equals("ON")){ mVibrator.cancel(); }
		
		Utils.initTimerData();
	}
	
	private class AlarmReceiver extends BroadcastReceiver
	{
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction("android.intent.action.SCREEN_OFF");
    		filter.addAction("android.intent.action.SCREEN_ON");
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			if (intent.getAction().equals("android.intent.action.SCREEN_OFF") || intent.getAction().equals("android.intent.action.SCREEN_ON")) 
			{
				stopTimer();
			}			
		}
	}
	 
	 private PhoneStateListener mPhoneStateListener = new PhoneStateListener() 
	 {
        public void onCallStateChanged(int state, String ignored) {
            if (state == TelephonyManager.CALL_STATE_RINGING) 
            {
            	stopTimer();
            }
        }
	 };
	 
}
