package jp.primeworks.android.flamingo.util;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import android.content.Context;
import android.telephony.TelephonyManager;


/**
 * Flamingo Util
 *
 * <p>
 * Flamingo Utilクラス
 *
 */
public class FlamingoUtil {

	/**
	 * 自クラスのインスタンス
	 */
	private static FlamingoUtil mFlamingoUtil = null;


	/**
	 * コンストラクタ（プライベート）
	 *
	 * 本クラスの単純生成は禁止する.<BR>
	 * getInstance()メソッドでシングルトンなインスタンスを取得すること.
	 */
	private FlamingoUtil() {

		// do nothing
	}


	/**
	 * 本クラスのインスタンスを生成して取得する.
	 *
	 * @return 自クラスのインスタンス
	 */
	public static synchronized FlamingoUtil getIncetance() {

		if (mFlamingoUtil == null) {
			mFlamingoUtil = new FlamingoUtil();
		}
		return mFlamingoUtil;
	}


	/**
	 * UUIDを生成して取得する.
	 *
	 * @return UUID
	 */
	public String createUuid() {

		return UUID.randomUUID().toString();
	}


	/**
	 * IMEIを取得する.<BR>
	 * IMEI(International Mobile Equipment Identity):GSM/W-CDMA/iDEN,一部の衛星電話の識別番号
	 *
	 * @param context
	 *            コンテキスト
	 * @return IMEI
	 */
	public String getImei(Context context) {

		TelephonyManager telephonyMgr = (TelephonyManager) (context.getSystemService(Context.TELEPHONY_SERVICE));
		return telephonyMgr.getDeviceId();
	}


	/**
	 * IMSIを取得する.<BR>
	 * IMSI(International Mobile Subscriber Identity):GSMおよびW-CDMAの端末識別番号
	 *
	 * @param context
	 *            コンテキスト
	 * @return IMSI
	 */
	public String getImsi(Context context) {

		TelephonyManager telephonyMgr = (TelephonyManager) (context.getSystemService(Context.TELEPHONY_SERVICE));
		return telephonyMgr.getSubscriberId();
	}


	/**
	 * アプリケーションのパッケージ名を取得する.
	 *
	 * @param context
	 *            コンテキスト
	 * @return パッケージ名
	 */
	public String getUserPackageName(Context context) {

		Logging.d("context.getPackageName=" + context.getPackageName());
		return context.getPackageName();
	}


	/**
	 * 有効期間確認API
	 *
	 * <p>
	 * 現在の日付に対して入力された日付が有効かチェックする.
	 *
	 * @param validDate
	 *            有効期間(期限日、または期限日時)
	 * @param days
	 *            猶予期間（単純な有効期間のチェックを行う場合はnull）
	 * @return 有効：true/無効：false
	 */
	public boolean checkValidDate(String validDate, String days) {

		Logging.d("checkValidDate is called. validDate=" + validDate + ", days=" + days);
		boolean valid = false;
		final String format1 = "yyyyMMdd";
		final String format2 = "yyyyMMdd'T'HHmmss";
		SimpleDateFormat simpleDateFormat;
		Date limitDateTime;
		SimpleDateFormat logSdf;

		try {

			// フォーマットの選択
			if (validDate.length() <= format1.length()) {

				// 短いフォーマットで取り扱う.

				Logging.d("input date is format (yyyyMMdd).");
				simpleDateFormat = new SimpleDateFormat(format1);

				// 実行日の23時59分59秒に設定する.
				limitDateTime = simpleDateFormat.parse(validDate);
				limitDateTime.setHours(23);
				limitDateTime.setMinutes(59);
				limitDateTime.setSeconds(59);

				logSdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Logging.d("limitDateTime [yyyy/MM/dd HH:mm:ss] : " + logSdf.format(limitDateTime));

			} else {

				// 長いフォーマットで取り扱う.

				Logging.d("input date is format (yyyyMMdd'T'HHmmss).");
				simpleDateFormat = new SimpleDateFormat(format2);
				limitDateTime = simpleDateFormat.parse(validDate);

				logSdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Logging.d("limitDateTime [yyyy/MM/dd HH:mm:ss] : " + logSdf.format(limitDateTime));
			}

			if (days != null) {
				Logging.d("graceDays exist");
				// 猶予期間がnullでなければ有効期間に加算する.
				long add = Long.valueOf(days) * 24 * 60 * 60 * 1000;
				limitDateTime.setTime(limitDateTime.getTime() + add);
			}

			// 現在日時を取得する.
			Date nowDateTime = Calendar.getInstance().getTime();

			logSdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Logging.d("nowDateTime [yyyy/MM/dd HH:mm:ss] : " + logSdf.format(nowDateTime));

			if (nowDateTime.compareTo(limitDateTime) < 0) {

				// 現在日時が有効期間と猶予期間を加算した終端の日時に達していない場合、「有効」.

				Logging.d("date is valid.");
				valid = true;
			}

		} catch (ParseException e) {

			// 比較手順の最中でエラーの場合、無効とする.
			Logging.d("ParseException " + e);
			valid = false;

		} catch (RuntimeException e) {

			// 比較手順の最中でエラーの場合、無効とする.
			Logging.d("RuntimeException " + e);
			valid = false;

		}
		Logging.d("checkValidDate returns " + valid + ".");
		return valid;
	}


	/**
	 * 有効期間確認API
	 *
	 * <p>
	 * 現在の日付に対して入力された日付が有効かチェックする.
	 *
	 * @param validDate
	 *            有効期間(期限日、または期限日時)
	 * @return 有効期間 年月日時分秒
	 */
	public Date getValidDate(String validDate) {

		Logging.d("getValidDate is called. validDate=" + validDate);
		final String format1 = "yyyyMMdd";
		final String format2 = "yyyyMMdd'T'HHmmss";
		SimpleDateFormat simpleDateFormat;
		Date limitDateTime = null;
		SimpleDateFormat logSdf;

		try {

			// フォーマットの選択
			if (validDate.length() <= format1.length()) {

				// 短いフォーマットで取り扱う.

				Logging.d("input date is format (yyyyMMdd).");
				simpleDateFormat = new SimpleDateFormat(format1);

				// 実行日の23時59分59秒に設定する.
				limitDateTime = simpleDateFormat.parse(validDate);
				limitDateTime.setHours(23);
				limitDateTime.setMinutes(59);
				limitDateTime.setSeconds(59);

				logSdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Logging.d("limitDateTime [yyyy/MM/dd HH:mm:ss] : " + logSdf.format(limitDateTime));

			} else {

				// 長いフォーマットで取り扱う.

				Logging.d("input date is format (yyyyMMdd'T'HHmmss).");
				simpleDateFormat = new SimpleDateFormat(format2);
				limitDateTime = simpleDateFormat.parse(validDate);

				logSdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				Logging.d("limitDateTime [yyyy/MM/dd HH:mm:ss] : " + logSdf.format(limitDateTime));
			}

		} catch (ParseException e) {

			// エラーの場合、無効とする.
			Logging.d("ParseException " + e);
			limitDateTime = null;

		} catch (RuntimeException e) {

			// エラーの場合、無効とする.
			Logging.d("RuntimeException " + e);
			limitDateTime = null;

		}

		return limitDateTime;
	}
}
