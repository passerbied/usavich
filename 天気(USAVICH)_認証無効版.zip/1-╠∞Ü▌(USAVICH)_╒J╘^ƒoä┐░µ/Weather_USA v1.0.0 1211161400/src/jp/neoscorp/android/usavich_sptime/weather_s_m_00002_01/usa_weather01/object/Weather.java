package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object;

public class Weather {
	public static final String WEATHER_TAG = "city";

	public static final String WEATHER_ID = "weather";
	public static final String MAX = "tempmax";
	public static final String MIN = "tempmin";
	public static final String POP = "pop";
	
	public static final String SUNNY = "weather-sunny";
	public static final String CLOUDY = "weather-cloudy";
	public static final String RAINY = "weather-rain";
	public static final String SNOWY = "weather-snow";

	private int mWeatherId = -1;
	private int mMax = -500;
	private int mMin = -500;
	private int mPop = -1;

	public Weather() {
	}

	public Weather(int weatherId, int max, int min, int pop) {
		mWeatherId = weatherId;
		mMax = max;
		mMin = min;
		mPop = pop;
	}

	public int getWeatherId() {
		return mWeatherId;
	}

	public void setWeatherId(int weatherId) {
		mWeatherId = weatherId;
	}

	public int getMax() {
		return mMax;
	}

	public void setMax(int max) {
		mMax = max;
	}

	public int getMin() {
		return mMin;
	}

	public void setMin(int min) {
		mMin = min;
	}

	public int getPop() {
		return mPop;
	}

	public void setPop(int pop) {
		mPop = pop;
	}

	public boolean isNull() {
		return ((mMax + mMin + mPop + mWeatherId) == -1002 ? true : false);
	}

	@Override
	public String toString() {
		return "Today's weather: " + "max=" + getMax() + ", min=" + getMin()
				+ ", pop=" + getPop() + ", weatherId=" + getWeatherId();
	}

}