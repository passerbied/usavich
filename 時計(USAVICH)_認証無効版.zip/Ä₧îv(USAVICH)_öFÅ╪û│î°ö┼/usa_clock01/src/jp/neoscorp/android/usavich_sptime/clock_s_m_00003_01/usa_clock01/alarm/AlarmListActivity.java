package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.R;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import jp.primeworks.android.flamingo.activity.FlamingoFragmentActivity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class AlarmListActivity extends FlamingoFragmentActivity  
{
	public static String APP_CLOSE_ACTION    = "com.taiyo.clock.action.APP_CLOSE_ACTION";
	public static String TIMER_STOP_ACTION = "com.taiyo.clock.action.TIMER_STOP_ACTION";
	public static String ALARM_UPDATE_ACTION = "com.taiyo.clock.action.ALARM_UPDATE_ACTION";
	private Button mBackBtn, mAddBtn;
	private ImageView mMainBg;
	private final int ORG_SCREEN_WIDTH = 480; 
	private ListView mAlarmListView;
	private TextView mAlarmListTitle;
	private AlarmDataBaseAdapter mAlarmDB;
	private AlarmListViewAdapter mAlarmListViewAdapter;
	private List<Map<String, Object>> mData; 
	private Dialog editDialog = null, deleteDialog = null;
	private int  selectItem = -1;
	private Typeface tf;
	private DisplayMetrics dm;
	private Context mContext;
	private CommonReceiver mCommonReceiver;
	
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.alarmlistview);
		Utils.MAIN_TAB_SHOW_STATUS = false;
		Utils.ALARMLIST_ACTIVITY_DESTROYED_STATUS = false;
		mContext = AlarmListActivity.this;
		dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);	
        
		mAlarmListTitle = (TextView) findViewById(R.id.alarmlistTitle);
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mAddBtn = (Button) findViewById(R.id.addBtn);
		
		mMainBg = (ImageView) findViewById(R.id.alarmlistbg);        
		tf = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/settings_A-OTF-ShinMGoPro-Medium.otf");
		
		mCommonReceiver = new CommonReceiver();
		mCommonReceiver.register();
		mAlarmDB = new AlarmDataBaseAdapter(this);
		mAlarmDB.open();
		
		mAlarmListTitle.setTypeface(tf);
		mBackBtn.setTypeface(tf);
		mAddBtn.setTypeface(tf);
		mAlarmListTitle.setTextColor(Color.WHITE);
		mBackBtn.setTextColor(Color.WHITE);
		mAddBtn.setTextColor(Color.WHITE);
		
		mAlarmListView = (ListView)findViewById(R.id.alarmListView);
		
		mBackBtn.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				Utils.TAB_ID = 1;
				AlarmListActivity.this.finish();
			}
		});
		
		mAddBtn.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				Intent intent = new Intent(AlarmListActivity.this,AlarmOptionActivity.class);
				intent.putExtra("editMode", "ADD");
				startActivity(intent);
			}
		});
	}
	
	protected void onResume()
	{
		super.onResume();
		if (Utils.TIMER_STATUS.equals("ON")) 
		{  
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); 
		} 
		else 
		{			
			getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		}
		reloadListView();
		mMainBg.setImageResource(R.drawable.watch_bg);
		mMainBg.setLayoutParams(getLinearLayoutPararm(0, 0, 480, 854));
	}
	
	private void reloadListView()
	{
		if(mData != null && !mData.isEmpty())
			mData.clear();
		mData = getData();
		mAlarmListViewAdapter = null;
		mAlarmListViewAdapter = new AlarmListViewAdapter(this);
		mAlarmListView.setAdapter(mAlarmListViewAdapter);
		mAlarmListView.setOnItemClickListener(mAlarmListOnItemClick);
		mAlarmListView.setOnItemLongClickListener(mAlarmListOnItemLongClick);
	}
    
	AdapterView.OnItemClickListener mAlarmListOnItemClick = new AdapterView.OnItemClickListener() 
	{
		public void onItemClick(AdapterView<?> parent, View view, int position,long id) 
		{
			mAlarmListViewAdapter.setSelectItem(position);
			if(editDialog != null)
				editDialog.cancel();
			Intent intent = new Intent(AlarmListActivity.this,AlarmOptionActivity.class);
			intent.putExtra("editMode", "EDIT");
			intent.putExtra("alarmId",    (String)mData.get(selectItem).get("alarmId"));
			intent.putExtra("alarmTime",  (String)mData.get(selectItem).get("alarmTime"));
			intent.putExtra("alarmLabel", (String)mData.get(selectItem).get("alarmLabel"));
			startActivity(intent);
		}
	};
	
	AdapterView.OnItemLongClickListener mAlarmListOnItemLongClick = new AdapterView.OnItemLongClickListener() 
	{
		public boolean onItemLongClick(AdapterView<?> parent, View view, int position,long id) 
		{
			mAlarmListViewAdapter.setSelectItem(position);
			
			editDialog = createEditDialog();
			editDialog.show(); 
			editDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
	        editDialog.setOnKeyListener(new android.content.DialogInterface.OnKeyListener()
	        {  
	    	   public boolean onKey(DialogInterface dialog, int keyCode,KeyEvent event) 
	    	   {             	
	    	        switch (keyCode) 
	    	        {  
			          case KeyEvent.KEYCODE_BACK:  
			        	   editDialog.dismiss();  
			        	   return true;
			          case KeyEvent.KEYCODE_HOME: 
			        	   editDialog.dismiss();  
			        	   sendBroadcast(new Intent(APP_CLOSE_ACTION));
			        	   AlarmListActivity.this.finish();
		    	           return true;  
	    	        }  
	    	        return false;  
	    	    }  
	    	});
	        
			return false;
		}
	};

	public final class AlarmInforViewHolder 
	{
		public TextView alarmLabel;	
		public TextView alarmTime;	
		public TextView alarmWeek;	
		public CheckBox alarmOnOff;
	}
		
	public class AlarmListViewAdapter extends BaseAdapter 
	{
		private LayoutInflater mInflater;
		
		public AlarmListViewAdapter(Context context) 
		{
			this.mInflater = LayoutInflater.from(context);
		}
		
		public int getCount()
		{
			return mData.size();
		}
		
		public Object getItem(int arg0) 
		{
			return mData.get(arg0);
		}
		
		public long getItemId(int arg0)
		{
			return arg0;
		}
		
		public View getView(final int position, View convertView, ViewGroup parent) 
		{
			AlarmInforViewHolder holder = null;
			
			if (convertView == null) 
			{
				holder = new AlarmInforViewHolder();
				convertView = mInflater.inflate(R.layout.alarmlistcellview, null);
				holder.alarmLabel = (TextView) convertView.findViewById(R.id.alarmlabel);
				holder.alarmTime = (TextView) convertView.findViewById(R.id.alarmtime);
				holder.alarmWeek = (TextView) convertView.findViewById(R.id.week);
				holder.alarmOnOff = (CheckBox) convertView.findViewById(R.id.alarmOnOff);
				
				holder.alarmLabel.setTypeface(tf);
				holder.alarmTime.setTypeface(tf);
				holder.alarmWeek.setTypeface(tf);
				
				convertView.setTag(holder);		
			} 
			else 
			{
				holder = (AlarmInforViewHolder) convertView.getTag();
			}
			
			holder.alarmLabel.setText(Utils.formartStringLength((String) mData.get(position).get("alarmLabel")));	
			holder.alarmTime.setText((String)  mData.get(position).get("alarmTime"));	
			holder.alarmWeek.setText((String)  mData.get(position).get("alarmWeekText"));	
			
			if(((String)mData.get(position).get("alarmOnOff")).equals("ON"))
			{
				holder.alarmOnOff.setChecked(true);
			}
			else
			{
				holder.alarmOnOff.setChecked(false);
			} 
			
			holder.alarmOnOff.setOnClickListener(new View.OnClickListener() 
			{  
	            public void onClick(View v) 
	            {  
	                CheckBox cb = (CheckBox)v;  
					if (cb.isChecked())
					{
						// OFF TO ON
						Alarm.alarmOffToOn( mContext,
								             (String)mData.get(position).get("alarmId"),
											 (String)mData.get(position).get("alarmHour"),
											 (String)mData.get(position).get("alarmMinutes"),
											 (String)mData.get(position).get("alarmWeek"));
						
						Intent intentNextAlarmTime = new Intent(ALARM_UPDATE_ACTION);
						intentNextAlarmTime.putExtra("nextalarmtime", Alarm.getNextAlarmTimeData(mContext).get(0));
						sendBroadcast(intentNextAlarmTime);						
					} 
					else 
					{
						//ON TO OFF
						Alarm.alarmOnToOff(mContext, (String)mData.get(position).get("alarmId"));
						
						Intent intentNextAlarmTime = new Intent(ALARM_UPDATE_ACTION);
						intentNextAlarmTime.putExtra("nextalarmtime", Alarm.getNextAlarmTimeData(mContext).get(0));
						sendBroadcast(intentNextAlarmTime);							
					}
					reloadListView();
	            }  
	        });  

			return convertView;
		}
		
		public  void setSelectItem(int iSelectItem) 
		{
			 selectItem = iSelectItem;
		}
	}

	public List<Map<String, Object>> getData() 
	{		
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> map = null;
		
		Cursor mCursor  = mAlarmDB.selectAllByAlarmIdAsc();
		if(mCursor != null && mCursor.getCount() != 0)
		{
			mCursor.moveToFirst();
			for(int i = 0; i < mCursor.getCount(); i++)
			{
				map = new HashMap<String, Object>();
				map.put("alarmId",     mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_ID)));
				map.put("alarmLabel",  mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_TITLE)));
				map.put("alarmTime",   mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_HOUR)) + ":" +
									   mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_MINUTES)));
				map.put("alarmHour",   mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_HOUR)));
				map.put("alarmMinutes",mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_MINUTES)));
				map.put("alarmWeek",   mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_WEEK)));
				map.put("alarmWeekText",mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_WEEKTEXT)));
				map.put("alarmOnOff",  mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_ONOFF)));
				
				list.add(map);
				
				mCursor.moveToNext();
			}
		}
		mCursor.close();
		mCursor = null;
		
		return list;
	}
	
	private Dialog createEditDialog()
	{
		Dialog dialog = null;
		
        String strAlarmOnOff;
        if(((String)mData.get(selectItem).get("alarmOnOff")).equals("ON")){
        	strAlarmOnOff = "OFF";
        }else{
        	strAlarmOnOff = "ON";
        }
        
        String[] itemContent = {"アラームを「" + strAlarmOnOff + "」にする",
        		               "アラームを編集",
        		               "アラームを削除"};
        
    	Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null);
        builder.setTitle((String)mData.get(selectItem).get("alarmTime") + "  " +
        		Utils.formartStringLength((String)mData.get(selectItem).get("alarmLabel")));
        builder.setItems(itemContent,new DialogInterface.OnClickListener()
        	{
        		public void onClick(DialogInterface dialog, int which) 
        		{	
        			switch(which)
        			{	
            			case 0:         						
    						String  OnOff = (String)mData.get(selectItem).get("alarmOnOff");
    						if (OnOff.equals("ON")) {
    							// ON TO OFF
    							Alarm.alarmOnToOff(mContext, (String)mData.get(selectItem).get("alarmId"));
    							Intent intentNextAlarmTime = new Intent(ALARM_UPDATE_ACTION);
    							intentNextAlarmTime.putExtra("nextalarmtime", Alarm.getNextAlarmTimeData(mContext).get(0));
    							sendBroadcast(intentNextAlarmTime);	
    						} 
    						else 
    						{
    							// OFF TO ON
    							Alarm.alarmOffToOn(  mContext,
    									             (String)mData.get(selectItem).get("alarmId"),
													 (String)mData.get(selectItem).get("alarmHour"),
													 (String)mData.get(selectItem).get("alarmMinutes"),
													 (String)mData.get(selectItem).get("alarmWeek"));
    							Intent intentNextAlarmTime = new Intent(ALARM_UPDATE_ACTION);
    							intentNextAlarmTime.putExtra("nextalarmtime", Alarm.getNextAlarmTimeData(mContext).get(0));
    							sendBroadcast(intentNextAlarmTime);	
    						}
    						reloadListView();
            				dialog.dismiss();
            				break;	            			
            			case 1: //編集
            				dialog.dismiss();
            				Intent intent = new Intent(AlarmListActivity.this,AlarmOptionActivity.class);
            				intent.putExtra("editMode", "EDIT");
            				intent.putExtra("alarmId",    (String)mData.get(selectItem).get("alarmId"));
            				intent.putExtra("alarmTime",  (String)mData.get(selectItem).get("alarmTime"));
            				intent.putExtra("alarmLabel", (String)mData.get(selectItem).get("alarmLabel"));
            				startActivity(intent);
            				break;
            			case 2: //削除
            				deleteDialog = createDeleteDialog();
            				deleteDialog.show();
            				break;	            				
        			}
                }
            });
        
        builder.setNegativeButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
            	dialog.dismiss(); 
            }
        });
        
        dialog = builder.create();
        return dialog;
	}
	
	private Dialog createDeleteDialog()
	{
        Dialog dialog = null;
        
        Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null);
        builder.setTitle((String)mData.get(selectItem).get("alarmTime") + "  " +
                		 (String)mData.get(selectItem).get("alarmLabel"));
        builder.setMessage("削除しますか？");
        
        builder.setPositiveButton("いいえ", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	editDialog.dismiss(); 
            	dialog.dismiss(); 
            }
        });
        
        builder.setNegativeButton("はい", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	Alarm.cancelAlarm(mContext, (String)mData.get(selectItem).get("alarmId"));
            	mAlarmDB.deleteByAlarmId(Integer.parseInt((String)mData.get(selectItem).get("alarmId")));
				if(Alarm.IsHaveSkipIdNotification(mContext, Integer.parseInt((String)mData.get(selectItem).get("alarmId")))){
				}
				else{
					Alarm.delNotification(mContext);
				}
				reloadListView();
				
				Intent intentNextAlarmTime = new Intent(ALARM_UPDATE_ACTION);
				intentNextAlarmTime.putExtra("nextalarmtime", Alarm.getNextAlarmTimeData(mContext).get(0));
				sendBroadcast(intentNextAlarmTime);	
				
				editDialog.dismiss(); 
				dialog.dismiss(); 
            }
        });
        
        dialog = builder.create();
        
        return dialog;
    }
	 
	 public LinearLayout.LayoutParams getLinearLayoutPararm(int x, int y, int w, int h)
	 {
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.leftMargin = dm.widthPixels * x / ORG_SCREEN_WIDTH;
		params.topMargin =  dm.widthPixels * y / ORG_SCREEN_WIDTH;
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		
		return params;
	 }
	 
     private class CommonReceiver extends BroadcastReceiver
	 {
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction(ALARM_UPDATE_ACTION);
			filter.addAction(TIMER_STOP_ACTION);
			filter.addAction(APP_CLOSE_ACTION);
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			if (intent.getAction().equals(ALARM_UPDATE_ACTION)) 
			{
				reloadListView();
			} 
			
			if (intent.getAction().equals(TIMER_STOP_ACTION)) 
			{
				getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
			}	
			
	        if (intent.getAction().equals(APP_CLOSE_ACTION)) 
	        {
	    		if(mData != null && !mData.isEmpty())
	    			mData.clear();
	    		mData = null;
	    		mMainBg.setImageDrawable(null);
	        	AlarmListActivity.this.finish();
	        }
		}
	}
	 
	 
	protected void onDestroy() 
	{
		//Log.v("CLOCK", "AlarmListActivity onDestroy");
		Utils.ALARMLIST_ACTIVITY_DESTROYED_STATUS = true;
		Utils.MAIN_TAB_SHOW_STATUS = true;
		mCommonReceiver.unRegister();
		mAlarmDB.close();  
		mAlarmDB = null;
		if(mData != null && !mData.isEmpty())
			mData.clear();
		mData = null;
		mMainBg.setImageDrawable(null);
		super.onDestroy();
	}

	 public void onAttachedToWindow() 
	 {
		  if (true) 
		  {
			  this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
		  }
		  super.onAttachedToWindow();
	 }
	 
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		 switch(keyCode)
		 {
			 case KeyEvent.KEYCODE_BACK:
				  Utils.TAB_ID = 1;
		          AlarmListActivity.this.finish();
				  break;
			 case KeyEvent.KEYCODE_HOME:
				  sendBroadcast(new Intent(APP_CLOSE_ACTION));
				  AlarmListActivity.this.finish();
				  break;				  
		 }
		return super.onKeyDown(keyCode, event);
    }

}
