package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm.Alarm;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm.AlarmListActivity;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.timer.TimerOptionActivity;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import jp.primeworks.android.flamingo.activity.FlamingoFragmentActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainTabActivity extends FlamingoFragmentActivity
{
	public static String TIMER_UPDATE_ACTION = "com.taiyo.clock.action.TIMER_UPDATE_ACTION";
	public static String TIMER_START_ACTION = "com.taiyo.clock.action.TIMER_START_ACTION";
	public static String TIMER_STOP_ACTION = "com.taiyo.clock.action.TIMER_STOP_ACTION";
	public static String APP_CLOSE_ACTION = "com.taiyo.clock.action.APP_CLOSE_ACTION";
	public static String ALARM_UPDATE_ACTION = "com.taiyo.clock.action.ALARM_UPDATE_ACTION";
	private GestureDetector gestureDetector;
	View.OnTouchListener gestureListener;
	private MainTabView mySurfaceView = null;
	private int currentView = 1;
	private static int maxTabIndex = 2;
	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_MAX_OFF_PATH = 250;
	private static final int SWIPE_THRESHOLD_VELOCITY = 200;
	private final int ORG_SCREEN_WIDTH = 480; 
	private TextView mAlarmNowTimeTextView, mTimerCountDown;
	private DisplayMetrics dm;
	private ImageView mTabBtn1, mTabBtn2, mAlarmDegital, mStartStopBtn, mTimerCountDownBg;
	private boolean mbIsStarted = false, mbAlarmIcon = false;
	private Context mContext;
	private AlarmReceiver mAlarmReceiver;
    
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		Utils.TAB_ID = 1;
		Utils.MAIN_TAB_ACTIVITY_STATUS = "onCreate";
		Utils.MAIN_TAB_ACTIVITY_DESTROYED_STATUS = false;
		setContentView(R.layout.maintabview);
        mySurfaceView  = (MainTabView)findViewById(R.id.alarmtimertabview);
        mAlarmDegital  =  (ImageView) findViewById(R.id.alarmdegital);
        mAlarmNowTimeTextView = (TextView) findViewById(R.id.alarmtimetext);
		mStartStopBtn = (ImageView) findViewById(R.id.StartStopBtn);
		mTimerCountDown = (TextView) findViewById(R.id.timerCountDown);
		mTimerCountDownBg = (ImageView) findViewById(R.id.timerCountDownBg);
		mTabBtn1 = (ImageView) findViewById(R.id.tab_alarm);
		mTabBtn2 = (ImageView) findViewById(R.id.tab_timer);
		
		mContext = MainTabActivity.this;
		mySurfaceView.bLoop = true;
        dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
 		
 		mTabBtn1.setLayoutParams(getLinearLayoutPararm(190, 20, 40, 40));
 		mTabBtn2.setLayoutParams(getLinearLayoutPararm(250, 20, 40, 40));
        mAlarmDegital.setLayoutParams(getLinearLayoutPararm(12, 80, 230, 100));  
		mTimerCountDown.setLayoutParams(getLinearLayoutPararm(65, 400, 110));  
		mTimerCountDownBg.setLayoutParams(getLinearLayoutPararm(65, 400, 110));  
		mStartStopBtn.setLayoutParams(getLinearLayoutPararm(0, 180, 60)); 
        
		startService(new Intent(Utils.ACTION_WIDGET_SERVICE));
		startService(new Intent(Utils.ACTION_TIMER_SERVICE));
		gestureDetector = new GestureDetector(new MyGestureDetector());
		mAlarmReceiver = new AlarmReceiver();
		mAlarmReceiver.register();
    	
		mTabBtn1.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				Utils.TAB_ID = 1;
		    	mySurfaceView.bAlarmIcon = mbAlarmIcon;   
		    	setItemVisibility();
			}
		});
		mTabBtn2.setOnClickListener(new OnClickListener() 
		{
			public void onClick(View arg0) {
				Utils.TAB_ID = 2;
				Utils.MAIN_TAB_SHOW_STATUS = true;
		    	mySurfaceView.bAlarmIcon = mbAlarmIcon;   
		    	setItemVisibility();
			}
		});
		
    	mAlarmDegital.setOnClickListener(new OnClickListener() 
 		{			
 			public void onClick(View arg0) 
 			{
 				Intent intent = new Intent(MainTabActivity.this,AlarmListActivity.class);
 				startActivity(intent);
 			}
 		});
        
        mStartStopBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				 //START 
				if (Utils.TIMER_STATUS.equals("OFF")) 
				{ 
					mbIsStarted = true;
					Utils.TIMER_STATUS = "ON";
					setItemVisibility();
					sendBroadcast(new Intent(TIMER_START_ACTION));
				 } 
				//STOP 
				else {
					mbIsStarted = false;
					Utils.TIMER_STATUS = "OFF";
					setItemVisibility();
					sendBroadcast(new Intent(TIMER_STOP_ACTION));
				 }
			}
		});

		mTimerCountDown.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				if (mbIsStarted) 
				{
					//画面遷移しない
				} 
				else 
				{
					Intent intent = new Intent(MainTabActivity.this, TimerOptionActivity.class);
					startActivity(intent);
				}
			}
		});
		
	}
	
	protected void onResume()
	{
		super.onResume();
		if (Utils.TIMER_STATUS.equals("ON")) 
		{  
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); 
		} 
		else 
		{			
			getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		}
		
		if(Utils.MAIN_TAB_ACTIVITY_STATUS.equals("onStop") && 
		   Utils.MAIN_TAB_ACTIVITY_DESTROYED_STATUS == false &&
		   Utils.ALARMLIST_ACTIVITY_DESTROYED_STATUS == true && 
		   Utils.TIMEROPTION_ACTIVITY_DESTROYED_STATUS == true)
		{
			Utils.TAB_ID = 1;
			currentView = 1;
		}
		Utils.MAIN_TAB_ACTIVITY_STATUS = "onResume";
		
		switch(Utils.TAB_ID)
		{
			case 1:
				//Degital Data
				mAlarmNowTimeTextView.setLayoutParams(getLinearLayoutPararm(190, 80, 230, 100));
		        mySurfaceView.mNextAlarmText = Alarm.getNextAlarmTimeData(getApplicationContext()).get(0);
		        if(mySurfaceView.mNextAlarmText.equals("-- : --"))
		        {
		        	mbAlarmIcon = false;
		        }
		        else
		        {
		        	mbAlarmIcon = true;
		        }
				break;
		}
		
    	mySurfaceView.bAlarmIcon = mbAlarmIcon;   
    	setItemVisibility();
    	
	}
	
	protected void onPause()
	{
		super.onPause();
		mbIsStarted = false;
	}
    
    private void setItemVisibility()
    {		
		switch(Utils.TAB_ID)
		{
			case 1:
				mAlarmDegital.setVisibility(View.VISIBLE);
				mAlarmNowTimeTextView.setVisibility(View.VISIBLE);
				mTimerCountDown.setVisibility(View.INVISIBLE);
				mTimerCountDownBg.setVisibility(View.INVISIBLE);
				mStartStopBtn.setVisibility(View.INVISIBLE);
				break;
			case 2:
				mAlarmDegital.setVisibility(View.INVISIBLE);
				mAlarmNowTimeTextView.setVisibility(View.INVISIBLE);
				mTimerCountDown.setVisibility(View.VISIBLE);
				mTimerCountDownBg.setVisibility(View.VISIBLE);
				mStartStopBtn.setVisibility(View.VISIBLE);
				
				if (Utils.TIMER_STATUS.equals("ON")) 
				{  
					getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); 
					Utils.TIMER_STATUS = "ON";
					mbIsStarted = true;
				} 
				else 
				{			
					getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
					if(Utils.TIMER.equals("00:00:00"))
					{
						mStartStopBtn.setEnabled(false);
						Utils.TIMER_STATUS = "OFF";
						mbIsStarted = false;
					} 
					else
					{
						mStartStopBtn.setEnabled(true);
						Utils.TIMER_STATUS = "OFF";
						mbIsStarted = false;
					}
				}
				break;
		}
    }
    
    private class AlarmReceiver extends BroadcastReceiver
	{
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction(ALARM_UPDATE_ACTION);
			filter.addAction(TIMER_STOP_ACTION);
			filter.addAction(APP_CLOSE_ACTION);
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			  if (intent.getAction().equals(ALARM_UPDATE_ACTION)) 
			  {
			        mySurfaceView.mNextAlarmText = Alarm.getNextAlarmTimeData(mContext).get(0);
			        if(mySurfaceView.mNextAlarmText.equals("-- : --"))
			        {
			        	mbAlarmIcon = false;
			        }
			        else
			        {
			        	mbAlarmIcon = true;
			        }
			   } 

			   if (intent.getAction().equals(TIMER_STOP_ACTION)) 
			   {
					getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
			   }	
			  
		       if (intent.getAction().equals(APP_CLOSE_ACTION)) 
		       {    
		    	   MainTabActivity.this.finish();
		       }
		}
	}

    private class MyGestureDetector extends SimpleOnGestureListener 
	{
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) 
		{
			try {
				if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
					return false;
				if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
					if (currentView == maxTabIndex) {
						currentView = 1;
					} else {
						currentView++;
					}
				} else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
					if (currentView == 1) {
						currentView = maxTabIndex;
					} else {
						currentView--;
					}
				}
				Utils.TAB_ID = currentView;	
				if(Utils.TAB_ID == 2)Utils.MAIN_TAB_SHOW_STATUS = true;
            	mySurfaceView.bAlarmIcon = mbAlarmIcon;   
            	setItemVisibility();
			} catch (Exception e) {
			}
			return true;
		}
	}
	
	public boolean dispatchTouchEvent(MotionEvent event) {

		if (gestureDetector.onTouchEvent(event)) {
			event.setAction(1);
		}
		return super.dispatchTouchEvent(event);
	}
	
	public LinearLayout.LayoutParams getLinearLayoutPararm(int y, int w, int h)
	{
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.topMargin =  dm.widthPixels * y / ORG_SCREEN_WIDTH;
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		
		return params;
	}
	
	public LinearLayout.LayoutParams getLinearLayoutPararm(int x, int y, int w, int h)
	{
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.leftMargin = dm.widthPixels * x / ORG_SCREEN_WIDTH;
		params.topMargin =  dm.widthPixels * y / ORG_SCREEN_WIDTH;
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		
		return params;
	}
	
	protected void onStop()
	{
		super.onStop();
		Utils.MAIN_TAB_ACTIVITY_STATUS = "onStop";
	}
	
	protected void onDestroy() 
	{
		Utils.MAIN_TAB_ACTIVITY_STATUS = "onDestroy";
		Utils.MAIN_TAB_ACTIVITY_DESTROYED_STATUS = true;
		Utils.MAIN_TAB_SHOW_STATUS = false;
		mAlarmReceiver.unRegister();
		mTabBtn1.setImageDrawable(null);
		mTabBtn2.setImageDrawable(null);
		mAlarmDegital.setImageDrawable(null);
		mStartStopBtn.setImageDrawable(null);
		mTimerCountDownBg.setImageDrawable(null);
		mySurfaceView.bLoop = false;
	    super.onDestroy();
	}
	
}