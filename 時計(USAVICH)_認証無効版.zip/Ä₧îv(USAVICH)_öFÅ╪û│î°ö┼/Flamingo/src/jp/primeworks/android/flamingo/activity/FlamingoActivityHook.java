package jp.primeworks.android.flamingo.activity;

import jp.primeworks.android.flamingo.Flamingo;
import jp.primeworks.android.flamingo.FlamingoError;
import jp.primeworks.android.flamingo.R;
import jp.primeworks.android.flamingo.util.FlamingoResources;
import jp.primeworks.android.flamingo.util.FlamingoSharedPreferences;
import jp.primeworks.android.flamingo.util.Logging;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

/**
 * Flamingo Activity Hook.
 *
 * @author takimura
 *
 */
public class FlamingoActivityHook {

	/**
	 * Activityインスタンス.
	 */
	private Activity mActivity;

	/**
	 * 認証処理中フラグ.
	 */
	boolean mAuthorizing = false;

	/**
	 * 認証結果エラーフラグ.
	 */
	boolean mAuthError = false;

	/**
	 * コンストラクタ.
	 * @param activity
	 */
	public FlamingoActivityHook(Activity activity) {
		mActivity = activity;
	}

	/**
	 * onCreateOptionsMenuフック.
	 *
	 * @param menu
	 * @return
	 */
    public boolean onHookCreateOptionsMenu(Menu menu) {
        MenuInflater inflator = new MenuInflater(mActivity);
        inflator.inflate(R.menu.flamingo_main, menu);

        return true;
    }

    /**
     * onOptionItemSelectedフック.
     * @param item
     * @return
     */
    public boolean onHookOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.flamingo_menu_main_about) {
            Intent intent = new Intent();
            intent.setClass(mActivity, AboutActivity.class);
            try {
            	mActivity.startActivity(intent);
            } catch (ActivityNotFoundException e) {
            }
        } else if(id == R.id.flamingo_menu_main_help) {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            intent.setData(Uri.parse(FlamingoResources.getResources(mActivity).getString(R.string.help_uri)));
            try {
            	mActivity.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                // FIXME: warning message
            }
        }
        return true;
    }

    /**
     * 起動認証を開始する.
     * 
     * <p>
     * 
     * @param bgAuth バックグラウンド認証実施
     */
    public void authorize() {
        Flamingo flamingo = new Flamingo(mActivity);

        if(flamingo.isValidApplication()) {
            onAuthorizeComplete(true);
        }

        else if(!isAuthorizeError()) {

        	FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();
        	
            if(!pref.getAuthorizeComplete(mActivity)) {
				/* TODO: 初回認証の場合にのみダイアログを表示する */
                mActivity.showDialog(FlamingoActivity.DIALOG_AUTHORIZE);
            } else {
                flamingo.authorize(new Flamingo.OnAuthorizeListner() {
                    @Override
                    public void onError(FlamingoError error) {
                        onAuthorizeError(error);
                    }

                    @Override
                    public void onComplete(boolean authorizeOk) {
                    	onAuthorizeComplete(authorizeOk);
                    }

                    @Override
                    public void onCancel() {
                        onAuthorizeCancel();
                    }
                });
            }
        }
    }

    public boolean isValidApplication() {
        return (new Flamingo(mActivity)).isValidApplication();
    }

    /**
     * 認証中状態を取得する.
     * @return true:認証中、false:非認証中
     */
    public boolean isAuthorizing() {
    	return mAuthorizing;
    }

    /**
     * 認証エラー状態を取得する.
     * 
     * <p>
     * Flamingo認証が完了し、且つ、エラーが発生していた場合に true を返す。
     * 
     * @return
     */
    public boolean isAuthorizeError() {
    	return mAuthError;
    }

    /**
     * ダイアログ作成コールバック.
     *
     * @param id ダイアログID
     */
    public Dialog onHookCreateDialog(int id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        switch(id) {
        case FlamingoActivity.DIALOG_AUTHORIZE:
        	prepareAuthorize(builder);
        	return builder.create();
        	//return null;
        case FlamingoActivity.DIALOG_AUTHORIZE_FAILED:
        	prepareAuthorizeFail(builder, R.string.flamingo_authorize_failed_message);
        	return builder.create();
        case FlamingoActivity.DIALOG_NETWORK_ERROR:
        	prepareAuthorizeError(builder, R.string.flamingo_authorize_network_error_message);
        	return builder.create();
        case FlamingoActivity.DIALOG_AUTHORIZE_CANCELED: // TODO: GT 暫定追加。NEOS殿に確認を依頼。
        	prepareAuthorizeError(builder, R.string.flamingo_authorize_canceled_message);
        	return builder.create();
        case FlamingoActivity.DIALOG_SERVER_ERROR:
            prepareAuthorizeError(builder, R.string.flamingo_authorize_server_error_message);
            return builder.create();
        default:
            return null;
        }
    }

    /**
     * アプリケーション認証ダイアログ初期化.
     * @param builder
     */
    protected void prepareAuthorize(AlertDialog.Builder builder) {
    	builder.setTitle(FlamingoResources.getResources(mActivity).getString(R.string.flamingo_authorize_confirm_title));
        builder.setMessage(FlamingoResources.getResources(mActivity).getString(R.string.flamingo_authorize_confirm_message));
        builder.setCancelable(false);
        builder.setPositiveButton(FlamingoResources.getResources(mActivity).getString(android.R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //dialog.dismiss();

            	mAuthorizing = true;
                Flamingo flamingo = new Flamingo(mActivity);
                flamingo.authorize(new Flamingo.OnAuthorizeListner() {
					@Override
					public void onError(FlamingoError error) {
					    onAuthorizeError(error);
					}
					@Override
					public void onComplete(boolean authorizeOk) {
					    onAuthorizeComplete(authorizeOk);
					}
					@Override
					public void onCancel() {
					    onAuthorizeCancel();
					}
				});
            }
        });
        builder.setNegativeButton(FlamingoResources.getResources(mActivity).getString(android.R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            	mActivity.finish();
				mActivity.setResult(Activity.RESULT_CANCELED);
            }
        });
    }

    /**
     * 認証NGダイアログの作成.
     *
     * @param builder ダイアログビルダー
     * @param message メッセージ
     */
    protected void prepareAuthorizeFail(AlertDialog.Builder builder, int messageId) {
    	prepareAuthorizeFail(builder, FlamingoResources.getResources(mActivity).getString(messageId));
    }

    /**
     * 認証NGダイアログの作成.
     *
     * @param builder ダイアログビルダー
     * @param message メッセージ
     */
    protected void prepareAuthorizeFail(AlertDialog.Builder builder, CharSequence message) {
    	builder.setTitle(android.R.string.dialog_alert_title);
    	builder.setIcon(android.R.drawable.ic_dialog_alert);
    	builder.setMessage(message);
    	builder.setCancelable(false);
    	builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mAuthorizing = false;
				mAuthError = true;

				// check string resource and browser start.
				String auth_ng_uri = FlamingoResources.getResources(mActivity).getString(R.string.flamingo_auth_ng_uri);
				if(auth_ng_uri.length() > 0) {
					// start browser application.
					Logging.d("Send browser intent. url=" + auth_ng_uri);
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(auth_ng_uri));
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					try {
	                    mActivity.startActivity(intent);
					} catch (ActivityNotFoundException e) {
					}
		        } else {
		        	// do nothing
		        }

				dialog.dismiss();
				mActivity.finish();
				mActivity.setResult(Activity.RESULT_CANCELED);

			}
		});
    }

    /**
     * 認証エラーダイアログの作成.
     *
     * @param builder ダイアログビルダー
     * @param message メッセージ
     */
    protected void prepareAuthorizeError(AlertDialog.Builder builder, int messageId) {
    	prepareAuthorizeError(builder, FlamingoResources.getResources(mActivity).getString(messageId));
    }

    /**
     * 認証エラーダイアログの作成.
     *
     * @param builder ダイアログビルダー
     * @param message メッセージ
     */
    protected void prepareAuthorizeError(AlertDialog.Builder builder, CharSequence message) {
    	builder.setTitle(android.R.string.dialog_alert_title);
    	builder.setIcon(android.R.drawable.ic_dialog_alert);
    	builder.setMessage(message);
    	builder.setCancelable(false);
    	builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mAuthorizing = false;
				mAuthError = true;

				dialog.dismiss();
				mActivity.finish();
				mActivity.setResult(Activity.RESULT_CANCELED);
			}
		});
    }

    /**
     * 認証完了コールバック.
     * 
     * @param authorizeOk 認証結果
     */
    protected void onAuthorizeComplete(boolean authorizeOk) {
        mAuthorizing = false;
        if(!authorizeOk) {
            mAuthError = true;
            mActivity.showDialog(FlamingoActivity.DIALOG_AUTHORIZE_FAILED);
        } else {
			FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();
			pref.setAuthorizeComplete(mActivity, true);
            mAuthError = false;
        }
    }

    /**
     * 認証エラーコールバック.
     * @param error 認証エラー
     */
    protected void onAuthorizeError(FlamingoError error) {
        mAuthorizing = false;
        mAuthError = true;
        switch(error.getErrorCode()) {
        case FlamingoError.ERROR_CODE_NETWORK:
            mActivity.showDialog(FlamingoActivity.DIALOG_NETWORK_ERROR);
            break;
        case FlamingoError.ERROR_CODE_NONE:
        case FlamingoError.ERROR_CODE_SERVER:
        case FlamingoError.ERROR_CODE_UNKNOWN:
        default:
            mActivity.showDialog(FlamingoActivity.DIALOG_SERVER_ERROR);
            break;
        }
    }

    /**
     * 認証キャンセルコールバック.
     */
    protected void onAuthorizeCancel() {
        mAuthorizing = false;
        mAuthError = true;
//      mActivity.finish();                                                 // TODO: GT 暫定コメントアウト。NEOS殿に確認を依頼。
//      mActivity.setResult(Activity.RESULT_CANCELED);                      // TODO: GT 暫定コメントアウト。NEOS殿に確認を依頼。
        mActivity.showDialog(FlamingoActivity.DIALOG_AUTHORIZE_CANCELED);   // TODO: GT 暫定追加。NEOS殿に確認を依頼。
    }

}
