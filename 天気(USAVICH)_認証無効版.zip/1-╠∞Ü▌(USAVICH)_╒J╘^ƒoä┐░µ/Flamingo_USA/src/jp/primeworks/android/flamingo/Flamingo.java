package jp.primeworks.android.flamingo;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import jp.primeworks.android.flamingo.activity.FlamingoAuthorizeActivity;
import jp.primeworks.android.flamingo.util.FlamingoResources;
import jp.primeworks.android.flamingo.util.FlamingoSharedPreferences;
import jp.primeworks.android.flamingo.util.FlamingoUtil;
import jp.primeworks.android.flamingo.util.Logging;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;

import com.samsung.zirconia.LicenseCheckListener;
import com.samsung.zirconia.Zirconia;

/**
 * Flamingo
 *
 * <p>
 * Flamingo DRM サーバ/クライアント共通インターフェース.
 *
 */
public class Flamingo {

	/**
	 * 自身のインスタンス
	 */
	private OnAuthorizeListner mOnAuthorizeListner = null;

	/**
	 * コンテキスト
	 */
	private Context mContext = null;

	/**
	 * Zirconia 認証結果キャッシュ.
	 * <p>
	 * ローカルキャッシュ/サーバから取得した認証結果をキャッシュ保持する。
	 */
    private boolean mZirconiaLocalResult = false;

	/**
	 * 認証処理完了フラグ<BR>
	 * ※処理の完了フラグであり、認証がOKであったかどうかではない.
	 */
	public static final int CERTIFICATE_COMPLETE = 0;

	/**
	 * 認証エラーフラグ
	 */
	public static final int CERTIFICATE_ERROR = 1;

	/**
	 * 認証キャンセル
	 */
	public static final int CERTIFICATE_CANCEL = 2;

	/**
	 * インテントEXTRAタグ - 認証処理状態通知用
	 */
	public static final String CERTIFICATE_REQUEST_RESULT = "certificate_request_result";

	/**
	 * インテントEXTRAタグ - 認証結果通知用
	 */
	public static final String CERTIFICATE_RESULT = "certificate_result";

	/**
	 * インテントEXTRAタグ - 認証エラーコード通知用
	 */
	public static final String CERTIFICATE_ERRORCODE = "certificate_error_code";

	/**
	 * Basic認証ユーザ名<BR>
	 * ※本項目はstring_static.xmlに配置しない.
	 */
	private static final String BASIC_AUTHENTICATION_USER = "pwmainte";

	/**
	 * Basic認証パスワード<BR>
	 * ※本項目はstring_static.xmlに配置しない.
	 */
	private static final String BASIC_AUTHENTICATION_PASSWORD = "maintepass";


	/**
	 * ユーザ認証の結果を受け取るためのレシーバー.<BR>
	 *
	 * 送付されてくるインテントには、ユーザ認証実施元のパッケージ名が付与されている.<BR>
	 * そのため、インテントフィルタには自身のパッケージ名を設定すること.<BR>
	 * <BR>
	 * 認証処理成功(CERTIFICATE_COMPLETE)の場合、EXTRAタグ "CERTIFICATE_REQUEST_RESULT" に認証の結果が設定される.<BR>
	 * true:認証OK, false:認証NG<BR>
	 * <BR>
	 * 認証処理失敗(CERTIFICATE_ERROR)の場合、EXTRAタグ "CERTIFICATE_ERRORCODE" にエラーコードが設定される.<BR>
	 * <BR>
	 * 認証処理キャンセル(CERTIFICATE_CANCEL)の場合、EXTRAタグは設定されない.<BR>
	 *
	 */
	private class UserCertificateRusltReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {

			Logging.v("UserCertificateRusltReceiver#onReceive");
			Logging.v("intent.getAction()" + intent.getAction());
			Logging.v("FlamingoUtil.getIncetance().getUserPackageName(context) : " + FlamingoUtil.getIncetance().getUserPackageName(context));
			if (intent.getAction().equals(FlamingoUtil.getIncetance().getUserPackageName(context))) {

				Logging.v("take recieve event.");

				// レシーバーの解除
				removeAuthorizeRusltReceiver();

				int requestResult = intent.getIntExtra(CERTIFICATE_REQUEST_RESULT, CERTIFICATE_ERROR);

				switch (requestResult) {

				case CERTIFICATE_COMPLETE:

					Logging.v("case CERTIFICATE_COMPLETE");

					// 認証処理成功 認証結果（認証OK時にtrue）を返す.
					if (mOnAuthorizeListner != null) {
						Logging.v("CERTIFICATE_COMPLETE " + intent.getBooleanExtra(CERTIFICATE_RESULT, false));
						mOnAuthorizeListner.onComplete(intent.getBooleanExtra(CERTIFICATE_RESULT, false));
					}
					break;

				case CERTIFICATE_ERROR:

					Logging.v("case CERTIFICATE_ERROR");

					// 認証処理エラー エラークラスのインスタンスを返す.
					if (mOnAuthorizeListner != null) {
						Logging.v("CERTIFICATE_ERROR");
						mOnAuthorizeListner.onError(new FlamingoError(mContext, intent.getIntExtra(CERTIFICATE_ERRORCODE,
								FlamingoError.ERROR_CODE_UNKNOWN)));
					}
					break;

				case CERTIFICATE_CANCEL:

					Logging.v("case CERTIFICATE_CANCEL");

					// 認証処理キャンセル
					if (mOnAuthorizeListner != null) {
						Logging.v("CERTIFICATE_CANCEL");
						mOnAuthorizeListner.onCancel();
					}
					break;

				default:
					Logging.w("Unknown. requestResult=" + requestResult);
					break;
				}
			}
		}
	}

	/**
	 * BroadcastReceiverのインスタンス
	 */
	private UserCertificateRusltReceiver authorizeRusltReceiver = new UserCertificateRusltReceiver();


	/**
	 * BroadcastReceiverを登録し利用可能状態にする.
	 */
	private void registerAuthorizeRusltReceiver() {

		IntentFilter filter = new IntentFilter();
		filter.addAction(FlamingoUtil.getIncetance().getUserPackageName(mContext));

		mContext.registerReceiver(authorizeRusltReceiver, filter);
	}


	/**
	 * BroadcastReceiverの利用を終了するために登録を解除する.
	 */
	private void removeAuthorizeRusltReceiver() {

		mContext.unregisterReceiver(authorizeRusltReceiver);
	}


	/**
	 * コンストラクタ
	 *
	 * @param context
	 *            コンテキスト
	 */
	public Flamingo(final Context context) {

		this.mContext = context;

		int logLevel = Logging.DEFAULT_LOG_LEVEL;
		try {
			logLevel = Integer.valueOf(FlamingoResources.getResources(context).getString(R.string.flamingo_log_level));
		} catch (RuntimeException e) {
			logLevel = Logging.DEFAULT_LOG_LEVEL;
		}
		if ((logLevel < Logging.LOG_LEVEL_MIN) || (Logging.LOG_LEVEL_MAX < logLevel)) {
			logLevel = Logging.DEFAULT_LOG_LEVEL;
		}
		if (logLevel != Logging.NOT_OUTPUT) {
			Logging.setLogLevel(Logging.ALL);
			Logging.d("logLevel=" + logLevel);
		}
		Logging.setLogLevel(logLevel);

		Logging.d("Library " + FlamingoResources.getResources(context).getString(R.string.flamingo_app_name) + " ver." + FlamingoResources.getResources(context).getString(R.string.flamingo_local_version));
	}


	/**
	 * アプリケーション利用可否取得API
	 *
	 * <p>
	 * アプリケーション利用権利情報を取得するAPI.<BR>
	 * 同期で利用可否の情報を返却する.
	 *
	 * @return 利用可否情報<BR>
	 *         true:利用可<BR>
	 *         false:利用不可
	 */
	public boolean isValidApplication() {

		Logging.d("isValidApplication() called.");

		// Zirconia認証
        if(FlamingoResources.getResources(mContext).getBoolean(R.bool.flamingo_zirconia_auth)) {
            if(!(mContext instanceof Activity)) {
                FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();
                return pref.getValidApplicationFlag(mContext);
            }

            Zirconia zirconia = new Zirconia((Activity)mContext);
            zirconia.setLicenseCheckListener(new LicenseCheckListener() {
                @Override
                public void licenseCheckedAsValid() {
                    mZirconiaLocalResult = true;
                }
                @Override
                public void licenseCheckedAsInvalid() {
                    mZirconiaLocalResult = false;
                }
            });
            zirconia.checkLicense(true, true);

            return mZirconiaLocalResult;
        }

        // Neos認証
        else if(FlamingoResources.getResources(mContext).getBoolean(R.bool.flamingo_auth)) {
    		// validateDate取得
    		FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();
    		String validateDate = pref.getValidateDate(mContext);
    
    		if (validateDate.length() == 0) {
    
    			Logging.d("validateDate is nothing.");
    			// 従量課金もしくは月額課金で一度も認証していない場合
    			return pref.getValidApplicationFlag(mContext);
    
    		} else {
    
    			Logging.d("validateDate exist : " + validateDate);
    			// 月額課金の時は有効期限の範囲チェックを行う.
    			// この時点での範囲チェックには「期限超過後猶予日数」は使用しない.
    			return FlamingoUtil.getIncetance().checkValidDate(validateDate, null);
    
    		}
        }

        // 認証なし
        else {
            return true;
        }
	}


	/**
	 * 期間制限権利の有効期限を取得する.
	 *
	 * @return 期間制限権利の有効期限
	 */
	public Date getValidTerm() {

		Logging.d("getValidTerm() called.");

		// validateDate取得
		FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();
		String validateDate = pref.getValidateDate(mContext);

		if ((validateDate == null) || (validateDate.length() == 0)) {

			Logging.d("not found validateDate.");

			/* 期間制限なしの場合 */
			return null;

		} else {

			Logging.d("found validateDate. validateDate=" + validateDate);

			/* 期間権利有効期限を返答する. */
			Date limitDateTime = FlamingoUtil.getIncetance().getValidDate(validateDate);

			return limitDateTime;

		}
	}


	/**
	 * アプリケーション利用認証API
	 *
	 * <p>
	 * アプリケーション利用権利情報を更新するAPI.<BR>
	 * 更新結果については、非同期で通知される.
	 *
	 * @param listener
	 *            リスナのインスタンス
	 */
	public void authorize(OnAuthorizeListner listener) {

		Logging.d("authorize() called.");
		if (listener == null) {
			Logging.d("listener is null.");
		}
		
		// リスナを保持する。
		mOnAuthorizeListner = listener;

		// BroadcastReceiverを登録する。
		registerAuthorizeRusltReceiver();

		// 認証処理を実施するActivityを起動
		Intent intent = new Intent();
		intent.setClass(mContext, FlamingoAuthorizeActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if(FlamingoResources.getResources(mContext).getBoolean(R.bool.flamingo_zirconia_auth)) {
            intent.addCategory(FlamingoAuthorizeActivity.INTENT_CATEGORY_ZIRCONIA);
        }
		mContext.startActivity(intent);
	}


	/**
	 * アイテム権利情報取得API<BR>
	 * <BR>
	 * 本メソッドは仕様未定.
	 *
	 * <p>
	 * アイテム権利情報を更新するAPI.<BR>
	 * 権利情報はブラウザを起動し、更新結果については非同期で通知される.
	 *
	 * @param itemId
	 *            アイテムID
	 * @param listener
	 *            リスナ
	 */
	public void purchase(String itemId, OnAuthorizeListner listener) {

		Logging.d("purchase() called.  itemId=" + itemId);
		if (listener == null) {
			Logging.d("listener is null.");
		}

		mOnAuthorizeListner = listener;
	}


	/**
	 * 利用権利情報更新関連のリスナークラス
	 *
	 * <p>
	 * 非同期で結果を取得する各APIのリスナークラス.
	 *
	 */
	public static interface OnAuthorizeListner {

		/**
		 * 正常終了時に呼ばれるコールバック
		 *
		 * @param authorizeOk
		 *            認証OKフラグ
		 */
		public void onComplete(boolean authorizeOk);


		/**
		 * 異常終了時に呼ばれるコールバック
		 *
		 * @param error
		 *            エラー情報
		 */
		public void onError(FlamingoError error);


		/**
		 * キャンセル時に呼ばれるコールバック
		 */
		public void onCancel();
	}


	/**
	 * アプリケーション利用認証2 API
	 *
	 * <p>
	 * ユーザー認証実施有無を指定してアプリケーション利用権利情報を更新するAPI.<BR>
	 * 更新結果については、非同期で通知される.
	 *
	 * @param userAuth
	 *            ユーザー認証実施有無<BR>
	 *            true:ユーザ認証とアプリケーション認可を行う.（UIあり）<BR>
	 *            false:ユーザ認証を行わず、アプリケーション認可のみ行う.（UIなし）
	 */
	public void authorize(boolean userAuth, OnAuthorizeListner listener) {

		Logging.d("authorize(userAuth, listener) called.  userAuth=" + userAuth);
		if (listener == null) {
			Logging.d("listener is null.");
		}

		if (!userAuth) {

			// リスナを保持する。
			mOnAuthorizeListner = listener;

			// BroadcastReceiverを登録する。
			registerAuthorizeRusltReceiver();

			// アプリケーション認可のみ行う。(UIは非表示)
			requestApplicationAuthorize();

		} else {

			// ユーザ認証とアプリケーション認可を行う。(UI表示あり)
			authorize(listener);

		}
	}


	/**
	 * アプリケーション認可を開始する.
	 *
	 * <p>
	 * アプリケーション利用認証2 向けの実装.<BR>
	 * UIを利用せずユーザ認証も行わない.<BR>
	 * アプリケーション認可と判定のみ行い、アプリケーション側に結果を返す.
	 */
	private void requestApplicationAuthorize() {

		Logging.v("call requestApplicationAuthorize()");

		/**
		 * アプリケーション認可を非同期で行うためのタスク.
		 *
		 */
		class RequestApplicationAuthorizeTask extends AsyncTask<Void, Void, Boolean> {

			/**
			 * 認証レスポンスの結果を格納する.
			 */
			private Map<String, String> response = null;


			/**
			 * onPreExecute<BR>
			 * 非同期処理開始<BR>
			 *
			 * @see android.os.AsyncTask#onPreExecute()
			 */
			@Override
			protected void onPreExecute() {

				super.onPreExecute();
				Logging.d("");
			}


			/**
			 * doInBackground<BR>
			 * 非同期処理本体<BR>
			 *
			 * @see android.os.AsyncTask#doInBackground(Params[])
			 */
			@Override
			protected Boolean doInBackground(Void... params) {

				Logging.d("");

				ApplicationAuthorize applicationAuthorize = new ApplicationAuthorize(mContext);
				response = applicationAuthorize.request();

				Boolean hasResponse = (response != null);
				Logging.d("hasResponse " + hasResponse);
				return hasResponse;
			}


			/**
			 * onPostExecute<BR>
			 * 非同期処理終了<BR>
			 * <p>
			 * 認証処理に成功した場合、resultにtrueを渡すこと.<BR>
			 * 失敗した場合(ネットワークエラーやタイムアウトで処理が正常に行えなかった場合)、resultにfalseを渡すこと.
			 */
			@Override
			protected void onPostExecute(Boolean result) {

				super.onPostExecute(result);
				Logging.d("");
				if (result) {
					onPostApplicationAuthorized(response);
				} else {
					onPostApplicationAuthorized(null);
				}
				Logging.d("");
			}
		}

		RequestApplicationAuthorizeTask task = new RequestApplicationAuthorizeTask();
		task.execute((Void) null);
		Logging.d("");
	}


	/**
	 * アプリケーション認可の結果を受け取ったときに呼ばれるコールバック.
	 *
	 * @param response
	 *            レスポンスデータの結果.<BR>
	 *            有効なレスポンスデータがない場合、nullを設定すること.
	 */
	private void onPostApplicationAuthorized(Map<String, String> response) {

		onApplicationAuthorizeResult2(response);
	}


	/**
	 * ２回目のアプリケーション認可に対する結果受信コールバック
	 *
	 * @param response
	 *            レスポンスデータ
	 */
	private void onApplicationAuthorizeResult2(Map<String, String> response) {

		Logging.v("response = " + response);

		FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();

		Logging.d("");

		// アプリケーション認可(2回目)に成功

		try {
			// レスポンスデータの検証
			verifyAuthorizeResponse(response);
		} catch (FlamingoError e) {
			Logging.d("verifyAuthorizeResponse is error.");

			// プリファレンスを「認可なし」状態でクリアする.
			pref.setValidApplicationFlag(mContext, false);
			pref.removeValidateDate(mContext);
			pref.removeGraceDays(mContext);

			// 認証エラー
			noticeAuthorizeErrorMessage(e.getErrorCode());
			return;
		}

		// 認証状態、期限の日時、期限超過後猶予日数を取得する.
		boolean hasLicense = false;
		String license = response.get("license");
		String validateDate = response.get("validateDate");
		String graceDays = response.get("graceDays");

		hasLicense = (license != null) && (license.equalsIgnoreCase("OK"));
		Logging.d("license = " + license + ", hasLicense = " + hasLicense);

		// プリファレンスに認証状態、期限の日時、期限超過後猶予日数を格納する.
		pref.setValidApplicationFlag(mContext, hasLicense);
		pref.setValidateDate(mContext, validateDate);
		pref.setGraceDays(mContext, graceDays);

		if (hasLicense) {

			// 認証済みの場合

			if (validateDate != null) {

				// 期限日時がnullでない場合 = 月額課金

				Logging.d("validateDate is not null");

				// この時点での期間チェックには「期限超過後猶予日数」は使用しない.
				if (FlamingoUtil.getIncetance().checkValidDate(validateDate, null)) {

					// 期間内であればアプリケーションは利用可能とする.

					Logging.d("checkValidDate is OK.");

					// ここで処理を終えるため通知を行う.
					noticeAuthorizeCompleteMessage(hasLicense);

				} else {

					Logging.d("checkValidDate is NG.");

					// 2回目の認可でも期日を超えているのでアプリケーションは利用不可とする.
					noticeAuthorizeCompleteMessage(false);

				}

			} else {

				// 従量課金の場合

				Logging.d("valiateDate is null");

				// ここで処理を終えるため通知を行う.（アプリケーションは「利用可能」）
				noticeAuthorizeCompleteMessage(hasLicense);

			}

		} else {

			Logging.d("not authorize");
			// 未認証の場合

			// 2回目の認可でも未認証なのでアプリケーションは利用不可.
			noticeAuthorizeCompleteMessage(false);

		}
	}


	/**
	 * 認可失敗通知API
	 *
	 * @param errorCode
	 *            エラー番号
	 */
	private void noticeAuthorizeErrorMessage(int errorCode) {

		Logging.d("errorCode=" + errorCode);
		FlamingoUtil flamingoUtil = FlamingoUtil.getIncetance();
		Intent intent = new Intent(flamingoUtil.getUserPackageName(mContext));
		// 認証処理エラーを返す.
		intent.putExtra(Flamingo.CERTIFICATE_REQUEST_RESULT, Flamingo.CERTIFICATE_ERROR);
		intent.putExtra(Flamingo.CERTIFICATE_ERRORCODE, errorCode);
		mContext.sendBroadcast(intent);

		Logging.d("");
	}


	/**
	 * 認可完了通知API
	 *
	 * @param hasLicense
	 *            ライセンスありフラグ
	 */
	private void noticeAuthorizeCompleteMessage(boolean hasLicense) {

		Logging.d("hasLicense = " + hasLicense);
		FlamingoUtil flamingoUtil = FlamingoUtil.getIncetance();
		Intent intent = new Intent(flamingoUtil.getUserPackageName(mContext));
		// 認証処理成功を返す.
		intent.putExtra(Flamingo.CERTIFICATE_REQUEST_RESULT, Flamingo.CERTIFICATE_COMPLETE);
		// 認証結果を返す.
		intent.putExtra(Flamingo.CERTIFICATE_RESULT, hasLicense);
		mContext.sendBroadcast(intent);

		Logging.d("");
	}


	/**
	 * アプリケーション認可API レスポンスデータの検証.
	 *
	 * <p>
	 * アプリケーション認可APIのレスポンスデータとして渡されたデータの整合性を検証する.<BR>
	 * 想定外のデータが格納されている場合は FlamingoError で通信エラーをアプリケーション側へ通知する.
	 *
	 * @param response
	 *            レスポンスデータ
	 * @throws FlamingoError
	 *             レスポンスデータが誤っている場合
	 */
	private void verifyAuthorizeResponse(Map<String, String> response) throws FlamingoError {

		// ネットワークエラー発生時
		if (response == null) {
			// ネットワークエラーを通知する.
			Logging.d("error authorize ");
			throw new FlamingoError(mContext, FlamingoError.ERROR_CODE_NETWORK);
		}

		// 認可結果を確認する.
		String resultStr = response.get("result");

		// 認可の結果がNG
		if ((resultStr == null) || (!resultStr.equalsIgnoreCase("OK"))) {
			// サーバーエラーを通知する.
			Logging.d("result NG");
			throw new FlamingoError(mContext, FlamingoError.ERROR_CODE_SERVER);
		}

		// 認証状態を確認する.
		String license = response.get("license");
		if (license == null) {
			throw new FlamingoError(mContext, FlamingoError.ERROR_CODE_SERVER);
		}
	}


	/**
	 * アプリケーション認可を行うクラス.
	 */
	private class ApplicationAuthorize {

		/**
		 * コンテキスト
		 */
		private Context mContext;

		/**
		 * アプリケーション認可用URI
		 */
		private ApplicationAuthorizeUri applicationAothorizeUri;


		/**
		 * コンストラクタ
		 *
		 * @param context
		 *            コンテキスト
		 */
		ApplicationAuthorize(Context context) {

			Logging.d("");
			mContext = context;
			applicationAothorizeUri = new ApplicationAuthorizeUri(mContext);
			Logging.d("");
		}


		/**
		 * アプリケーション認可を行う.
		 *
		 * @return HTTPから取得した項目マップ
		 */
		public Map<String, String> request() {

			Logging.d("");
			Map<String, String> map = null;
			Uri uri = getUri();

			Logging.d("uri=" + uri.toString());
			InputStream in = null;

			// アプリケーション認証の応答について疑似データを作成する（動作テスト用）
			boolean useAppAuthorizeTestData = false;
			useAppAuthorizeTestData = Boolean.valueOf(FlamingoResources.getResources(
			        mContext).getString(R.string.flamingo_use_app_authorize_test_data));

			if (useAppAuthorizeTestData) {
				return makeDebugData();
			}

			// 正規のHTTPアクセス処理
			final DefaultHttpClient httpClient = new DefaultHttpClient();

			// Basic認証
			Credentials credentials = new UsernamePasswordCredentials(BASIC_AUTHENTICATION_USER, BASIC_AUTHENTICATION_PASSWORD);
			AuthScope scope = new AuthScope(uri.getHost(),uri.getPort() );
			httpClient.getCredentialsProvider().setCredentials(scope, credentials);

		    HttpGet httpGet = new HttpGet(uri.toString());
		    HttpResponse response = null;

		    // HTTP request
		    try {
		    	response = httpClient.execute(httpGet);
		    	
			    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
					// データを取得
					in = response.getEntity().getContent();

					ResponseParser parser = new ResponseParser();
					map = parser.read(in);
					Logging.v(map.toString());

					if (map != null) {
						Logging.d("Result of Application Authorize ----- map.size()=" + map.size());
						for (Map.Entry<String, String> e : map.entrySet()) {
							Logging.d("map key=" + e.getKey() + ", data=" + e.getValue());
						}
					}
			    } else {
			    	Logging.w("getResponseCode() is not HTTP_OK. getResponseCode()=" + response.getStatusLine().getStatusCode());
			    }
		    } catch (ClientProtocolException e) {

		    	Logging.e(e.toString());

		    } catch (IOException e) {

		    	Logging.e(e.toString());

		    } catch (XmlPullParserException e) {

		    	Logging.e(e.toString());

		    } finally {
		    	try {
		    		if (in != null) {
		    			in.close();
		    			in = null;
		    		}
		    	} catch (Exception e) {

		    		Logging.e(e.toString());

		    	}
		    }

			return map;
		}


		/**
		 * アプリケーション認証応答の疑似データ作成（動作テスト用）
		 *
		 * @return HTTPから取得した項目マップの擬似データ
		 */
		private Map<String, String> makeDebugData() {

			//

			if (Logging.DEBUG < Logging.getLogLevel()) {
				// ログが必ず出力されるようにする.
				Logging.setLogLevel(Logging.DEBUG);
			}

			Logging.w("== TEST ROUTINE IS RUNNING. USE APP AUTHORIZE TEST DATA. == ==");

			HashMapLowerCaseKey map = new HashMapLowerCaseKey();

			int testMode = 0;

			Logging.d("testMode=" + testMode);

			switch (testMode) {

			case 0:
				map.put("reSuLT", "OK");
				map.put("LicenSE", "NG");
				break;

			case 1:
				map.put("result", "OK");
				map.put("licenSE", "OK");
				break;

			case 2:
				map.put("result", "NG");
				map.put("licenSE", "OK");
				break;

			case 3:
				map.put("RESULT", "Ok");
				map.put("LICENSE", "ok");
				map.put("validateDate", "20120607T233000Z");
				map.put("graceDays", "3");
				break;

			case 4:
				map.put("result", "OK");
				map.put("licenSe", "ok");
				map.put("validateDate", "20120630T233000Z");
				map.put("graceDays", "3");
				break;

			case 5:
				map.put("RESULT", "Ok");
				map.put("LICENSE", "NG");
				map.put("validateDate", "20120607T233000Z");
				map.put("graceDays", "3");
				break;

			case 6:
				map.put("RESULT", "Ok");
				map.put("LICENSE", "ok");
				map.put("validateDate", "20120607");
				map.put("graceDays", "3");
				break;

			case 7:
				map.put("RESULT", "Ok");
				map.put("LICENSE", "ok");
				map.put("validateDate", "20120608");
				map.put("graceDays", "3");
				break;

			case 99:
				return null;

			default:
				// no item
				break;
			}

			return map;
		}


		/**
		 * アプリケーション認可用URIを取得する.
		 *
		 * @return アプリケーション認可用URI
		 */
		private Uri getUri() {

			Logging.d("");
			return applicationAothorizeUri.getUriInquiryApproval();
		}


		/**
		 * アプリケーション認可のレスポンスデータを解析する.
		 *
		 */
		private class ResponseParser {

			private static final String XML_TAG_ROOT = "flamingo";


			/**
			 * アプリケーション認可のレスポンスデータを解析しMap型に変換する.<BR>
			 * <BR>
			 * Mapのキーにはレスポンスデータのタグ名、値にはレスポンスデータのタグに設定されたテキストが格納される.<BR>
			 * ※キーについては必ず英小文字変換した結果を返す.<BR>
			 * ※値については特に英大文字小文字の変換は行わない.
			 *
			 * @param in
			 *            InputStreamクラスのインスタンス
			 * @return レスポンスデータのMap.<BR>
			 *         キー=レスポンスデータのタグ名 値=タグに対するデータ<BR>
			 *         ※キーについては必ず英小文字変換した結果を返す.
			 * @throws XmlPullParserException
			 *             パーサー処理失敗の場合
			 * @throws IOException
			 *             IO例外の場合
			 */
			public Map<String, String> read(InputStream in) throws XmlPullParserException, IOException {

				Logging.d("");

				XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
				parser.setInput(new InputStreamReader(in, "UTF-8"));

				// キーハンドリングを常に英小文字化して扱うHashMapを用いる.
				Map<String, String> map = new HashMapLowerCaseKey();

				int eventType = parser.getEventType();
				Logging.d("parser.getEventType=" + eventType);

				while (!isEndTagEvent(parser, XML_TAG_ROOT)) {
					switch (parser.next()) {
					case XmlPullParser.START_TAG:
						String name = parser.getName();
						if (XML_TAG_ROOT.equals(name)) {
							// ignore <root> tag body. it's empty.
							break;
						}

						eventType = parser.next();
						if (eventType == XmlPullParser.TEXT) {
							map.put(name, parser.getText());
							Logging.v("result: " + name + "=" + parser.getText());
						}

						break;
					case XmlPullParser.END_TAG:
						break;

					default:
						break;
					}

				}

				Logging.d("");
				return map;
			}


			/**
			 * 指定タグの終了を検出したか判定する.
			 *
			 * @param parser
			 *            XMLパーサ
			 * @param tag
			 *            タグ
			 * @return 終了を検出したときtrueを返す.
			 * @throws XmlPullParserException
			 *             分割処理エラーの場合
			 */
			private boolean isEndTagEvent(XmlPullParser parser, String tag) throws XmlPullParserException {

				int eventType = parser.getEventType();
				return eventType == XmlPullParser.END_DOCUMENT || (eventType == XmlPullParser.END_TAG && tag.equals(parser.getName()));
			}
		}


		/**
		 * アプリケーション認可時に使用するURIを表すクラス.
		 */
		class ApplicationAuthorizeUri {

			/**
			 * コンテキスト
			 */
			private Context mContext;


			/**
			 * コンストラクタ
			 *
			 * @param context
			 *            コンテキスト
			 */
			ApplicationAuthorizeUri(Context context) {

				mContext = context;
			}


			/**
			 * サーバー側のスキーマ名を取得する.<BR>
			 * 例) "http","https"
			 *
			 * @return スキーマ名
			 */
			private String getScheme() {

				Resources res = FlamingoResources.getResources(mContext);
				return res.getString(R.string.flamingo_server_scheme);
			}


			/**
			 * アプリケーション認可接続先のAuthority（ホスト名）を取得する.<BR>
			 * 例)"stg.www.custamo.com"
			 *
			 * @return アプリケーション認可接続先のAuthority
			 */
			private String getUrlApplicationAuthority() {

				Resources res = FlamingoResources.getResources(mContext);
				return res.getString(R.string.flamingo_application_authorize_url_authority);
			}


			/**
			 * アプリケーション認可接続先のパスを取得する.<BR>
			 * 例) "/smartp/FLM001"
			 *
			 * @return アプリケーション認可接続先のパス
			 */
			private String getUrlApplicationPath() {

				Resources res = FlamingoResources.getResources(mContext);
				return res.getString(R.string.flamingo_application_authorize_url_path);
			}


			/**
			 * IMEIを取得する.
			 *
			 * @return IMEI
			 */
			private String getImei() {

				return FlamingoUtil.getIncetance().getImei(mContext);
			}


			/**
			 * IMSIを取得する.
			 *
			 * @return IMSI
			 */
			private String getImsi() {

				return FlamingoUtil.getIncetance().getImsi(mContext);
			}


			/**
			 * アプリケーションのパッケージ名を取得する.
			 *
			 * @return アプリケーションのパッケージ名
			 */
			private String getUserPackageName() {

				return FlamingoUtil.getIncetance().getUserPackageName(mContext);
			}


			/**
			 * アプリケーション認可問合わせのURIを取得する.<BR>
			 * <BR>
			 * キーには下記のものを用いる.<BR>
			 * ・IMEI<BR>
			 * ・IMSI<BR>
			 * ・パッケージ名<BR>
			 * ・アイテムID（任意項目のため、現在は利用しない.） <BR>
			 * URI文字列の例）<BR>
			 * http://www.example.com/flamingo/auth?imei=abcdefg&imsi=1234567890&packageName=jp.neos.android.example
			 *
			 * @return URIインスタンス
			 */
			public Uri getUriInquiryApproval() {

				String imei = getImei();
				String imsi = getImsi();
				String packageName = getUserPackageName();

				Uri.Builder builder = new Uri.Builder();
				builder.scheme(getScheme());
				builder.authority(getUrlApplicationAuthority());
				builder.path(getUrlApplicationPath());
				builder.appendQueryParameter("imei", imei);
				builder.appendQueryParameter("imsi", imsi);
				builder.appendQueryParameter("packageName", packageName);

				Uri uri = builder.build();

				Logging.v("ApplicationAuthorize Uri = " + uri.toString());

				return uri;
			}
		}
	}


	/**
	 * キーを常に英小文字化したうえで扱うHashMap<String, String>クラス
	 * <p>
	 * 本クラスはキーの入出力について必ず英小文字化を実施することにより、<BR>
	 * キーの英大小文字を同一視したマップとして機能する.
	 *
	 */
	private static class HashMapLowerCaseKey extends HashMap<String, String> {

		/**
		 * serialVersionUID<BR>
		 * デフォルト・シリアル・バージョンで扱う.
		 */
		private static final long serialVersionUID = 1L;


		/**
		 * 指定するキーがマップに存在するか調べる.
		 *
		 * @see java.util.HashMap#containsKey(java.lang.Object)
		 */
		@Override
		public boolean containsKey(Object key) {

			if (key instanceof String) {
				return super.containsKey(((String) key).toLowerCase(Locale.ENGLISH));
			} else {
				return super.containsKey(key);
			}
		}


		/**
		 * 指定するキーに対応する値を取得する.
		 *
		 * @see java.util.HashMap#get(java.lang.Object)
		 */
		@Override
		public String get(Object key) {

			if (key instanceof String) {
				return super.get(((String) key).toLowerCase(Locale.ENGLISH));
			} else {
				return super.get(key);
			}
		}


		/**
		 * マップにエントリを追加する.
		 *
		 * @see java.util.HashMap#put(java.lang.Object, java.lang.Object)
		 */
		@Override
		public String put(String key, String value) {

			return super.put(((String) key).toLowerCase(Locale.ENGLISH), value);
		}
	};

}
