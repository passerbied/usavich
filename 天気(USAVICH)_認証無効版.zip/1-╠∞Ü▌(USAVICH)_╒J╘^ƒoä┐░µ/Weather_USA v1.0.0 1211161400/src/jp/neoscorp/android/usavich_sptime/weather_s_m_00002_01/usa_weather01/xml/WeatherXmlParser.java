package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Date;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Weather;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class WeatherXmlParser {
	public static final String TAG = "XmlParser";

	private ArrayList<Weather> mWeatherList = new ArrayList<Weather>();

	private ArrayList<Date> mDateList = new ArrayList<Date>();

	public void parseStream(InputStream is) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		builder = factory.newDocumentBuilder();
		Document document = builder.parse(is);
		Element root = document.getDocumentElement();
		parseRoot(root);
	}

	private void parseRoot(Element root) {
		NodeList weatherNews = root.getChildNodes().item(3).getChildNodes();

		NodeList dateNode = weatherNews.item(1).getChildNodes();
		NodeList weekDate = dateNode.item(3).getChildNodes();
		for (int i = 0; i < weekDate.getLength(); i++) {
			Node day = weekDate.item(i);
			if (day.getNodeName().equals("day")) {
				NodeList innerDay = day.getChildNodes();
				Date date = new Date();
				for (int j = 0; j < innerDay.getLength(); j++) {
					Node innerinnerDay = innerDay.item(j);
					String innnnrTag = innerinnerDay.getNodeName();
					if (innnnrTag.equals(Date.YEAR)) {
						date.setYear(Integer.parseInt(innerinnerDay
								.getFirstChild().getNodeValue()));
					} else if (innnnrTag.equals(Date.MONTH)) {
						date.setMonth(Integer.parseInt(innerinnerDay
								.getFirstChild().getNodeValue()));
					} else if (innnnrTag.equals(Date.DATE)) {
						date.setDate(Integer.parseInt(innerinnerDay
								.getFirstChild().getNodeValue()));
					} else if (innnnrTag.equals(Date.DAY)) {
						date.setDay(Integer.parseInt(innerinnerDay
								.getFirstChild().getNodeValue()));
					}
				}
				mDateList.add(date);
			}
		}

		NodeList area = weatherNews.item(3).getChildNodes();
		NodeList weekArea = area.item(1).getChildNodes();
		for (int i = 0; i < weekArea.getLength(); i++) {
			Node day = weekArea.item(i);
			if (day.getNodeName().equals("day")) {
				NamedNodeMap dayAttr = day.getAttributes();
				Weather weather = new Weather(Integer.parseInt(dayAttr
						.getNamedItem(Weather.WEATHER_ID).getNodeValue()),
						Integer.parseInt(dayAttr.getNamedItem(Weather.MAX)
								.getNodeValue()), Integer.parseInt(dayAttr
								.getNamedItem(Weather.MIN).getNodeValue()),
						Integer.parseInt(dayAttr.getNamedItem(Weather.POP)
								.getNodeValue()));
				mWeatherList.add(weather);
			}
		}
	}

	public ArrayList<Weather> getWeathers() {
		return mWeatherList;
	}

	public ArrayList<Date> getDates() {
		return mDateList;
	}
}