package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.wviews;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.R;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.Utils;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Weather;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.AnimationDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class TodayView extends LinearLayout {

	private Context mContext;

	private ImageView mWeatherIv;
	private TextView mMaxTextView;
	private TextView mMaxTv;
	private TextView mMinTextView;
	private TextView mMinTv;
	private TextView mPopTextView;
	private TextView mPopTv;

	private AnimationDrawable mImgAnim;

	public TodayView(Context context, AttributeSet attrs) {
		super(context, attrs);
		mContext = context;
		LayoutInflater inflater = (LayoutInflater) mContext
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.todayinfo, this);

		Typeface numType = Utils.getTodayType(context);

		mWeatherIv = (ImageView) findViewById(R.id.iv_main_today_weather);
		mWeatherIv.setLayoutParams(new LayoutParams(0,
				ScreenConfig.todayWeather, 1.2f));
		mMaxTv = (TextView) findViewById(R.id.tv_main_today_max);
		mMaxTv.setTypeface(numType);
		mMaxTv.setTextSize(ScreenConfig.todayParam);
		mMinTv = (TextView) findViewById(R.id.tv_main_today_min);
		mMinTv.setTypeface(numType);
		mMinTv.setTextSize(ScreenConfig.todayParam);
		mPopTv = (TextView) findViewById(R.id.tv_main_today_pop);
		mPopTv.setTypeface(numType);
		mPopTv.setTextSize(ScreenConfig.todayParam);
		
		mMaxTextView = (TextView) findViewById(R.id.textview_main_max);
		mMaxTextView.setTypeface(numType);
		mMaxTextView.setTextSize(ScreenConfig.todayDscp);
		
		mMinTextView = (TextView) findViewById(R.id.textview_main_min);
		mMinTextView.setTypeface(numType);
		mMinTextView.setTextSize(ScreenConfig.todayDscp);
		
		mPopTextView = (TextView) findViewById(R.id.textview_main_pop);
		mPopTextView.setTypeface(numType);
		mPopTextView.setTextSize(ScreenConfig.todayDscp);
	}

	public void setWeather(Weather weather) {
		int todayMax = weather.getMax();
		mMaxTv.setText((todayMax == -500 ? "-" : todayMax) + "℃");
		int todayMin = weather.getMin();
		mMinTv.setText((todayMin == -500 ? "-" : todayMin) + "℃");
		int todayPop = weather.getPop();
		mPopTv.setText((todayPop == -1 ? "-" : todayPop) + "%");
		int comId = Utils.getComponentId(mContext, weather.getWeatherId());
		int animId;
		if (comId != -1) {
			animId = mContext.getResources().getIdentifier("frame_" + comId,
					"anim", mContext.getPackageName());
			mWeatherIv.setImageResource(animId);
			mImgAnim = (AnimationDrawable) mWeatherIv.getDrawable();
			mWeatherIv.post(new Runnable() {

				@Override
				public void run() {
					mImgAnim.setOneShot(false);
					mImgAnim.start();
				}
			});
		} else {
			animId = R.drawable.weather_def;
			mWeatherIv.setImageResource(animId);
		}
	}
}