package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.wviews;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.R;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.Utils;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Date;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Weather;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ImageView.ScaleType;

public class WeekDayView extends RelativeLayout {
	// private static final float NOR_TV_R = 5.0f / 226.0f;
	// private static final float DATE_TV_R = 4.0f / 226.0f;
	// private static final float WEATHER_IV_R = 10.0f / 226.0f;

	private Context mContext;

	// private int mScreenW = 768;
	// private int mScreenH = 1280;

	private TextView mDateTv;
	private TextView mDayTv;
	private ImageView mWeatherIv;
	private TextView mMaxTv;
	private TextView mMinTv;
	private TextView mPopTv;
	
	public WeekDayView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context);
	}

	public WeekDayView(Context context) {
		super(context);
		init(context);
	}

	private void init(Context context) {
		mContext = context;
		LayoutInflater inflater = (LayoutInflater) mContext
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.weekdayinfo, this);
		
		Typeface chaType = Utils.getWeekType(context);
		mDateTv = (TextView) findViewById(R.id.tv_wkdinfo_date);
		mDateTv.setTypeface(chaType);
		mDayTv = (TextView) findViewById(R.id.tv_wkdinfo_day);
		mDayTv.setTypeface(chaType);
		mWeatherIv = (ImageView) findViewById(R.id.iv_wkdinfo_weather);
		mWeatherIv.setScaleType(ScaleType.FIT_XY);
		mMaxTv = (TextView) findViewById(R.id.tv_wkdinfo_max);
		mMaxTv.setTypeface(chaType);
		mMinTv = (TextView) findViewById(R.id.tv_wkdinfo_min);
		mMinTv.setTypeface(chaType);
		mPopTv = (TextView) findViewById(R.id.tv_wkdinfo_pop);
		mPopTv.setTypeface(chaType);
		
		mDateTv.setTextSize(ScreenConfig.weekDate);
//		TextPaint datePaint = mDateTv.getPaint();
//		datePaint.setFakeBoldText(true);
		
		mDayTv.setTextSize(ScreenConfig.weekDay);
//		TextPaint dayPaint = mDateTv.getPaint();
//		dayPaint.setFakeBoldText(true);
		
		LayoutParams params = (LayoutParams) mWeatherIv.getLayoutParams();
		params.width = ScreenConfig.weekWeather;
		params.height = (int) (ScreenConfig.weekWeather / 1.36f);
		mWeatherIv.setLayoutParams(params);
		mMaxTv.setTextSize(ScreenConfig.weekParam);
//		TextPaint maxPaint = mMaxTv.getPaint();
//		maxPaint.setFakeBoldText(true);
		
		mMinTv.setTextSize(ScreenConfig.weekParam);
//		TextPaint minPaint = mMinTv.getPaint();
//		minPaint.setFakeBoldText(true);
		
		mPopTv.setTextSize(ScreenConfig.weekParam);
//		TextPaint popPaint = mPopTv.getPaint();
//		popPaint.setFakeBoldText(true);
	}

	public void setWeekWeather(Weather weather, Date date) {
		int month = date.getMonth(), nowDate = date.getDate();
		mDateTv.setText((month == -1 ? "-" : month) + "/"
				+ (nowDate == -1 ? "-" : nowDate));
		mDayTv.setText(Utils.getDayCast(date.getDay()));
		int max = weather.getMax();
		mMaxTv.setText((max == -500 ? "-" : max) + "℃");
		int min = weather.getMin();
		mMinTv.setText((min == -500 ? "-" : min) + "℃");
		int pop = weather.getPop();
		mPopTv.setText((pop == -1 ? "-" : pop) + "%");
		mWeatherIv.setImageBitmap(Utils.getTinyWeatherById(mContext,
				weather.getWeatherId()));
		invalidate();
	}
}