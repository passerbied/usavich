package jp.primeworks.android.flamingo;


import jp.primeworks.android.flamingo.util.FlamingoResources;
import jp.primeworks.android.flamingo.util.Logging;
import android.content.Context;


/**
 * FlamingoError
 *
 * <p>
 * Flamingo Error定義クラス
 */
public class FlamingoError extends Exception {

	/**
	 * serialVersionUID<BR>
	 * デフォルト・シリアル・バージョンで扱う.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * エラーコード：エラーなし 値0
	 */
	public static final int ERROR_CODE_NONE = 0;

	/**
	 * エラーコード：サーバーエラー 値1
	 */
	public static final int ERROR_CODE_SERVER = 1;

	/**
	 * エラーコード：ネットワークエラー 値2
	 */
	public static final int ERROR_CODE_NETWORK = 2;

	/**
	 * エラーコード：不明なエラー 値999
	 */
	public static final int ERROR_CODE_UNKNOWN = 999;

	/**
	 * エラー文言
	 */
	private String mErrorMessage = "";

	/**
	 * エラー番号
	 */
	private int mErrorCode = ERROR_CODE_NONE;


	public FlamingoError(Context context, int errorCode) {

		if (context != null) {
			mErrorCode = errorCode;
			mErrorMessage = readErrorMessage(context, errorCode);
			Logging.d(mErrorMessage);
		}
	}


	private String readErrorMessage(Context context, int errorCode) {

		String msg;

		switch (errorCode) {

		case ERROR_CODE_NONE:
			msg = "";
			break;

		case ERROR_CODE_SERVER:
			msg = FlamingoResources.getResources(context).getString(R.string.flamingo_error_message_server);
			break;

		case ERROR_CODE_NETWORK:
			msg = FlamingoResources.getResources(context).getString(R.string.flamingo_error_message_network);
			break;

		case ERROR_CODE_UNKNOWN:
		default:
			msg = FlamingoResources.getResources(context).getString(R.string.flamingo_error_message_unknown) + "(CODE:" + errorCode + ")";
			break;
		}
		return msg;
	}


	public int getErrorCode() {

		return mErrorCode;
	}


	public String getErrorMessage() {

		return mErrorMessage;
	}
}
