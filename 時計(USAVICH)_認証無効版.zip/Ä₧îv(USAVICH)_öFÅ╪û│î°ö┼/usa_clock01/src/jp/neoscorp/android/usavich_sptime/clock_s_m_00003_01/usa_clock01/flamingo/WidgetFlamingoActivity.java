package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.flamingo;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.MainTabActivity;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import jp.primeworks.android.flamingo.activity.FlamingoFragmentActivity;
import android.content.Intent;

public class WidgetFlamingoActivity extends FlamingoFragmentActivity {
    
    protected void onResume() {
        super.onResume();
/*
        // 未認証で非エラー画面は認証ダイアログ
        Flamingo flamingo = new Flamingo(this);
        if(!flamingo.isValidApplication() && !isAuthorizeError()) {
            showDialog(FlamingoActivity.DIALOG_AUTHORIZE);
        }

        // 認証済み or 認証成功
        else if(flamingo.isValidApplication() || !isAuthorizeError()) {
        	Utils.sCanAuto = true;
        	Intent resultValue = new Intent();

        	resultValue.setClass(this, MainTabActivity.class);
        	startActivity(resultValue);
        	finish();
        }
        */
        
        
    	Utils.sCanAuto = true;
    	Intent resultValue = new Intent();

    	resultValue.setClass(this, MainTabActivity.class);
    	startActivity(resultValue);
    	finish();
    }
}
