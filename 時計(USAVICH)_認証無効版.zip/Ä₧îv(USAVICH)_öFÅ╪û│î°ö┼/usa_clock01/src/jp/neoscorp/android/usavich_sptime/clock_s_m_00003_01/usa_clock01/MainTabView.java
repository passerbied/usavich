package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01;

import java.io.InputStream;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Typeface;
import android.text.format.Time;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MainTabView extends SurfaceView implements SurfaceHolder.Callback {
	
	private SurfaceHolder holder = null;
	private Paint paint = new Paint();
	public boolean bLoop = true, bAlarmIcon = false;
	private Paint mTimerFontPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private Paint mAlarmFontPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private Typeface mTimerFontType, mAlarmFontType;
	private Bitmap bgimg, timer_countdown, timer_button, timer_item, chara01, chara02, 
			timer_chara01, timer_chara02, copyright01, copyright02, copyright03;
	public String mNextAlarmText = "";
	private final int ORG_SCREEN_WIDTH = 480;
	private float fScale = (float) getWidth() / ORG_SCREEN_WIDTH;
	private Bitmap ind01, ind02, arrow_l, arrow_r, watch_bg, alarm_icon, degital_watch_bg,
			watch_arrow_l, watch_arrow_s, watch_point;
	private Time mCalendar = new Time();
	private int BLUE_TEXT_COLOR = Color.rgb(255, 255, 255);
	private int RED_TEXT_COLOR = Color.rgb(255, 187, 102);
	private int ALARM_TEXT_COLOR = Color.rgb(218, 229, 231);
	private float mHour, mMinutes;// , mSecond;
	public int mTime = -1; // 1:あさ　　2:ひる 3:よる

	private int timer_anime_chara01Pos = 0, timer_anime_chara02Pos = 0;

	// アニメ　timer_anime_chara01_01
	private int timer_anime_chara01_timecount = 0;
	private int[] timer_anime_chara01 = new int[] { 
			R.drawable.timer_anime_chara01_01,
			R.drawable.timer_anime_chara01_02 };
	private int[] timer_anime_chara01_time = new int[] { 200, 200 };

	// アニメ　timer_anime_chara02_01
	private int timer_anime_chara02_timecount = 0;
	private int[] timer_anime_chara02 = new int[] { 
			R.drawable.timer_anime_chara02_01,
			R.drawable.timer_anime_chara02_02 };
	private int[] timer_anime_chara02_time = new int[] { 200, 200 };

	// ///////////////////////////////////////////////
	public void drawAlarmView(Canvas canvas) {
		paint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
		canvas.drawPaint(paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC));

		onTimeChanged();
		switch (mTime) {
		case 1:
			drawBgImg(canvas, R.drawable.bg01_1, 0, 0);
			drawWatch(canvas, R.drawable.watch_bg01);
			drawMorningChara(canvas);
			drawDegitalWatch(canvas);
			drawBgImg(canvas, R.drawable.bg01_2, 0, 0);
			drawBgImg(canvas, R.drawable.effect01, 0, 0);
			drawTabIndex(canvas, 1);
			drawWatchIcon(canvas);
			drawCopyRight(canvas, 1);
			break;
		case 2:
			drawBgImg(canvas, R.drawable.bg02_1, 0, 0);
			drawWatch(canvas, R.drawable.watch_bg02);
			drawNoonChara(canvas);
			drawDegitalWatch(canvas);
			drawBgImg(canvas, R.drawable.bg02_2, 0, 0);
			drawTabIndex(canvas, 1);
			drawWatchIcon(canvas);
			drawCopyRight(canvas, 2);
			break;
		case 3:
			drawBgImg(canvas, R.drawable.bg03_1, 0, 0);
			drawWatch(canvas, R.drawable.watch_bg03);
			drawNightChara(canvas);
			drawDegitalWatch(canvas);
			drawBgImg(canvas, R.drawable.bg03_2, 0, 0);
			drawBgImg(canvas, R.drawable.effect03, 0, 0);
			drawTabIndex(canvas, 1);
			drawWatchIcon(canvas);
			drawCopyRight(canvas, 3);
			break;
		}
	}

	private void drawMorningChara(Canvas canvas) {
		Matrix m = null;
		
		if (chara01 != null && !chara01.isRecycled())
			chara01.recycle();
		chara01 = readBitmap(getResources(), R.drawable.chara01_1);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 0 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 278 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(chara01, m, null);
		
		if (chara02 != null && !chara02.isRecycled())
			chara02.recycle();
		chara02 = readBitmap(getResources(), R.drawable.chara01_2);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 120 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 378 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(chara02, m, null);
	}

	private void drawNoonChara(Canvas canvas) {
		Matrix m = null;
		
		if (chara01 != null && !chara01.isRecycled())
			chara01.recycle();
		chara01 = readBitmap(getResources(), R.drawable.chara02_1);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 0 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 252 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(chara01, m, null);
		
		if (chara02 != null && !chara02.isRecycled())
			chara02.recycle();
		chara02 = readBitmap(getResources(), R.drawable.chara02_2);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 229 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 260 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(chara02, m, null);
	}

	private void drawNightChara(Canvas canvas) {
		Matrix m = null;
		
		if (chara01 != null && !chara01.isRecycled())
			chara01.recycle();
		chara01 = readBitmap(getResources(), R.drawable.chara03_1);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 0 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 200 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(chara01, m, null);
		
		if (chara02 != null && !chara02.isRecycled())
			chara02.recycle();
		chara02 = readBitmap(getResources(), R.drawable.chara03_2);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 310 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 230 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(chara02, m, null);

		if (copyright03 != null && !copyright03.isRecycled())
			copyright03.recycle();
		copyright03 = readBitmap(getResources(), R.drawable.copyright03);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 100 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 20 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(copyright03, m, null);
	}
	
	public void drawTabIndex(Canvas canvas, int tabid) {
		Matrix m = null;
		
		if (arrow_l != null && !arrow_l.isRecycled())
			arrow_l.recycle();
		arrow_l = readBitmap(getResources(), R.drawable.arrow_l);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 150 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 20 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(arrow_l, m, null);
		
		if (arrow_r != null && !arrow_r.isRecycled())
			arrow_r.recycle();
		arrow_r = readBitmap(getResources(), R.drawable.arrow_r);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 295 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 20 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(arrow_r, m, null);
		
		switch (tabid) {
		case 1:
			if (ind01 != null && !ind01.isRecycled())
				ind01.recycle();
			ind01 = readBitmap(getResources(), R.drawable.alarm_ind01_on);
			m = new Matrix();
			m.setScale(fScale, fScale);
			m.postTranslate((float) getWidth() * 190 / ORG_SCREEN_WIDTH,
					(float) getWidth() * 20 / ORG_SCREEN_WIDTH);
			canvas.drawBitmap(ind01, m, null);

			if (ind02 != null && !ind02.isRecycled())
				ind02.recycle();
			ind02 = readBitmap(getResources(), R.drawable.alarm_ind02_off);
			m = new Matrix();
			m.setScale(fScale, fScale);
			m.postTranslate((float) getWidth() * 250 / ORG_SCREEN_WIDTH,
					(float) getWidth() * 20 / ORG_SCREEN_WIDTH);
			canvas.drawBitmap(ind02, m, null);
			break;
		case 2:
			if (ind01 != null && !ind01.isRecycled())
				ind01.recycle();
			ind01 = readBitmap(getResources(), R.drawable.alarm_ind01_off);
			m = new Matrix();
			m.setScale(fScale, fScale);
			m.postTranslate((float) getWidth() * 190 / ORG_SCREEN_WIDTH,
					(float) getWidth() * 20 / ORG_SCREEN_WIDTH);
			canvas.drawBitmap(ind01, m, null);

			if (ind02 != null && !ind02.isRecycled())
				ind02.recycle();
			ind02 = readBitmap(getResources(), R.drawable.alarm_ind02_on);
			m = new Matrix();
			m.setScale(fScale, fScale);
			m.postTranslate((float) getWidth() * 250 / ORG_SCREEN_WIDTH,
					(float) getWidth() * 20 / ORG_SCREEN_WIDTH);
			canvas.drawBitmap(ind02, m, null);
			break;
		}
	}

	public void drawDegitalWatch(Canvas canvas) {
    	if(degital_watch_bg != null && !degital_watch_bg.isRecycled()) degital_watch_bg.recycle();
		degital_watch_bg = readBitmap(getResources(), R.drawable.degital_watch_bg);
		Matrix m = new Matrix();
        m.setScale(fScale, fScale);
        m.postTranslate((float)getWidth() * 12 / ORG_SCREEN_WIDTH, (float)getWidth() * 82 / ORG_SCREEN_WIDTH);
        canvas.drawBitmap(degital_watch_bg, m, null); 
        
        if(bAlarmIcon)
        {
        	canvas.drawText(mNextAlarmText, (float)getWidth() * 42 / ORG_SCREEN_WIDTH, (float)getWidth() * 149 / ORG_SCREEN_WIDTH, mAlarmFontPaint);
        }
        else
        {
        	// -- : --
        	canvas.drawText(mNextAlarmText, (float)getWidth() * 46 / ORG_SCREEN_WIDTH, (float)getWidth() * 145 / ORG_SCREEN_WIDTH, mAlarmFontPaint);
        }
	}

	public void drawWatch(Canvas canvas, int WatchResId) {
		if (watch_bg != null && !watch_bg.isRecycled())
			watch_bg.recycle();
		watch_bg = readBitmap(getResources(), WatchResId);
		Matrix m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * -15 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 165 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(watch_bg, m, null);

		if (watch_arrow_l != null && !watch_arrow_l.isRecycled())
			watch_arrow_l.recycle();
		watch_arrow_l = readBitmap(getResources(), R.drawable.watch_arrow_l);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * -15 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 165 / ORG_SCREEN_WIDTH);
		m.preRotate(mMinutes / 60.0f * 360.0f,
				(float) watch_arrow_l.getWidth() / 2,
				(float) watch_arrow_l.getHeight() / 2);
		canvas.drawBitmap(watch_arrow_l, m, null);

		if (watch_arrow_s != null && !watch_arrow_s.isRecycled())
			watch_arrow_s.recycle();
		watch_arrow_s = readBitmap(getResources(), R.drawable.watch_arrow_s);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * -15 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 165 / ORG_SCREEN_WIDTH);
		m.preRotate(mHour / 12.0f * 360.0f,
				(float) watch_arrow_s.getWidth() / 2,
				(float) watch_arrow_s.getHeight() / 2);
		canvas.drawBitmap(watch_arrow_s, m, null);

		if (watch_point != null && !watch_point.isRecycled())
			watch_point.recycle();
		watch_point = readBitmap(getResources(), R.drawable.watch_point);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * -15 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 165 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(watch_point, m, null);

	}
	
	public void drawCopyRight(Canvas canvas, int time) {
		switch(time)
		{
			case 1:
				if (copyright01 != null && !copyright01.isRecycled())
					copyright01.recycle();
				copyright01 = readBitmap(getResources(), R.drawable.copyright01);
				Matrix m = new Matrix();
				m.setScale(fScale, fScale);
				m.postTranslate((float) getWidth() * 380 / ORG_SCREEN_WIDTH,
						(float) getWidth() * 640 / ORG_SCREEN_WIDTH);
				canvas.drawBitmap(copyright01, m, null);
				break;
			case 2:
				if (copyright02 != null && !copyright02.isRecycled())
					copyright02.recycle();
				copyright02 = readBitmap(getResources(), R.drawable.copyright02);
				m = new Matrix();
				m.setScale(fScale, fScale);
				m.postTranslate((float) getWidth() * 380 / ORG_SCREEN_WIDTH,
						(float) getWidth() * 640 / ORG_SCREEN_WIDTH);
				canvas.drawBitmap(copyright02, m, null);
				break;
			case 3:
				if (copyright03 != null && !copyright03.isRecycled())
					copyright03.recycle();
				copyright03 = readBitmap(getResources(), R.drawable.copyright03);
				m = new Matrix();
				m.setScale(fScale, fScale);
				m.postTranslate((float) getWidth() * 380 / ORG_SCREEN_WIDTH,
						(float) getWidth() * 650 / ORG_SCREEN_WIDTH);
				canvas.drawBitmap(copyright03, m, null);
				break;
		}
	}
	
	public void drawWatchIcon(Canvas canvas) {
		if (bAlarmIcon) {
			if (alarm_icon != null && !alarm_icon.isRecycled())
				alarm_icon.recycle();
			alarm_icon = readBitmap(getResources(), R.drawable.alarm_icon);
			Matrix m = new Matrix();
			m.setScale(fScale, fScale);
			m.postTranslate((float) getWidth() * 45 / ORG_SCREEN_WIDTH,
					(float) getWidth() * 165 / ORG_SCREEN_WIDTH);
			canvas.drawBitmap(alarm_icon, m, null);
		}
	}

	private void onTimeChanged() {
		mCalendar.setToNow();
		int hour = mCalendar.hour;
		int minute = mCalendar.minute;
		int second = mCalendar.second;

		mMinutes = minute + second / 60.0f;
		mHour = hour + mMinutes / 60.0f;
		// mSecond = second;
		//
		if (4 <= mHour && mHour < 12) {
			mTime = 1;
		} else if (12 <= mHour && mHour < 20) {
			mTime = 2;
		} else if ((20 <= mHour && mHour <= 24) || (0 <= mHour && mHour < 4)) {
			mTime = 3;
		}
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////

	public void drawTimerView(Canvas canvas) {
		Matrix m = null;
		paint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
		canvas.drawPaint(paint);
		paint.setXfermode(new PorterDuffXfermode(Mode.SRC));

		drawBgImg(canvas, R.drawable.timer_bg, 0, 0);

		drawTabIndex(canvas, 2);

		if (timer_countdown != null && !timer_countdown.isRecycled())
			timer_countdown.recycle();
		timer_countdown = readBitmap(getResources(), R.drawable.timer_frame);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 30 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 65 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(timer_countdown, m, null);

		if (!Utils.TIMER.equals("00:00:00") && Utils.TIMER_STATUS.equals("ON")) {
			mTimerFontPaint.setColor(RED_TEXT_COLOR);
			if (timer_button != null && !timer_button.isRecycled())
				timer_button.recycle();
			timer_button = readBitmap(getResources(), R.drawable.timer_stop_btn);
			m = new Matrix();
			m.setScale(fScale, fScale);
			m.postTranslate((float) getWidth() * 150 / ORG_SCREEN_WIDTH,
					(float) getWidth() * 180 / ORG_SCREEN_WIDTH);
			canvas.drawBitmap(timer_button, m, null);

			if (timer_anime_chara01_timecount == 0) {
				if (timer_anime_chara01Pos == timer_anime_chara01.length)
					timer_anime_chara01Pos = 0;
				timer_anime_chara01Pos++;
				timer_anime_chara01_timecount = timer_anime_chara01_time[timer_anime_chara01Pos - 1];
			}
			timer_anime_chara01_timecount = timer_anime_chara01_timecount - 100;

			if (timer_anime_chara02_timecount == 0) {
				if (timer_anime_chara02Pos == timer_anime_chara02.length)
					timer_anime_chara02Pos = 0;
				timer_anime_chara02Pos++;
				timer_anime_chara02_timecount = timer_anime_chara02_time[timer_anime_chara02Pos - 1];
			}
			timer_anime_chara02_timecount = timer_anime_chara02_timecount - 100;
		} else {
			if (timer_button != null && !timer_button.isRecycled())
				timer_button.recycle();
			timer_button = readBitmap(getResources(),
					R.drawable.timer_start_btn);
			m = new Matrix();
			m.setScale(fScale, fScale);
			m.postTranslate((float) getWidth() * 150 / ORG_SCREEN_WIDTH,
					(float) getWidth() * 180 / ORG_SCREEN_WIDTH);
			canvas.drawBitmap(timer_button, m, null);

			mTimerFontPaint.setColor(BLUE_TEXT_COLOR);
		}
		canvas.drawText(Utils.TIMER, (float) getWidth() / 2, (float) getWidth()
				* 150 / ORG_SCREEN_WIDTH, mTimerFontPaint);

		if (timer_chara01 != null && !timer_chara01.isRecycled())
			timer_chara01.recycle();
		timer_chara01 = readBitmap(getResources(),
				timer_anime_chara01[(timer_anime_chara01Pos - 1 < 0 ? 0 : timer_anime_chara01Pos - 1)]);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 50 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 230 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(timer_chara01, m, null);

		if (timer_chara02 != null && !timer_chara02.isRecycled())
			timer_chara02.recycle();
		timer_chara02 = readBitmap(getResources(), timer_anime_chara02[(timer_anime_chara02Pos - 1 < 0 ? 0
				: timer_anime_chara02Pos - 1)]);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 44 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 235 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(timer_chara02, m, null);
		
		if (timer_item != null && !timer_item.isRecycled())
			timer_item.recycle();
		timer_item = readBitmap(getResources(), R.drawable.timer_itembg);
		m = new Matrix();
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * 0 / ORG_SCREEN_WIDTH,
				(float) getWidth() * 645 / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(timer_item, m, null);
	}

	public static Bitmap readBitmap(Resources r, int resId) {
		BitmapFactory.Options opt = new BitmapFactory.Options();
		opt.inPreferredConfig = Bitmap.Config.RGB_565;
		opt.inPurgeable = true;
		opt.inInputShareable = true;
		InputStream is = r.openRawResource(resId);
		return BitmapFactory.decodeStream(is, null, opt);
	}

	private void drawBgImg(Canvas canvas, int ResId, int x, int y) {
		if (bgimg != null && !bgimg.isRecycled())
			bgimg.recycle();
		bgimg = readBitmap(getResources(), ResId);
		Matrix m = new Matrix();
		fScale = (float) getWidth() / ORG_SCREEN_WIDTH;
		m.setScale(fScale, fScale);
		m.postTranslate((float) getWidth() * x / ORG_SCREEN_WIDTH,
				(float) getWidth() * y / ORG_SCREEN_WIDTH);
		canvas.drawBitmap(bgimg, m, null);
	}

	public static float px2pxByHVGA(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return ((pxValue + 0.5f) * scale + 0.5f);
	}

	private void setTimerFontPaint() {
		mTimerFontType = Typeface.createFromAsset(getContext().getAssets(),
				"fonts/clock_SHOWG.ttf");
		mTimerFontPaint.setTextSize(px2pxByHVGA(getContext(), 48));
		mTimerFontPaint.setTextAlign(Align.CENTER);
		mTimerFontPaint.setTypeface(mTimerFontType);
	}

	private void setAlarmFontPaint() {
		mAlarmFontType = Typeface.createFromAsset(getContext().getAssets(),
				"fonts/clock_SHOWG.ttf");
		mAlarmFontPaint.setTextSize(px2pxByHVGA(getContext(), 28));
		mAlarmFontPaint.setColor(ALARM_TEXT_COLOR);
		mAlarmFontPaint.setTypeface(mAlarmFontType);
	}

	public MainTabView(Context context, AttributeSet attr) {
		super(context, attr);
		holder = getHolder();
		holder.addCallback(this);

		//setZOrderOnTop(true);
		getHolder().setFormat(PixelFormat.TRANSLUCENT);
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {

	}

	public void surfaceCreated(SurfaceHolder holder) {
		bLoop = true;
		setTimerFontPaint();
		setAlarmFontPaint();
		new Thread(new MyLoop()).start();
	}

	public void surfaceDestroyed(SurfaceHolder holder) {
		bLoop = false;
	}

	public void doDraw(Canvas canvas) {
		super.onDraw(canvas);

		switch (Utils.TAB_ID) {
		case 1:
			drawAlarmView(canvas);
			break;
		case 2:
			drawTimerView(canvas);
			break;
		}
	}

	class MyLoop implements Runnable {
		public void run() {
			while (bLoop) {
				try {
					Canvas c = holder.lockCanvas();
					doDraw(c);
					holder.unlockCanvasAndPost(c);
					Thread.sleep(10);
				} catch (Exception e) {

				}
			}
		}

	}

}
