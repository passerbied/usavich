package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01;

import java.util.ArrayList;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.City;
import jp.primeworks.android.flamingo.activity.FlamingoActivity;

import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class SettingActivity extends FlamingoActivity implements
		android.view.View.OnClickListener {
	public static final String TAG = "SettingActivity";

	private static final int DLG_CITY = 1;
	private static final int DLG_UPDATE = 2;
	public static final long[] RATES = { 3 * 60 * 60 * 1000,
			6 * 60 * 60 * 1000, 12 * 60 * 60 * 1000, 24 * 60 * 60 * 1000, };

	private Context mContext;
	private TextView mUpdateTV;
	private TextView mCityTV;

	private ArrayList<City> mCities;
	private City mCurrCity;

	private long mUpdateRate;

	private String[] mUpdateStrings;
	private String[] mCityStrings;

	private int mIndexCity = 11;
	private int mIndexRate = 1;
	
	static SettingActivity INSTANCE;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.setting);
		mContext = SettingActivity.this;
		
		INSTANCE = this;

		initControlViews();

		commonInit();
		
	}

	private void initControlViews() {
		Typeface cTypeface = Typeface.createFromAsset(
				mContext.getResources().getAssets(),
				"fonts/settings_A-OTF-ShinMGoPro-Medium.otf");

		Button backBtn = (Button) findViewById(R.id.btn_setting_back);
		backBtn.setOnClickListener(this);
		backBtn.setTypeface(cTypeface);
		
		TextView title = (TextView) findViewById(R.id.textview_setting_title);
		title.setTypeface(cTypeface);
		
		findViewById(R.id.llayout_setting_city).setOnClickListener(this);
		findViewById(R.id.llayout_setting_update).setOnClickListener(this);

		mCityTV = (TextView) findViewById(R.id.tv_setting_currcity);
		mUpdateTV = (TextView) findViewById(R.id.tv_setting_updaterate);
	}

	private void commonInit() {
		mCurrCity = Utils.getCity(mContext);
		mCities = Utils.getAllCities();
		mCityStrings = new String[mCities.size()];
		mCityTV.setText(getShowingCity(Utils.getCity(mContext)));

		mUpdateRate = Utils.getUpdateRate();
		mUpdateTV.setText(getShowingUpdateRate(mUpdateRate));
	}

	private String getShowingUpdateRate(long millis) {
		mUpdateStrings = getResources().getStringArray(R.array.update_rate);
		String rateString = "更新間隔：";
		if (millis == 0) {
			mIndexRate = 0;
			rateString += mUpdateStrings[0];
		} else {
			for (int i = 0; i < RATES.length; i++) {
				if (RATES[i] == millis) {
					mIndexRate = i + 1;
				}
			}
			rateString += mUpdateStrings[mIndexRate];
		}
		return rateString;
	}

	private String getShowingCity(City city) {
		int size = mCities.size();
		for (int i = 0; i < size; i++) {
			String name = mCities.get(i).getName();
			mCityStrings[i] = name;
			if (city.getName().equals(name)) {
				mIndexCity = i;
			}
		}
		return "地域：" + city.getName();
	}

	protected Dialog createDlg(int id) {
		Builder builder = new Builder(mContext);
		switch (id) {
		case DLG_UPDATE:
			builder.setTitle("更新間隔");
			builder.setNegativeButton(R.string.cancel, null);

			builder.setSingleChoiceItems(mUpdateStrings, mIndexRate,
					new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							mUpdateRate = (which == 0 ? 0 : RATES[which - 1]);
							String text = "更新間隔：" + mUpdateStrings[which];
							mUpdateTV.setText(text);
							dialog.dismiss();
						}
					});
			break;
		case DLG_CITY:
			builder.setTitle("地域");
			builder.setNegativeButton(R.string.cancel, null);
			builder.setSingleChoiceItems(mCityStrings, mIndexCity,
					new OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							mCurrCity = mCities.get(which);
							mCityTV.setText(getShowingCity(mCurrCity));
							dialog.dismiss();
						}
					});
			break;
		default:
			break;
		}
		return builder.create();
	}
	
	private void returnMain() {
		boolean isChanged = false;
		if (mCurrCity != Utils.getCity(mContext)
				|| mUpdateRate != Utils.getUpdateRate()) {
			isChanged = true;
		}
		Utils.setCity(mContext, mCurrCity);
		Utils.setUpdateRate(mContext, mUpdateRate);
		Intent intent = new Intent();
		intent.setAction(getPackageName() + "/SettingChanged");
		intent.putExtra(Utils.SETTING_CHANGED, isChanged);
		sendBroadcast(intent);
		finish();
	}

//	@Override
//	public void onAttachedToWindow() {
//		getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
//		super.onAttachedToWindow();
//	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
//		if (keyCode == KeyEvent.KEYCODE_HOME) {
//			Intent intent = new Intent(this, WeatherActivity.class);
//			intent.putExtra("need-finish", true);
//			setResult(1, intent);
//			this.finish();
//			return true;
//		} else if (keyCode == KeyEvent.KEYCODE_BACK) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			returnMain();
			return true;
//			returnMain();
//			return true;
		} else {
			return super.onKeyDown(keyCode, event);
		}
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_setting_back:
			returnMain();
			break;
		case R.id.llayout_setting_city:
			showSettingDialog(DLG_CITY);
			break;
		case R.id.llayout_setting_update:
			showSettingDialog(DLG_UPDATE);
			break;
		default:
			break;
		}
	}

	private void showSettingDialog(int dlgId) {
		Dialog dialog = createDlg(dlgId);
		dialog.show();
		dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
		dialog.setOnKeyListener(new android.content.DialogInterface.OnKeyListener() {

			@Override
			public boolean onKey(DialogInterface dialog, int keyCode,
					KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_HOME) {
					dialog.dismiss();
					Intent intent = new Intent(SettingActivity.this, WeatherActivity.class);
					intent.putExtra("need-finish", true);
					setResult(1, intent);
//					SettingActivity.this.finish();
					return true;
				}
				return false;
			}
		});
	}
	
	@Override
	protected void onDestroy() {
		INSTANCE = null;
		super.onDestroy();
	}
}