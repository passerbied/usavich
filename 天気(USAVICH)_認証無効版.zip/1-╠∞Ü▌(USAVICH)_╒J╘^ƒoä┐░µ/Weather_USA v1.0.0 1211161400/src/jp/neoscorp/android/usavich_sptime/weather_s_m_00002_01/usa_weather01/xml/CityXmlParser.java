package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.xml;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.City;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.content.Context;
import android.util.Xml;


public class CityXmlParser {
	public static final String TAG = "XmlParser";

	private XmlPullParser mParser;
	private Context mContext;

	public CityXmlParser(Context context) {
		mParser = Xml.newPullParser();
		mContext = context;
	}

	public ArrayList<City> getCities() {
		ArrayList<City> cities = null;
		City city = null;
		int eventType;
		try {
			InputStream is = mContext.getResources().getAssets()
					.open("xml/cityinfos.xml");
			mParser.setInput(is, "utf-8");
			eventType = mParser.getEventType();
			while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.START_DOCUMENT:
					cities = new ArrayList<City>();
					break;
				case XmlPullParser.START_TAG:
					String tag = mParser.getName();
					if (tag.equals(City.CITY_TAG)) {
						city = new City();
					} else if (tag.equals(City.ID)) {
						city.setId(Integer.parseInt(mParser.nextText()));
					} else if (tag.equals(City.NAME)) {
						city.setName(mParser.nextText());
					} else if (tag.equals(City.CODE)) {
						city.setCode(mParser.nextText());
					} else if (tag.equals(City.AREA)) {
						city.setArea(Integer.parseInt(mParser.nextText()));
					}
					break;
				case XmlPullParser.END_TAG:
					if (mParser.getName().equals(City.CITY_TAG)) {
						cities.add(city);
					}
					break;
				default:
					break;
				}
				eventType = mParser.next();
			}
//			Log.d(TAG, "Total size: " + cities.size());
			return cities;
		} catch (XmlPullParserException e) {
//			Log.e(TAG, "XmlPullParser Error !!! ");
		} catch (NumberFormatException e) {
//			Log.e(TAG, "NumberFormat Error !!! ");
		} catch (IOException e) {
//			Log.e(TAG, "IOException.");
		}
//		Log.e(TAG, "Can't get city list!!!");
		return null;
	}
}