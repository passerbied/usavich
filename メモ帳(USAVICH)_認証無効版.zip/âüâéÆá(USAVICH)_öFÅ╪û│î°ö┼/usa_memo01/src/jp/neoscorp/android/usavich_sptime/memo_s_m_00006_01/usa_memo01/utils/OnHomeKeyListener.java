package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.app.Activity;
	public class OnHomeKeyListener{
	private boolean isTesting;
	public boolean isTesting() {
		return isTesting;
	}
	public void setTesting(boolean isTesting) {
		this.isTesting = isTesting;
	}
	private Context mContext;
	public void threadRun(Context context)
	{
		mContext = context;
		new CatchLogThread().start();
	}
	class CatchLogThread extends Thread {
		@Override    
	      public void run() {    
	          Process mLogcatProc = null;    
	          BufferedReader reader = null;    
	           String line;    
	           while (isTesting) {    
	               try {    
	                   mLogcatProc = Runtime.getRuntime().exec(new String[] { "logcat", "ActivityManager:I *:S" });    
	                   reader = new BufferedReader(new InputStreamReader(mLogcatProc.getInputStream()),2*1024);    
	                   while ((line = reader.readLine()) != null) {    
	                       if (line.indexOf("android.intent.category.HOME") > 0) {    
	                           isTesting = false;    
	                           handler.sendMessage(handler.obtainMessage());     
	                         Runtime.getRuntime().exec("logcat -c");   
	                          break;    
	                      }     
	                  }    
	               } catch (Exception e) {    
	                   e.printStackTrace();    
	               }    
	           }    
	      }    
	};
		Handler handler = new Handler() {
			public void handleMessage(android.os.Message msg) {
				Log.i(" Home key======================================","Home key press");
				//do something here
				((Activity)mContext).finish();
			};
		};
	}
