package jp.primeworks.android.flamingo.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.OnCreateContextMenuListener;

/**
 * Flamingo Fragment Activity.
 * 
 * @author takimura
 * @see FlamingoActivityHook
 */
public abstract class FlamingoFragmentActivity extends FragmentActivity {

    /**
     * Activity hook.
     */
	private FlamingoActivityHook mHook;

	/**
	 * Callback activity create.
	 * 
	 * @param savedInstanceState
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mHook = new FlamingoActivityHook(this);
	}

	/**
	 * Callback create option menu.
	 * 
	 * @param menu option menu
	 */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        return mHook.onHookCreateOptionsMenu(menu);
    }

    /**
     * Callback option menu item selected.
     * 
     * @param item selected menu item
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        return mHook.onHookOptionsItemSelected(item);
    }

    /**
     * Callback create dialog.
     * 
     * @param id dialog id
     */
    @Override
    protected Dialog onCreateDialog(int id) {
    	return mHook.onHookCreateDialog(id);
    }

    /**
     * Callback create FlamingoAuctivityHook.
     * 
     * @return FlamingoActivityHook
     */
    public FlamingoActivityHook onCreateFlamingoActivityHook() {
        return new FlamingoActivityHook(this);
    }

    /**
     * Set activity hook.
     * @param hook Activity Hook instance
     * @deprecated Use {@link OnCreateContextMenuListener}
     */
    public void setActivityHook(FlamingoActivityHook hook) {
        mHook = hook;
    }

    /**
     * 月額対応認証を開始する.
     */
    public void authorize() {
        mHook.authorize();
    }

    public boolean isValidApplication() {
        return mHook.isValidApplication();
    }

    /**
     * Get authorize status.
     * 
     * @return
     */
    public boolean isAuthorizing() {
    	return mHook.mAuthorizing;
    }

    /**
     * Get authorize error is happened or not.
     * @return
     */
    public boolean isAuthorizeError() {
    	return mHook.mAuthError;
    }

}
