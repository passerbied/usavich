package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import java.util.ArrayList;


import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SystemBootReceiver extends BroadcastReceiver 
{
	private String nextAlarm, alarmId, nextTime;
	private ArrayList<String> alarm;
	
	public void onReceive(Context context, Intent intent) 
	{ 		
		if(intent.getAction().equals("android.intent.action.BOOT_COMPLETED"))
		 {
				Intent serviceLauncher = new Intent(context, Service.class);
				context.startService(serviceLauncher);
				
				alarm = Alarm.getNextAlarmTimeData(context); 
				
		        nextAlarm = alarm.get(0);
		        alarmId   = alarm.get(1);
		        nextTime  = alarm.get(2);
		        
		        if(!nextAlarm.equals("-- : --"))
		        {
		        	Alarm.sendAlarm(context, alarmId, Long.parseLong(nextTime));
		        	Alarm.setNotification(context);
		        }
		  }
	}
}
