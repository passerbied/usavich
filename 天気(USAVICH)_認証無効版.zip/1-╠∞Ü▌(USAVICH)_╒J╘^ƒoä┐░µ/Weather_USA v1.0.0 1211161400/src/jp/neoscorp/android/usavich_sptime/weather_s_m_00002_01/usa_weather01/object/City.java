package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object;

public class City {
	public static final String CITY_TAG = "city";

	public static final String ID = "id";
	public static final String NAME = "name";
	public static final String CODE = "code";
	public static final String AREA = "area";

	private int mId;
	private String mName;
	private String mCode;
	private int mArea;

	public City() {
	}

	public City(int id, String name, String code, int area) {
		mId = id;
		mName = name;
		mCode = code;
		mArea = area;
	}

	public int getId() {
		return mId;
	}

	public void setId(int id) {
		mId = id;
	}

	public String getName() {
		return mName;
	}

	public void setName(String name) {
		mName = name;
	}

	public String getCode() {
		return mCode;
	}

	public void setCode(String code) {
		mCode = code;
	}

	public int getArea() {
		return mArea;
	}

	public void setArea(int area) {
		mArea = area;
	}

	@Override
	public String toString() {
		return "City id: " + getId() + " ,name: " + getName() + ", code:"
				+ getCode() + ", area:" + getArea();
	}
}
