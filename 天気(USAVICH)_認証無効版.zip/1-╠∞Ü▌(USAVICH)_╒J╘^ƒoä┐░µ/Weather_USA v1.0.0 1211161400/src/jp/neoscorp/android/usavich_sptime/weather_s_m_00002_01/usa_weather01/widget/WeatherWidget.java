package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.widget;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.Utils;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

public class WeatherWidget extends AppWidgetProvider {

	@Override
	public void onEnabled(Context context) {
		super.onEnabled(context);
		// Utils.startService(context);
	}

	@Override
	public void onUpdate(final Context context,
			AppWidgetManager appWidgetManager, int[] appWidgetIds) {
		super.onUpdate(context, appWidgetManager, appWidgetIds);
		// Utils.initInfos(context);
		// Utils.updateWidget(context);
		// Utils.startService(context);
		Utils.initInfos(context);
		Utils.startService(context);
		// Flamingo flamingo = new Flamingo(context);
		// if (flamingo.isValidApplication()) {
		// new Thread(new Runnable() {
		//
		// @Override
		// public void run() {
		// try {
		// Thread.sleep(5000);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		// Utils.updateWidget(context);
		// }
		// }).start();
		// }
	}

	@Override
	public void onReceive(final Context context, Intent intent) {
		super.onReceive(context, intent);
		String action = intent.getAction();
		if (Utils.getWidgetIds(context).length > 0) {
			if (action.equals("android.intent.action.BOOT_COMPLETED")) {
				Utils.startService(context);
			} else {
				new Thread(new Runnable() {

					@Override
					public void run() {
						try {
							Thread.sleep(5000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						Utils.startService(context);
					}
				}).start();
			}
		}
	}

	@Override
	public void onDisabled(Context context) {
		Utils.stopService(context);
		super.onDisabled(context);
	}
}