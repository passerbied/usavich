 package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.R;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import jp.primeworks.android.flamingo.activity.FlamingoFragmentActivity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

public class AlarmOptionActivity extends FlamingoFragmentActivity 
{
	public static String APP_CLOSE_ACTION = "com.taiyo.clock.action.APP_CLOSE_ACTION";
	public static String TIMER_STOP_ACTION = "com.taiyo.clock.action.TIMER_STOP_ACTION";
	public static String ALARM_UPDATE_ACTION = "com.taiyo.clock.action.ALARM_UPDATE_ACTION";
	private Button mBackBtn, mDelBtn;
	private boolean mIsEditMode = false, mbAlarmOnOff = false, mbAlarmOnOffOld = false, mbVibrate = false, mbDialogStatus = false;
	private String mAlarmId, mAlarmTime, mAlarmLabel, mSoundName = "", mSoundPath = "", mSnoozeValue = "", mSnoozeValueId = "";
	private AlarmDataBaseAdapter mAlarmDB;
	private TextView mAlarmTimeItem, mAlarmWeekItem, mAlarmSnoozeItem, mAlarmSoundItem, mAlarmOptionTitle;
	private CheckBox mAlarmOnOffItem, mAlarmVibrateItem;
	private EditText mAlarmTitleItem;
	private CommonReceiver mCommonReceiver;
	private boolean mbBackBtnActionStatus = false; 
	private List<String> mSoundNameList = new ArrayList<String>();
	private static MediaPlayer mMediaPlayer;
	private static Uri mSoundUri;
	private static int mSoundSelectId = 0;
	private TimePicker picker;
	private LinearLayout mAlarmOption, mSoundOption, mSnoozeOption, mWeekOption;
	private Dialog timeDialog = null, snoozeDialog = null, weekDialog = null, soundDialog = null, deleteDialog = null;
	private final boolean[] mWeekValue = { false, false, false, false, false, false, false };
	private Typeface tf2;
	private ImageView mMainBg;
	private final int ORG_SCREEN_WIDTH = 480; 
	private DisplayMetrics dm;
	private Context mContext;
	
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.alarmoptionview);
		mContext = AlarmOptionActivity.this;
		Utils.MAIN_TAB_SHOW_STATUS = false;
		dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);	
        
		mMainBg = (ImageView) findViewById(R.id.alarmoptionbg);
		tf2 = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/settings_A-OTF-ShinMGoPro-Medium.otf");
	
		mCommonReceiver = new CommonReceiver();
		mCommonReceiver.register();
		mAlarmDB = new AlarmDataBaseAdapter(this);
		mAlarmDB.open();
		
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mDelBtn = (Button) findViewById(R.id.delBtn);
		mAlarmOption =  (LinearLayout) findViewById(R.id.alarmTimeOption);
		mSoundOption = (LinearLayout) findViewById(R.id.soundOption);
		mSnoozeOption = (LinearLayout) findViewById(R.id.snoozeOption);
		mWeekOption =  (LinearLayout) findViewById(R.id.weekOption);
		mAlarmTitleItem = (EditText) findViewById(R.id.alarmtitleitem);
		mAlarmOptionTitle = (TextView) findViewById(R.id.alarmOptionTitle);
		mAlarmTimeItem = (TextView) findViewById(R.id.alarmtimeitem);
		mAlarmWeekItem = (TextView) findViewById(R.id.alarmweekitem);
		mAlarmSnoozeItem = (TextView) findViewById(R.id.alarmsnoozeitem);
		mAlarmSoundItem = (TextView) findViewById(R.id.alarmsounditem);
		mAlarmOnOffItem = (CheckBox) findViewById(R.id.alarmonoffitem);
		mAlarmVibrateItem = (CheckBox) findViewById(R.id.alarmvibrateitem);
		
		mBackBtn.setTypeface(tf2);
		mDelBtn.setTypeface(tf2);
		mAlarmOptionTitle.setTypeface(tf2);
		mAlarmOptionTitle.setTextColor(Color.WHITE);
		mBackBtn.setTextColor(Color.WHITE);
		mDelBtn.setTextColor(Color.WHITE);		
		
		initData();
		initListener();
	}
	
	protected void onResume()
	{
		super.onResume();
		if (Utils.TIMER_STATUS.equals("ON")) 
		{  
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); 
		} 
		else 
		{			
			getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		}
		mMainBg.setImageResource(R.drawable.watch_bg);
		mMainBg.setLayoutParams(getLinearLayoutPararm(0, 0, 480, 854));
	}
	
	private void initData()
	{
		mbBackBtnActionStatus = false; 
		mAlarmId =  getIntent().getStringExtra("alarmId");
		mAlarmTime =  getIntent().getStringExtra("alarmTime");
		mAlarmLabel =  getIntent().getStringExtra("alarmLabel");
		
		mSoundUri = Utils.getRingtoneByUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE,  Utils.getRingtoneUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE, 0, ""));
		if(mSoundUri != null)
		{
			mMediaPlayer = MediaPlayer.create(getApplicationContext(), mSoundUri);   
		}
		
		//編集モード
		if((getIntent().getStringExtra("editMode").equals("EDIT")))
		{
			mIsEditMode = true;
			
			Cursor mCursor = mAlarmDB.selectByAlarmId(Integer.parseInt(mAlarmId));
			mCursor.moveToFirst();
			//
			if(mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_ONOFF)).equals("ON")){
				mAlarmOnOffItem.setChecked(true);
				mbAlarmOnOff = true;
				mbAlarmOnOffOld = true;
			}else{
				mAlarmOnOffItem.setChecked(false);
				mbAlarmOnOff = false;
				mbAlarmOnOffOld = false;
			}
			
			//
			mAlarmTimeItem.setText(mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_HOUR)).trim() + ":" +
								   mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_MINUTES)).trim());			
			//
			mSoundName = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_SOUNDNAME));
			mSoundPath = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_SOUNDPATH));
			mAlarmSoundItem.setText(mSoundName);
			
			//
			if(mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_VIBRATE)).equals("ON")){
				mAlarmVibrateItem.setChecked(true);
				mbVibrate = true;
			}else{
				mAlarmVibrateItem.setChecked(false);
				mbVibrate = false;
			}
			
			//
			mSnoozeValue = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_SNOOZE));
			switch(new Integer(mSnoozeValue))
			{
				case 1:
					mAlarmSnoozeItem.setText("１分");
					mSnoozeValueId = "0";
					break;
				case 3:
					mAlarmSnoozeItem.setText("３分");
					mSnoozeValueId = "1";
					break;
				case 5:
					mAlarmSnoozeItem.setText("５分");
					mSnoozeValueId = "2";
					break;
				case 10:
					mAlarmSnoozeItem.setText("１０分");
					mSnoozeValueId = "3";
					break;
				case 15:
					mAlarmSnoozeItem.setText("１５分");
					mSnoozeValueId = "4";
					break;
				case 20:
					mAlarmSnoozeItem.setText("２０分");
					mSnoozeValueId = "5";
					break;
				case 25:
					mAlarmSnoozeItem.setText("２５分");
					mSnoozeValueId = "6";
					break;
				case 30:
					mAlarmSnoozeItem.setText("３０分");
					mSnoozeValueId = "7";
					break;
			}
			
			//
			mAlarmTitleItem.setText(mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_TITLE)));
			
			//
			String alarmweek = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_WEEK));
			if(!alarmweek.equals(""))
			{
				for(int i = 0; i < alarmweek.split(":").length; i++)
			    {
					mWeekValue[Integer.parseInt(alarmweek.split(":")[i]) - 1] = true;
			    }
			}
			mAlarmWeekItem.setText(mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_WEEKTEXT)));
			if(mAlarmWeekItem.getText().toString().trim().equals("")){
				mAlarmWeekItem.setText("繰り返しなし");
			}
			mCursor.close();
			mCursor = null;
		}
		//新規モード
		else{
			mIsEditMode = false;			
			mAlarmOnOffItem.setChecked(false);
            SimpleDateFormat formatter = new SimpleDateFormat ("HH:mm:ss");
            Date curDate = new Date(System.currentTimeMillis());            
            mAlarmTimeItem.setText(formatter.format(curDate).split(":")[0] + ":" + formatter.format(curDate).split(":")[1]);
            mAlarmWeekItem.setText("繰り返しなし");
            mAlarmSnoozeItem.setText("５分");
            mAlarmSoundItem.setText("サイレント");
            mSnoozeValueId = "2";
		}
	}
	
	private void initListener()
	{
		mBackBtn.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) 
			{
				if(mbBackBtnActionStatus == false)
				{
					mbBackBtnActionStatus = true;
					backBtnAction();
				}
			}
		});
		
		mDelBtn.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				//編集モード
				if((getIntent().getStringExtra("editMode").equals("EDIT")))
				{
					if(mbDialogStatus == false)
					{
						deleteDialog = createDeleteDialog();
						deleteDialog.show(); 
						mbDialogStatus = true;
						deleteDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
						{ 
							public void onDismiss(DialogInterface dialog) { 
								mbDialogStatus = false;	
							} 
						}); 
					}
				}
				//追加モード
				else
				{
					AlarmOptionActivity.this.finish();
				}
			}
		});
		
		mAlarmOption.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				if(mbDialogStatus == false)
				{
					mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
					timeDialog = createTimeDialog();
					timeDialog.show(); 
					timeDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD); 
			        mbDialogStatus = true;
			        
			        timeDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
					{ 
						public void onDismiss(DialogInterface dialog) { 
							mbDialogStatus = false;	
						} 
					}); 
					
			        timeDialog.setOnKeyListener(new android.content.DialogInterface.OnKeyListener()
			        {  
			    	   public boolean onKey(DialogInterface dialog, int keyCode,KeyEvent event) 
			    	   {             	
			    	        switch (keyCode) 
			    	        {  
					          case KeyEvent.KEYCODE_BACK:  
					        	    timeDialog.dismiss();      	
					        	    mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
					        	    mbDialogStatus = false;
				    	            return true;  					        	  
					          case KeyEvent.KEYCODE_HOME: 
					          case KeyEvent.KEYCODE_POWER:
					        	    timeDialog.dismiss();   	
					        	    mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
					        	    mbDialogStatus = false;
					        	    sendBroadcast(new Intent(APP_CLOSE_ACTION));
					        		AlarmOptionActivity.this.finish();
				    	            return true;  
			    	        }  
			    	        return false;  
			    	    }  
			    	}); 
				}
			}
		});
		
		mSoundOption.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				if(mbDialogStatus == false)
				{
					mSoundOption.setBackgroundColor(Color.TRANSPARENT);
					soundDialog = createSoundDialog();
					soundDialog.show(); 
					soundDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD); 
					mbDialogStatus = true;
					soundDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
					{ 
						public void onDismiss(DialogInterface dialog) { 
							mbDialogStatus = false;	
						} 
					}); 
					soundDialog.setOnKeyListener(new android.content.DialogInterface.OnKeyListener()
			        {  
			    	   public boolean onKey(DialogInterface dialog, int keyCode,KeyEvent event) 
			    	   {             	
			    	        switch (keyCode) 
			    	        {  
					          case KeyEvent.KEYCODE_BACK:  
					        	  	soundDialog.dismiss();
									if(mSoundUri != null)
									{
					            		if(mMediaPlayer.isPlaying()){
					            			mMediaPlayer.stop();
					            		}
									}          	
					        	    mSoundOption.setBackgroundColor(Color.TRANSPARENT);
					        	    mbDialogStatus = false;
				    	            return true;  					        	  
					          case KeyEvent.KEYCODE_HOME: 
					          case KeyEvent.KEYCODE_POWER:
					        	  	soundDialog.dismiss();
									if(mSoundUri != null)
									{
					            		if(mMediaPlayer.isPlaying()){
					            			mMediaPlayer.stop();
					            		}
									}          	
					        	    mSoundOption.setBackgroundColor(Color.TRANSPARENT);
					        	    mbDialogStatus = false;
					        	    sendBroadcast(new Intent(APP_CLOSE_ACTION));
					        		AlarmOptionActivity.this.finish();
				    	            return true;  
			    	        }  
			    	        return false;  
			    	    }  
			    	}); 
				}
			}
		});
		
		mSnoozeOption.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				if(mbDialogStatus == false)
				{
					mSnoozeOption.setBackgroundColor(Color.TRANSPARENT);
					snoozeDialog = createSnoozeDialog();
					snoozeDialog.show(); 
					snoozeDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD); 
					mbDialogStatus = true;
					snoozeDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
					{ 
						public void onDismiss(DialogInterface dialog) { 
							mbDialogStatus = false;	
						} 
					});
					snoozeDialog.setOnKeyListener(new android.content.DialogInterface.OnKeyListener()
			        {  
			    	   public boolean onKey(DialogInterface dialog, int keyCode,KeyEvent event) 
			    	   {             	
			    	        switch (keyCode) 
			    	        {  
					          case KeyEvent.KEYCODE_BACK:  
					        	    snoozeDialog.dismiss();      	
					        	    mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
					        	    mbDialogStatus = false;
				    	            return true;  					        	  
					          case KeyEvent.KEYCODE_HOME: 
					          case KeyEvent.KEYCODE_POWER:
					        	    snoozeDialog.dismiss();   	
					        	    mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
					        	    mbDialogStatus = false;
					        	    sendBroadcast(new Intent(APP_CLOSE_ACTION));
					        		AlarmOptionActivity.this.finish();
				    	            return true;  
			    	        }  
			    	        return false;  
			    	    }  
			    	}); 
				}
			}
		});
		
		mWeekOption.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				if(mbDialogStatus == false)
				{
					mWeekOption.setBackgroundColor(Color.TRANSPARENT);
					weekDialog = createWeekDialog();
					weekDialog.show(); 
					weekDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD); 
					mbDialogStatus = true;
					weekDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
					{ 
						public void onDismiss(DialogInterface dialog) { 
							mbDialogStatus = false;	
						} 
					});
					weekDialog.setOnKeyListener(new android.content.DialogInterface.OnKeyListener()
			        {  
			    	   public boolean onKey(DialogInterface dialog, int keyCode,KeyEvent event) 
			    	   {             	
			    	        switch (keyCode) 
			    	        {  
					          case KeyEvent.KEYCODE_BACK:  
					        	    weekDialog.dismiss();      	
					        	    mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
					        	    mbDialogStatus = false;
				    	            return true;  					        	  
					          case KeyEvent.KEYCODE_HOME: 
					          case KeyEvent.KEYCODE_POWER:
					        	    weekDialog.dismiss();   	
					        	    mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
					        	    mbDialogStatus = false;
					        	    sendBroadcast(new Intent(APP_CLOSE_ACTION));
					        		AlarmOptionActivity.this.finish();
				    	            return true;  
			    	        }  
			    	        return false;  
			    	    }  
			    	}); 
				}
			}
		});
		
		mAlarmOnOffItem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					mbAlarmOnOff = true;
				} else {
					mbAlarmOnOff = false;
				}
			}
		});
		
		mAlarmVibrateItem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					mbVibrate = true;
				} else {
					mbVibrate = false;
				}
			}
		});	
	}
	
	private void backBtnAction()
	{
		boolean bAlarmSetError = true;
        
        //編集モード
		if(mIsEditMode)
		{
			Alarm.editAlarm(
					mContext,
				    Integer.parseInt(mAlarmId),
				   (mAlarmTitleItem.getText().toString().trim()).equals("") ? "アラーム" : mAlarmTitleItem.getText().toString(),		
				   (mAlarmTimeItem.getText().toString()).split(":")[0].trim(), 
				   (mAlarmTimeItem.getText().toString()).split(":")[1].trim(), 
	               "00", 
	               mWeekValue,
	               mbAlarmOnOff  == true ? "ON" : "OFF",
	               mAlarmSoundItem.getText().toString().trim().equals("") ? "" : mAlarmSoundItem.getText().toString().trim(), 
				   mSoundPath.equals("") ? "" : mSoundPath, 
				   mbVibrate == true ? "ON" : "OFF",
				   mSnoozeValue.equals("") ? "5" : mSnoozeValue);
		
			String aHour = (mAlarmTimeItem.getText().toString()).split(":")[0].trim();
			String aMinutes = (mAlarmTimeItem.getText().toString()).split(":")[1].trim();
			
			//OFF TO ON
			if(mbAlarmOnOffOld == false && mbAlarmOnOff == true)
			{
				Alarm.alarmOffToOn(mContext, mAlarmId, aHour,  aMinutes, Alarm.getWeekText(mWeekValue));
			}
			//ON TO OFF
			else if(mbAlarmOnOffOld == true && mbAlarmOnOff == false)
			{
				Alarm.alarmOnToOff(mContext, mAlarmId);
			}
			//ON TO ON
			else if(mbAlarmOnOffOld == true && mbAlarmOnOff == true)
			{
				Alarm.alarmOnToOn(mContext, mAlarmId);
			}
		}
		//追加モード
		else
		{
			Alarm.addAlarm(
					   mContext,
					   (mAlarmTitleItem.getText().toString().trim()).equals("") ? "アラーム" : mAlarmTitleItem.getText().toString(),		
					   (mAlarmTimeItem.getText().toString()).split(":")[0].trim(), 
					   (mAlarmTimeItem.getText().toString()).split(":")[1].trim(), 
		               "00", 
		               mWeekValue,
		               mbAlarmOnOff  == true ? "ON" : "OFF",
		               mAlarmSoundItem.getText().toString().trim().equals("") ? "" : mAlarmSoundItem.getText().toString().trim(), 
					   mSoundPath.equals("") ? "" : mSoundPath, 
					   mbVibrate == true ? "ON" : "OFF",
					   mSnoozeValue.equals("") ? "5" : mSnoozeValue);
							
			if(Alarm.IsHaveSkipIdNotification(mContext, mAlarmDB.selectMaxAlarmId())){
			}
			else if(mbAlarmOnOff == true){
				Alarm.setNotification(mContext);
			}
			
			ArrayList<String> alarm = Alarm.getNextAlarmTimeData(mContext); 
	        String alarmId   = alarm.get(1);
	        String nextTime  = alarm.get(2);
			
			if(("" + mAlarmDB.selectMaxAlarmId()).equals(alarmId))
			{
				Alarm.sendAlarm(mContext, alarmId, Long.parseLong(nextTime));
			}
		}
		
		if(bAlarmSetError)
		{
			Intent intentNextAlarmTime = new Intent(ALARM_UPDATE_ACTION);
			intentNextAlarmTime.putExtra("nextalarmtime", mAlarmTimeItem.getText().toString());
			sendBroadcast(intentNextAlarmTime);
			AlarmOptionActivity.this.finish();
		}
	}
	
	private Dialog createTimeDialog()
	{
		Dialog dialog = null;
		Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null);
        builder.setTitle("時刻");
        
        LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
        View view = inflater.inflate(R.layout.timepicker, null); 
        builder.setView(view);
        
        picker = (TimePicker) view.findViewById(R.id.time_picker);
		picker.setIs24HourView(true);
	
		String aHour = (mAlarmTimeItem.getText().toString()).split(":")[0].trim();
		String aMinutes = (mAlarmTimeItem.getText().toString()).split(":")[1].trim();
		
		picker.setCurrentHour(Integer.parseInt(aHour));
		picker.setCurrentMinute(Integer.parseInt(aMinutes));
		
        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	picker.clearFocus();
            	mAlarmOption.setBackgroundColor(Color.TRANSPARENT);
            	mAlarmTimeItem.setText(Utils.formartDigits(picker.getCurrentHour().intValue()) + " : " + Utils.formartDigits(picker.getCurrentMinute().intValue()));
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        dialog = builder.create();
        
        return dialog;
	}
	
	private Dialog createSnoozeDialog()
	{
		Dialog dialog = null;
		Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null);
        builder.setTitle("スヌーズ");
        builder.setSingleChoiceItems(
        		R.array.snoozeitem, Integer.valueOf(mSnoozeValueId), 
        	new DialogInterface.OnClickListener()
        	{
        		public void onClick(DialogInterface dialog, int which) {
        			String snoozeValueTemp = getResources().getStringArray(R.array.snoozeitem)[which];
        			
        			if(snoozeValueTemp.equals("１分")){
        				mSnoozeValue = "1";
        			}
        			else if(snoozeValueTemp.equals("３分")){
        				mSnoozeValue = "3";
        			}	
        			else if(snoozeValueTemp.equals("５分")){
        				mSnoozeValue = "5";
        			}	
        			else if(snoozeValueTemp.equals("１０分")){
        				mSnoozeValue = "10";
        			}	
        			else if(snoozeValueTemp.equals("１５分")){
        				mSnoozeValue = "15";
        			}	
        			else if(snoozeValueTemp.equals("２０分")){
        				mSnoozeValue = "20";
        			}	
        			else if(snoozeValueTemp.equals("２５分")){
        				mSnoozeValue = "25";
        			}	
        			else if(snoozeValueTemp.equals("３０分")){
        				mSnoozeValue = "30";
        			}
        			
        			mSnoozeValueId = new Integer(which).toString();
            }
        });
        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	mSnoozeOption.setBackgroundColor(Color.TRANSPARENT);
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	mSnoozeOption.setBackgroundColor(Color.TRANSPARENT);
            	
            	switch(new Integer(mSnoozeValueId))
            	{
                	case 0:
	                	mAlarmSnoozeItem.setText("１分");
                		break;
                	case 1:
	                	mAlarmSnoozeItem.setText("３分");
                		break;
                	case 2:
	                	mAlarmSnoozeItem.setText("５分");
                		break;
                	case 3:
	                	mAlarmSnoozeItem.setText("１０分");
                		break;
                	case 4:
	                	mAlarmSnoozeItem.setText("１５分");
                		break;
                	case 5:
	                	mAlarmSnoozeItem.setText("２０分");
                		break;
                	case 6:
	                	mAlarmSnoozeItem.setText("２５分");
                		break;
                	case 7:
	                	mAlarmSnoozeItem.setText("３０分");
                		break;	                		
            	}
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        dialog = builder.create();
		return dialog;
	}

	private Dialog createWeekDialog()
	{
		Dialog dialog = null;
		Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null);
        builder.setTitle("繰り返し");
        //0: デフォルト
        builder.setMultiChoiceItems(R.array.weekitem, mWeekValue, new DialogInterface.OnMultiChoiceClickListener(){
        	public void onClick(DialogInterface dialog, int which, boolean isChecked) 
        	{
    	         switch (which) 
    	         {
        	         case 0:
            	          mWeekValue[0] = isChecked;
            	          break;
        	         case 1:
            	          mWeekValue[1] = isChecked;
            	          break;
        	         case 3:
            	          mWeekValue[3] = isChecked;
            	          break;
        	         case 4:
            	          mWeekValue[4] = isChecked;
            	          break;
        	         case 5:
            	          mWeekValue[5] = isChecked;
            	          break;
        	         case 6:
            	          mWeekValue[6] = isChecked;
            	          break;
        	         case 7:
            	          mWeekValue[7] = isChecked;
            	          break;	
        	        default:
        	          break;
    	         }
            }
        });
        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
				mWeekOption.setBackgroundColor(Color.TRANSPARENT);
				dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
				mWeekOption.setBackgroundColor(Color.TRANSPARENT);
				
				boolean bWeekSelected = false;
				for(int i = 0; i < mWeekValue.length; i++)
				{
					if(mWeekValue[i]){
						bWeekSelected = true;
						break;
					}
				}
				if(!bWeekSelected)
				{
					mAlarmWeekItem.setText("繰り返しなし");
				}
				else
				{
					mAlarmWeekItem.setText(Alarm.getWeekText(mWeekValue));
				}
				dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        dialog = builder.create();
		
		return dialog;
	}
	
	private Dialog createSoundDialog()
	{
		Dialog dialog = null;
		Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null);
        builder.setTitle("アラーム音");
        
        mSoundNameList = Utils.getSoundTitleList(getApplicationContext());
        
        for(int i = 0; i < mSoundNameList.size(); i++)
        {
        	if(mSoundNameList.get(i).equals(mAlarmSoundItem.getText().toString().trim()))
        	{
        		mSoundSelectId = i;
        		break;
        	}
        }
        mSoundUri = null;
        builder.setSingleChoiceItems(mSoundNameList.toArray(new CharSequence[mSoundNameList.size()]), mSoundSelectId, 
        	new DialogInterface.OnClickListener()
        	{
        		public void onClick(DialogInterface dialog, int which) 
        		{
        			mSoundSelectId = which;
        			if(which == 0)
        			{
	            		if(mMediaPlayer.isPlaying())
	            		{
	            			mMediaPlayer.stop();
	            		}
	            		mSoundUri = null;
        			}
        			else
        			{
        				AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);  
        				am.adjustStreamVolume (AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_PLAY_SOUND); 
	            		if(mMediaPlayer.isPlaying())
	            		{
	            			mMediaPlayer.stop();
	            			mSoundUri = null;
	            		}
	            		mSoundUri = Utils.getRingtoneByUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE,  Utils.getRingtoneUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE, which - 1, ""));
	            		try 
	            		{
	            			mMediaPlayer.reset();
							mMediaPlayer.setDataSource(getApplicationContext(), mSoundUri);
							mMediaPlayer.prepare();
							mMediaPlayer.start();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (SecurityException e) {
							e.printStackTrace();
						} catch (IllegalStateException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						} 
        		   }
        		}
        });
        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
				if(mSoundUri != null)
				{
            		if(mMediaPlayer.isPlaying()){
            			mMediaPlayer.stop();
            		}
				}
        		mSoundOption.setBackgroundColor(Color.TRANSPARENT);
        		dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
				if(mSoundUri != null)
				{
            		if(mMediaPlayer.isPlaying()){
            			mMediaPlayer.stop();
            		}
				}
				
        		mSoundOption.setBackgroundColor(Color.TRANSPARENT);
            	mSoundName = mSoundNameList.get(mSoundSelectId);
            	mSoundPath = mSoundUri == null ? "" : mSoundUri.toString();
            	mAlarmSoundItem.setText(mSoundName);
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        dialog = builder.create();
		
		return dialog;
	}
	
	private Dialog createDeleteDialog()
	{
		Dialog dialog = null;
		Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null);
        builder.setTitle(mAlarmTime + "  " + mAlarmLabel);
        builder.setMessage("削除しますか？");
        
        builder.setPositiveButton("いいえ", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        builder.setNegativeButton("はい", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	Alarm.cancelAlarm(mContext, mAlarmId);
            	mAlarmDB.deleteByAlarmId(Integer.parseInt(mAlarmId));
            	if(Alarm.IsHaveSkipIdNotification(mContext, Integer.parseInt(mAlarmId))){
				}
				else{
					Alarm.delNotification(mContext);
				}
				
            	dialog.dismiss();
            	mbDialogStatus = false;
            	
				Intent intentNextAlarmTime = new Intent(ALARM_UPDATE_ACTION);
				intentNextAlarmTime.putExtra("nextalarmtime", Alarm.getNextAlarmTimeData(mContext).get(0));
				sendBroadcast(intentNextAlarmTime);
				AlarmOptionActivity.this.finish();
            }
        });
        
        dialog = builder.create();
        return dialog;
	}
	
    private class CommonReceiver extends BroadcastReceiver
	 {
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction(APP_CLOSE_ACTION);
			filter.addAction(TIMER_STOP_ACTION);
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			if (intent.getAction().equals(APP_CLOSE_ACTION)) 
		    {
	        	mMainBg.setImageDrawable(null);
	        	AlarmOptionActivity.this.finish();
		    }
			if (intent.getAction().equals(TIMER_STOP_ACTION)) 
			{
				getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
			}	
		}
	}
	 
	protected void onDestroy() 
	{
		//Log.v("CLOCK", "AlarmOptionActivity onDestroy");
		mCommonReceiver.unRegister();
		mAlarmDB.close();  
		mMainBg.setImageDrawable(null);
		super.onDestroy();
	}
	
	 public void onAttachedToWindow() 
	 {
		  if (true) 
		  {
			  this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
		  }
		  super.onAttachedToWindow();
		  
	 }
	 
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		 switch(keyCode)
		 {
			 case KeyEvent.KEYCODE_BACK:
					if(mbBackBtnActionStatus == false)
					{
						mbBackBtnActionStatus = true;
						backBtnAction();
					}
					break;		
			 case KeyEvent.KEYCODE_HOME:
					if(mSoundUri != null)
					{
						if(mMediaPlayer.isPlaying()){
							mMediaPlayer.stop();
							mMediaPlayer.release();
						}
					}
					sendBroadcast(new Intent(APP_CLOSE_ACTION));
					AlarmOptionActivity.this.finish();	
					break;
		 }
		return super.onKeyDown(keyCode, event);
    }
	
	 public LinearLayout.LayoutParams getLinearLayoutPararm(int x, int y, int w, int h)
	 {
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.leftMargin = dm.widthPixels * x / ORG_SCREEN_WIDTH;
		params.topMargin =  dm.widthPixels * y / ORG_SCREEN_WIDTH;
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		
		return params;
	 }
	 
}
