package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.widget;

import java.text.SimpleDateFormat;
import java.util.Date;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.MainTabActivity;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.R;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm.Alarm;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.flamingo.FlamingoTimingReceiver;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.flamingo.WidgetFlamingoActivity;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import jp.primeworks.android.flamingo.Flamingo;
import jp.primeworks.android.flamingo.Flamingo.OnAuthorizeListner;
import jp.primeworks.android.flamingo.FlamingoError;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.view.View;
import android.widget.RemoteViews;

public class ClockWidgetService extends Service 
{
	public  static String ALARM_UPDATE_ACTION = "com.taiyo.clock.action.ALARM_UPDATE_ACTION";
	private String mWidgetAlarmTime = "";
	private int mTime, mHour; 
	private SimpleDateFormat f = new SimpleDateFormat ("HH:mm:ss");
	private AlarmReceiver mAlarmReceiver;
	private Context mContext;
	private FlamingoTimingReceiver mTimingReceiver;
	
	public void onCreate() 
	{
		super.onCreate();
		mContext = ClockWidgetService.this;
		mAlarmReceiver = new AlarmReceiver();
		mAlarmReceiver.register();
		mWidgetAlarmTime = Alarm.getNextAlarmTimeData(mContext).get(0);
		
		//Flamingo
		Intent pIntent = new Intent();
		pIntent.setAction(FlamingoTimingReceiver.ACTION_FLAMINGO_TIMING);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext, Utils.PENDING_FLAMINGO_TIMING, pIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
		alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, 0, Utils.AUTHORIZE_RATE, pendingIntent);

		int[] ids = getWidgetIds(mContext);
		for (int id : ids) { setInvalidWidget(id); }
		
		mTimingReceiver = FlamingoTimingReceiver.getInstance(mContext);
		mTimingReceiver.register();

		Flamingo flamingo = new Flamingo(mContext);
		if (!Utils.sCanAuto) {
			if (!flamingo.isValidApplication()) {
				flamingo.authorize(false, new OnAuthorizeListner() {
					public void onError(FlamingoError error) {
						setWidgets();
						Utils.sCanAuto = true;
					}
					
					public void onComplete(boolean authorizeOk) {
						setWidgets();
						Utils.sCanAuto = true;
					}
					
					public void onCancel() {
						setWidgets();
						Utils.sCanAuto = true;
					}
				});
			} else {
				Utils.sCanAuto = true;
				setWidgets();
			}
		}
	}
	
	public int onStartCommand(Intent intent, int flags, int startId) {
		super.onStartCommand(intent, flags, startId);
		if (Utils.sCanAuto) {
			setWidgets();
		}
		return START_STICKY;
	}
	
	public void setWidgets() {
		Flamingo flamingo = new Flamingo(this);
		boolean isValidApp = flamingo.isValidApplication();
		
		isValidApp = true;
		
		if (isValidApp) {
			UpdateWidget(mContext);
		} 
		else
		{
			Alarm.alarmAllOff(mContext);
			Utils.initTimerData();
		}

		int[] ids = getWidgetIds(mContext);
		for (int id : ids) {
			if (isValidApp) {
				setValidWidget(id);
				UpdateWidget(mContext);
			} else {
				setInvalidWidget(id);
			}
		}
	}
	
	public void setValidWidget(int id)
	{
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(mContext);
		RemoteViews remoteView = new RemoteViews(mContext.getPackageName(), R.layout.widgetview);
		remoteView.setViewVisibility(R.id.tv_widget_invalidtxt, View.INVISIBLE);
			
		remoteView.setViewVisibility(R.id.invalidhour, View.INVISIBLE);
		remoteView.setViewVisibility(R.id.invalidminutes, View.INVISIBLE);
		remoteView.setViewVisibility(R.id.invalidclockbg, View.INVISIBLE);
		
		getUpdateBgImageResId();
		if(mWidgetAlarmTime != null && mWidgetAlarmTime.equals("-- : --"))
		{
			remoteView.setViewVisibility(R.id.alarmicon, View.INVISIBLE);
		}
		else
		{
			remoteView.setViewVisibility(R.id.alarmicon, View.VISIBLE);
		}
		
		switch(mTime)
		{
			case 1:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.VISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara01_01);
				remoteView.setImageViewResource(R.id.clockbg3, R.drawable.widget_watch_chara01_02);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow01);
				break;
			case 2:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.INVISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara02);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow02);
				break;
			case 3:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.VISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara03);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow03);
				break;
		}
		
		Intent intent = new Intent(mContext, MainTabActivity.class);
		PendingIntent pending = PendingIntent.getActivity(mContext, 0, intent, 0);
		remoteView.setOnClickPendingIntent(R.id.visitBgLayout, pending);
		appWidgetManager.updateAppWidget(id, remoteView);
	}

	public void setInvalidWidget(int id) 
	{
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(mContext);
		RemoteViews remoteView = new RemoteViews(mContext.getPackageName(),R.layout.widgetview);
		remoteView.setViewVisibility(R.id.tv_widget_invalidtxt, View.VISIBLE);
		remoteView.setViewVisibility(R.id.alarmicon, View.INVISIBLE);
		getUpdateBgImageResId();
		switch(mTime)
		{
			case 1:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidhour, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidminutes, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidclockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara01_01);
				remoteView.setImageViewResource(R.id.clockbg3, R.drawable.widget_watch_chara01_02);
				remoteView.setImageViewResource(R.id.invalidclockbg, R.drawable.widget_watch_bg2);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow01);
				break;
			case 2:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.INVISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidhour, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidminutes, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidclockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara02);
				remoteView.setImageViewResource(R.id.invalidclockbg, R.drawable.widget_watch_bg2);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow02);
				break;
			case 3:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.INVISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidhour, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidminutes, View.VISIBLE);
				remoteView.setViewVisibility(R.id.invalidclockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara03);
				remoteView.setImageViewResource(R.id.invalidclockbg, R.drawable.widget_watch_bg2);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow03);
				break;
		}
		
		Intent intent = new Intent();
		intent.setClass(mContext, WidgetFlamingoActivity.class);
		intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
		PendingIntent pending = PendingIntent.getActivity(mContext, 1, intent, intent.getFlags());
		remoteView.setOnClickPendingIntent(R.id.visitBgLayout, pending);
		appWidgetManager.updateAppWidget(id, remoteView);
	}
	
	private void UpdateWidget(Context context) 
	{        
		RemoteViews remoteView = new RemoteViews(context.getPackageName(), R.layout.widgetview);
		getUpdateBgImageResId();
		if(mWidgetAlarmTime != null && mWidgetAlarmTime.equals("-- : --"))
		{
			remoteView.setViewVisibility(R.id.alarmicon, View.INVISIBLE);
		}
		else
		{
			remoteView.setViewVisibility(R.id.alarmicon, View.VISIBLE);
		}
		
		switch(mTime)
		{
			case 1:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.VISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara01_01);
				remoteView.setImageViewResource(R.id.clockbg3, R.drawable.widget_watch_chara01_02);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow01);
				break;
			case 2:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.INVISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara02);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow02);
				break;
			case 3:
				remoteView.setViewVisibility(R.id.AnalogClock1, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg3, View.INVISIBLE);
				remoteView.setViewVisibility(R.id.point, View.VISIBLE);
				remoteView.setViewVisibility(R.id.clockbg, View.VISIBLE);
				remoteView.setImageViewResource(R.id.clockbg, R.drawable.widget_watch_chara03);
				remoteView.setImageViewResource(R.id.bgshadows, R.drawable.widget_watch_shadow03);
				break;
		}
		
        Intent startActivityIntent = new Intent(context, MainTabActivity.class);  
        PendingIntent Pintent = PendingIntent.getActivity(context, 0, startActivityIntent,0);  
        remoteView.setOnClickPendingIntent(R.id.visitBgLayout,Pintent);  
        
		AppWidgetManager awg = AppWidgetManager.getInstance(context);	
		int[] widgetIds = awg.getAppWidgetIds(new ComponentName(context, ClockWidget.class));
		awg.updateAppWidget(widgetIds, remoteView);
	}
	
	public static int[] getWidgetIds(Context context) {
		AppWidgetManager manager = AppWidgetManager.getInstance(context);
		return manager.getAppWidgetIds(new ComponentName(context, ClockWidget.class));
	}
	
	public void onDestroy() {
		super.onDestroy();
		if (mAlarmReceiver != null) {
			mAlarmReceiver.unRegister();
		}
		
		if (mTimingReceiver != null) {
			mTimingReceiver.unregister();
		}
		
		Intent pIntent = new Intent();
		pIntent.setAction(FlamingoTimingReceiver.ACTION_FLAMINGO_TIMING);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext, Utils.PENDING_FLAMINGO_TIMING, pIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
		alarmManager.cancel(pendingIntent);
		Utils.sCanAuto = false;
	}
	
	private class AlarmReceiver extends BroadcastReceiver
	{
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction(ALARM_UPDATE_ACTION);
			filter.addAction(Intent.ACTION_TIME_TICK);
			filter.addAction(Intent.ACTION_TIME_CHANGED);
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			Flamingo flamingo = new Flamingo(context);
			boolean isValidApp = flamingo.isValidApplication();
			isValidApp = true;
			if (isValidApp) 
			{
				if (intent.getAction().equals(ALARM_UPDATE_ACTION)) 
				{
					mWidgetAlarmTime = (String)(intent.getExtras().getString("nextalarmtime"));
					UpdateWidget(mContext);
				}
				
	            if (intent.getAction().equals(Intent.ACTION_TIME_TICK) || intent.getAction().equals(Intent.ACTION_TIME_CHANGED)) 
	            {
	            	UpdateWidget(mContext);
	            }
			} 
		}
	}

	public IBinder onBind(Intent arg0) 
	{
		return null;
	}
	
	private void getUpdateBgImageResId()
	{
        mHour = Integer.parseInt(f.format(new Date(System.currentTimeMillis())).split(":")[0]);
        
        if(mHour == 4 || mHour == 5 || mHour == 6 || mHour == 7 || mHour == 8 || mHour == 9 || mHour == 10 || mHour == 11 )
        {
			mTime = 1;
        }
        else if(mHour == 12 || mHour == 13 || mHour == 14 || mHour == 15 || mHour == 16 || mHour == 17 || mHour == 18 || mHour == 19 )
        {
			mTime = 2;
        }
        else if(mHour == 20 || mHour == 21 || mHour == 22 || mHour == 23 || mHour == 24 || mHour == 0 || mHour == 1 || mHour == 2 || mHour == 3 )
        {
			mTime = 3;	
        }	
	}
}