package jp.primeworks.android.flamingo.util;


import android.util.Log;


/**
 * ログクラス
 *
 */
public abstract class Logging {

	/** ログレベル 全て出力 */
	public static final int ALL = 0;

	/** ログレベル VERBOSE */
	public static final int VERBOSE = 1;

	/** ログレベル DEBUG */
	public static final int DEBUG = 2;

	/** ログレベル INFO */
	public static final int INFO = 3;

	/** ログレベル WARNING */
	public static final int WARNING = 4;

	/** ログレベル ERROR */
	public static final int ERROR = 5;

	/** ログレベル 出力なし */
	public static final int NOT_OUTPUT = 6;

	/** ログレベル 最小 */
	public static final int LOG_LEVEL_MIN = ALL;

	/** ログレベル 最大 */
	public static final int LOG_LEVEL_MAX = NOT_OUTPUT;

	/** ログレベル デフォルト */
	public static final int DEFAULT_LOG_LEVEL = NOT_OUTPUT;

	/** 現在のログレベル */
	private static int sLogLevel = ALL;

	/** ログ稼働中フラグ 初期状態はfalseとする. */
	private static boolean sLogActive = true;

	/** ログ用タグ */
	private static final String LOGTAG = "Flamingo";

	/**
	 * スタックトレースの何番目を取得してログ文字列を作るか.<BR>
	 * 値の定義範囲:(0～)<BR>
	 * [0]がこのgetDebugInfo()内、[1]がv()などのメソッド内、[2]が呼び出し元となる.
	 */
	private static final int STACK_TRACE_PICKUP_POINT = 2;


	/**
	 * ログ出力レベルを設定する.
	 *
	 * @param logLevel
	 *            ログ出力レベル(ALL/VERBOSE/DEBUG/INFO/WARNING/ERROR/NOT_OUTPUT)
	 *
	 */
	public static void setLogLevel(int logLevel) {

		if (logLevel < ALL) {
			logLevel = ALL;
		}
		if (NOT_OUTPUT < logLevel) {
			logLevel = NOT_OUTPUT;
		}
		Logging.sLogLevel = logLevel;
	}


	/**
	 * ログ出力レベルを取得する.
	 */
	public static int getLogLevel() {

		return sLogLevel;
	}


	/**
	 * ログ稼働中フラグを設定する.
	 *
	 * @param logActive
	 *            ログ稼働中フラグ
	 */
	public static void setLogActive(boolean logActive) {

		Logging.sLogActive = logActive;
	}


	/**
	 * ログ稼働中フラグを取得する.
	 */
	public static boolean isLogActive() {

		return sLogActive;
	}


	/**
	 * 呼び出し元のソースファイル名、行番号、メソッド名を取得する.
	 *
	 * return ソースファイル名と行番号とメソッド名を連結した文字列を返す.
	 */
	private static String getDebugInfo() {

		// 例外を生成してスタックトレース情報を取得する.
		StackTraceElement[] stackTraceElement = new Exception().getStackTrace();

		if (STACK_TRACE_PICKUP_POINT < stackTraceElement.length) {
			StackTraceElement element = stackTraceElement[STACK_TRACE_PICKUP_POINT];

			String fileName = element.getFileName();
			String methodName = element.getMethodName();
			int lineNumber = element.getLineNumber();

			if (fileName == null) {
				fileName = "**";
			}

			if (methodName == null) {
				methodName = "**";
			}

			return "(" + fileName + ":" + lineNumber + ") " + methodName + ": ";
		}

		return "";
	}


	/**
	 * 出力レベルがVERBOSEのログを出力する.
	 *
	 * @param msg
	 *            ログメッセージ
	 */
	public static void v(String msg) {

		if (sLogActive && (sLogLevel <= VERBOSE)) {
			String addMsg = getDebugInfo() + msg;
			Log.v(LOGTAG, addMsg);
		}
	}


	/**
	 * 出力レベルがDEBUGのログを出力する.
	 *
	 * @param msg
	 *            ログメッセージ
	 */
	public static void d(String msg) {

		if (sLogActive && (sLogLevel <= DEBUG)) {
			String addMsg = getDebugInfo() + msg;
			Log.d(LOGTAG, addMsg);
		}
	}


	/**
	 * 出力レベルがINFOのログを出力する.
	 *
	 * @param msg
	 *            ログメッセージ
	 */
	public static void i(String msg) {

		if (sLogActive && (sLogLevel <= INFO)) {
			String addMsg = getDebugInfo() + msg;
			Log.i(LOGTAG, addMsg);
		}
	}


	/**
	 * 出力レベルがWARNINGのログを出力する.
	 *
	 * @param msg
	 *            ログメッセージ
	 */
	public static void w(String msg) {

		if (sLogActive && (sLogLevel <= WARNING)) {
			String addMsg = getDebugInfo() + msg;
			Log.w(LOGTAG, addMsg);
		}
	}


	/**
	 * 出力レベルがERRORのログを出力する.
	 *
	 * @param msg
	 *            ログメッセージ
	 */
	public static void e(String msg) {

		if (sLogActive && (sLogLevel <= ERROR)) {
			String addMsg = getDebugInfo() + msg;
			Log.e(LOGTAG, addMsg);
		}
	}
}
