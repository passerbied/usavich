package jp.primeworks.android.flamingo.activity;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.OnCreateContextMenuListener;

/**
 * Flamingo Activity.
 * 
 * @author takimura
 * @see FlamingoActivityHook
 */
public abstract class FlamingoActivity extends Activity {

    /**
     * 認証ダイアログID.
     */
    public static final int DIALOG_AUTHORIZE = 3;

    /**
     * 認証失敗ダイアログID.
     */
    public static final int DIALOG_AUTHORIZE_FAILED = 4;

    /**
     * ネットワークエラーダイアログID.
     */
    public static final int DIALOG_NETWORK_ERROR = 5;

    /**
     * 認証キャンセルダイアログID.
     */
    public static final int DIALOG_AUTHORIZE_CANCELED = 6;  // TODO: GT 暫定追加。NEOS殿に確認を依頼。

    /**
     * ネットワークエラーダイアログID.
     */
    public static final int DIALOG_SERVER_ERROR = 7;

    /**
     * FlamingoActivityHook インスタンス.
     * <p>
     * FlamingoActivity の実動作を制御する Hookオブジェクト のインスタンス。
     * {@link #onCreateFlamingoActivityHook()} で取得したインスタンスが代入される。
     */
	private FlamingoActivityHook mHook;

	/**
	 * Activity 生成コールバック.
	 * 
	 * <p>
	 * FlamingoActivityHook を {@link #onCreateFlamingoActivityHook()} で取得/保存する。
	 * 
	 * @param savedInstanceState
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mHook = onCreateFlamingoActivityHook();
	}

	/**
	 * OptionMenu 生成コールバック.
	 * 
	 * @param menu メニュー
	 */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        return mHook.onHookCreateOptionsMenu(menu);
    }

    /**
     * OptionMenu 選択コールバック.
     * 
     * @param item 選択されたメニュー
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        return mHook.onHookOptionsItemSelected(item);
    }

    /**
     * Dialog 生成コールバック.
     * 
     * @param id 生成ダイアログID
     * <ul>
     *   <li>{@link #DIALOG_AUTHORIZE} - 認証開始確認ダイアログ
     *   <li>{@link #DIALOG_AUTHORIZE_FAILED} - 認証失敗通知ダイアログ
     *   <li>{@link #DIALOG_NETWORK_ERROR} - 通信失敗ダイアログ
     *   <li>{@link #DIALOG_AUTHORIZE_CANCELED} - 認証キャンセルダイアログ
     *   <li>{@link #DIALOG_SERVER_ERROR} - サーバーエラーダイアログ
     * </ul>
     */
    @Override
    protected Dialog onCreateDialog(int id) {
    	return mHook.onHookCreateDialog(id);
    }

    /**
     * FlamingoActvityHook 生成コールバック.
     * @return
     */
    protected FlamingoActivityHook onCreateFlamingoActivityHook() {
        return new FlamingoActivityHook(this);
    }

    /**
     * @deprecated Use {@link OnCreateContextMenuListener}
     * @param hook
     */
    public void setActivityHook(FlamingoActivityHook hook) {
        mHook = hook;
    }

    /**
     * 月額対応認証を開始する.
     */
    public void authorize() {
        mHook.authorize();
    }

    /**
	 * アプリケーション利用可否を取得する.
	 */
    public boolean isValidApplication() {
        return mHook.isValidApplication();
    }

    /**
     * 認証中状態を取得する.
     * @return true:認証中、false:非認証中
     */
    public boolean isAuthorizing() {
        return mHook.mAuthorizing;
    }

    /**
     * 認証エラー状態を取得する.
     * 
     * <p>
     * Flamingo認証が完了し、且つ、エラーが発生していた場合に true を返す。
     * 
     * @return
     */
    public boolean isAuthorizeError() {
        return mHook.mAuthError;
    }

}
