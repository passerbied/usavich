package jp.primeworks.android.flamingo.xml;

public class XmlTag {

    private String name;

    private String prefix;

    public XmlTag() {
    	this(null, null);
    }

    public XmlTag(String prefix, String name) {
    	setPrefix(prefix);
    	setName(name);
    }

    @Override
    public boolean equals(Object o) {
    	if(o == null) {
    		return false;
    	}
    	
    	if(!(o instanceof XmlTag)) {
    		return false;
    	}
    	
    	XmlTag obj = (XmlTag)o;

    	if((obj.name == null && this.name != null)
    			|| (obj.name != null && this.name == null)
    			|| (obj.name != null && this.name != null && !obj.name.equals(this.name))) {
    		return false;
    	}

    	if((obj.prefix == null && this.prefix != null)
    			|| (obj.prefix != null && this.prefix == null)
    			|| (obj.prefix != null && this.prefix != null && !obj.prefix.equals(this.prefix))) {
    		return false;
    	}

    	return true;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

}
