package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.sql;

import java.util.ArrayList;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.City;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseAdapter {
	private static DatabaseAdapter INSTANCE; 
	
	private static Context mContext;
	
	private SQLiteDatabase mSqLiteDatabase = null;
	private DatabaseHelper mDh = null;

	private static final String DB_NAME = "MWEATHER.db";
	private static final int DB_VERSION = 1;
	public static final String WEATHER_TABLE = "weather_info";
	public final String ID				= "id";
	public final String CITY_NAME		= "city_name";
	public final String CITY_CODE		= "city_code";
	public final String LAST_UPDATE		= "last_update";
	public final String DAY0_DATE		= "day0_date";
	public final String DAY0_WEATHER	= "day0_weather";
	public final String DAY1_DATE		= "day1_date";
	public final String DAY1_WEATHER	= "day1_weather";
	public final String DAY2_DATE		= "day2_date";
	public final String DAY2_WEATHER	= "day2_weather";
	public final String DAY3_DATE		= "day3_date";
	public final String DAY3_WEATHER	= "day3_weather";
	public final String DAY4_DATE		= "day4_date";
	public final String DAY4_WEATHER	= "day4_weather";
	public final String DAY5_DATE		= "day5_date";
	public final String DAY5_WEATHER	= "day5_weather";
	public final String DAY6_DATE		= "day6_date";
	public final String DAY6_WEATHER	= "day6_weather";
	public final String PRE1			= "pre1";
	public final String PRE2			= "pre2";
	public final String PRE3			= "pre3";
	
	
	private final String CREATE_TABLE = "CREATE TABLE " 	+ WEATHER_TABLE + " ("
											+ ID 			+ " INTEGER primary key autoincrement, "
											+ CITY_NAME 	+ " TEXT, "
											+ CITY_CODE 	+ " TEXT, "
											+ LAST_UPDATE 	+ " TEXT, "
											+ DAY0_DATE 	+ " TEXT, "
											+ DAY0_WEATHER 	+ " TEXT, "
											+ DAY1_DATE 	+ " TEXT, "
											+ DAY1_WEATHER	+ " TEXT, "
											+ DAY2_DATE 	+ " TEXT, "
											+ DAY2_WEATHER 	+ " TEXT, "
											+ DAY3_DATE 	+ " TEXT, "
											+ DAY3_WEATHER 	+ " TEXT, "
											+ DAY4_DATE 	+ " TEXT, "
											+ DAY4_WEATHER 	+ " TEXT, "
											+ DAY5_DATE 	+ " TEXT, "
											+ DAY5_WEATHER 	+ " TEXT, "
											+ DAY6_DATE 	+ " TEXT, "
											+ DAY6_WEATHER 	+ " TEXT, "
											+ PRE1 			+ " TEXT, " 
											+ PRE2 			+ " TEXT, "
											+ PRE3 			+ " TEXT" + " );";
	
	private final String[] ALL_COLMN =  {
			ID, CITY_NAME, CITY_CODE, LAST_UPDATE,
			DAY0_DATE, DAY0_WEATHER, DAY1_DATE, DAY1_WEATHER,
			DAY2_DATE, DAY2_WEATHER, DAY3_DATE, DAY3_WEATHER, 
			DAY4_DATE, DAY4_WEATHER, DAY5_DATE, DAY5_WEATHER, 
			DAY6_DATE, DAY6_WEATHER, 
	};

	private DatabaseAdapter() {
	}
	
	public static DatabaseAdapter getInstance(Context context) {
		mContext = context;
		if (INSTANCE == null) {
			INSTANCE = new DatabaseAdapter();
		}
		return INSTANCE;
	}
	
	public DatabaseAdapter(Context context) {
		mContext = context;
	}
	
	public void open() {
		mDh = new DatabaseHelper(mContext, DB_NAME, null, DB_VERSION, CREATE_TABLE, WEATHER_TABLE);
		mSqLiteDatabase = mDh.getWritableDatabase();
	}
	
	public void close() {
		mDh.close();
	}
	
	
	public Cursor getInfoByName(String cityName) {
		Cursor cursor = query(ALL_COLMN, CITY_NAME + "=?", new String[] { cityName });
		if (cursor.getCount() > 0) {
			return cursor;
		} else {
			return null;
		}
	}
	
	public void updateWeather(City savedCity, ArrayList<String> dateList, ArrayList<String> weatherList) {
		Cursor cursor = mSqLiteDatabase.query(WEATHER_TABLE, 
				new String[] { CITY_NAME }, CITY_NAME + "=?", 
				new String[] { savedCity.getName() }, 
				null, null, null);
		ContentValues cv = new ContentValues();
		cv.put(CITY_NAME, savedCity.getName());
		cv.put(CITY_CODE, savedCity.getCode());
		cv.put(DAY0_DATE, dateList.get(0));
		cv.put(DAY0_WEATHER, weatherList.get(0));
		cv.put(DAY1_DATE, dateList.get(1));
		cv.put(DAY1_WEATHER, weatherList.get(1));
		cv.put(DAY2_DATE, dateList.get(2));
		cv.put(DAY2_WEATHER, weatherList.get(2));
		cv.put(DAY3_DATE, dateList.get(3));
		cv.put(DAY3_WEATHER, weatherList.get(3));
		cv.put(DAY4_DATE, dateList.get(4));
		cv.put(DAY4_WEATHER, weatherList.get(4));
		cv.put(DAY5_DATE, dateList.get(5));
		cv.put(DAY5_WEATHER, weatherList.get(5));
		cv.put(DAY6_DATE, dateList.get(6));
		cv.put(DAY6_WEATHER, weatherList.get(6));
		if (cursor.getCount() > 0) {
			mSqLiteDatabase.update(WEATHER_TABLE, cv, CITY_NAME + "=?", 
					new String[]{ savedCity.getName() });
		} else {
			mSqLiteDatabase.insert(WEATHER_TABLE, null, cv);
		}
	}
	
	public void insert(ContentValues cv) {
		mSqLiteDatabase.insert(WEATHER_TABLE, null, cv);
	}
	
	public void update(ContentValues cv, String whereClause, String[] whereArgs) {
		mSqLiteDatabase.update(WEATHER_TABLE, cv, whereClause, whereArgs);
	}
	
	public Cursor query(String[] columns, String selection, String[] selectionArgs) {
		return mSqLiteDatabase.query(WEATHER_TABLE, columns, selection, 
				selectionArgs, null, null, null);
	}
	
	public void closeDataBase() {
		
		mSqLiteDatabase.close();
	}
}