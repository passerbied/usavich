package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.EditText;

public class EditTestText extends EditText{

	OnSizeChangedListener mListener;
	
	int orgH;
	
	public EditTestText(Context context, AttributeSet attrs) {
		super(context, attrs);
		orgH = 0;
	}
	
	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		if (oldh == 0 && oldw == 0) {
			orgH = h;
		}

		System.out.println("org=" + orgH + ", h=" + h);
		
		if (mListener != null) {
			if (h < orgH && h != 0) {
				mListener.onTextSizeChanged(true , h );
			} else if (h >= orgH && h != 0) {
				mListener.onTextSizeChanged(false , h );
			}
//			mListener.onTextSizeChanged((h < orgH && h != 0)? false : true);
 		}

		
//		if (h > orgH) {
//			ViewGroup.LayoutParams params = getLayoutParams();
//			params.height = orgH;
//			setLayoutParams(params);
//		}
	}
	
	public void setSizeChangedListener(OnSizeChangedListener listener) {
		mListener = listener;
	}

	interface OnSizeChangedListener {
		void onTextSizeChanged(boolean needVisible , int changeSize);
	}
}