/** Automatically generated file. DO NOT MODIFY */
package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}