/** Automatically generated file. DO NOT MODIFY */
package jp.primeworks.android.flamingo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}