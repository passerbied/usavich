package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.MemoApplication.Category;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db.MemoDBOperate;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db.MemoDataBaseAdapter;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.utils.Util;
import jp.primeworks.android.flamingo.activity.FlamingoActivity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MemoActivity extends FlamingoActivity {
	private ListView memoListView;
	private Button addMemoBtn;
	private Button memosetting_btn;
	private Button memofilter_btn;
	private Dialog filterDialog;
	private MemoDataBaseAdapter mdba;
	private MemoListAdapter memoAdapter;
	private List<Map<String, Object>> mData;
	private MemoApplication memoApp;
	private EditText currentPwdEdit;
	public final static String DEFAULT_PASSWORD = "0000";
	public static String TIMER_START_ACTION = "jp.neoscorp.android.action.usa.TIMER_START_ACTION";
	public static String ACTION_TIMER_SERVICE ="jp.neoscorp.android.usa.ACTION_TIMER_SERVICE"; 
	private Builder builder;
	private String[] editString = {"削除","ショートカット作成"};
	private SingleChoiceItemsOnClick singleClick;
	private ChoiceItemsOnClick itemClick;
	private int singleChoiceIndex;
	private TextView memoTitle;
	private ImageView memoBg,memoFooterImg;
	private DisplayMetrics dm;
	public static List<Category> filterList;
	public static boolean isFilter;
	public static boolean mbBackBtnActionStatus = false;
	private MemoSharedPreferences shortcutShared;
	private ImageView footerLinearContent;
	private boolean  isTesting;  
	private static String APP_CLOSE_ACTION = "com.taiyo.memo.action.APP_CLOSE_ACTION";
	private CommonReceiver mCommonReceiver;
	public static boolean isFilter() {
		return isFilter;
	}
	public static void setFilter(boolean isFilter) {
		MemoActivity.isFilter = isFilter;
	}
	public static List<Category> getFilterList() {
		return filterList;
	}
	public static void setFilterList(List<Category> filterList) {
		MemoActivity.filterList = filterList;
	}
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memo);
        shortcutShared = new MemoSharedPreferences(this);
        mCommonReceiver = new CommonReceiver();
		mCommonReceiver.register();
        dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        memoApp = (MemoApplication)this.getApplication();
        addMemoBtn = (Button)findViewById(R.id.add_memo_btn);
        footerLinearContent = (ImageView)findViewById(R.id.footerLinearContent);
        footerLinearContent.setLayoutParams(Util.getLinearLayoutFormHeightPararm(90, dm));
        memoFooterImg = (ImageView)findViewById(R.id.memo_footer_img);
        memoFooterImg.setLayoutParams(Util.getLinearLayoutPararm(480,100,dm));
        mdba = new MemoDataBaseAdapter(this);
        mdba.open();
        mData = MemoListAdapter.getData(mdba,memoApp);
        memoApp.setPositionMap(mData);
        startService(new Intent(ACTION_TIMER_SERVICE));
        memoAdapter = new MemoListAdapter(this,mdba,memoApp);
        mdba.close();
        Util.windowDisplay = dm;
        memoListView = (ListView)findViewById(R.id.memo_list);
        memoListView.setAdapter(memoAdapter);
        memoListView.setCacheColorHint(0);
        memoListView.setDividerHeight(0);
      
        memoListView.setOnItemClickListener(memoListOnItemClick);
        memoListView.setOnItemLongClickListener(memoListOnItemLongClick);
        // add footer
        ImageView footerImg = new ImageView(this);
        singleClick = new SingleChoiceItemsOnClick();
 
        memoTitle = (TextView)findViewById(R.id.memoTitle);
        memoTitle.setTypeface(Util.setMediumFont(this));
      
        memoBg = (ImageView)findViewById(R.id.memoBg);
        memoBg.setLayoutParams(Util.getLinearLayoutPararm(480, 854, dm));
        memofilter_btn = (Button)findViewById(R.id.memofilter_btn);
        memofilter_btn.setTypeface(Util.setLightFont(this));
        memofilter_btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				createFilterDialog();
			}
		});
        memosetting_btn = (Button)findViewById(R.id.memosetting_btn);
        memosetting_btn.setTypeface(Util.setLightFont(this));
        memosetting_btn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MemoActivity.this,MemoSettingActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
				startActivity(intent);				
			}
		});
        addMemoBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(mbBackBtnActionStatus == false)
				{
					mbBackBtnActionStatus = true;
					CategoryDialog category = new CategoryDialog(MemoActivity.this,new Intent(MemoActivity.this,MemoEditActivity.class));
					category.showCategoryDialog(getWindowManager().getDefaultDisplay().getWidth()
												,getWindowManager().getDefaultDisplay().getHeight()
												,dm
												,0
												);
					
				}
			}
		});
               
        searchMemoPassword();
        
    }
	protected void onResume()
	{
		super.onResume();
		reloadList();
	}
    private void reloadList()
    {
    	mdba = new MemoDataBaseAdapter(this);
        mdba.open();
    	mData = MemoListAdapter.getData(mdba,memoApp);
		memoApp.setPositionMap(mData);
		memoAdapter = new MemoListAdapter(this,mdba,memoApp);
		memoListView.setAdapter(memoAdapter);
		mdba.close();
    }
    //絞り込み
    private void createFilterDialog(){
    	filterDialog = new Dialog(this,R.style.AlertDialog);
    	
        LayoutInflater inflater=(LayoutInflater)this.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);  
        inflater =  filterDialog.getLayoutInflater();
        View view = inflater.inflate(R.layout.memo_filter, null);
        final CheckBox chkDuck = (CheckBox)view.findViewById(R.id.chkDuck);
//        chkDuck.setLayoutParams(Util.getLinearLayoutPararm(75, dm));
        final CheckBox chkBear = (CheckBox)view.findViewById(R.id.chkBear);
//        chkBear.setLayoutParams(Util.getLinearLayoutPararm(75, dm));
        final CheckBox chkRabbit = (CheckBox)view.findViewById(R.id.chkRabbit);
//        chkRabbit.setLayoutParams(Util.getLinearLayoutPararm(75, dm));
        final CheckBox chkGiraffe = (CheckBox)view.findViewById(R.id.chkGiraffe);
//        chkGiraffe.setLayoutParams(Util.getLinearLayoutPararm(75, dm));
        final CheckBox chkElephant = (CheckBox)view.findViewById(R.id.chkElephant);
//        chkElephant.setLayoutParams(Util.getLinearLayoutPararm(75, dm));
        
        ImageView memo_dialog_chara01 = (ImageView)view.findViewById(R.id.memo_dialog_chara01);
        memo_dialog_chara01.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(chkDuck.isChecked())
				{
					chkDuck.setChecked(false);
				}
				else
				{
					chkDuck.setChecked(true);
				}
			}
		});
        memo_dialog_chara01.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        ImageView memo_dialog_chara02 = (ImageView)view.findViewById(R.id.memo_dialog_chara02);
        memo_dialog_chara02.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara02.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(chkBear.isChecked())
				{
					chkBear.setChecked(false);
				}
				else
				{
					chkBear.setChecked(true);
				}
			}
		});
        ImageView memo_dialog_chara03 = (ImageView)view.findViewById(R.id.memo_dialog_chara03);
        memo_dialog_chara03.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara03.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(chkRabbit.isChecked())
				{
					chkRabbit.setChecked(false);
				}
				else
				{
					chkRabbit.setChecked(true);
				}
			}
		});
        ImageView memo_dialog_chara04 = (ImageView)view.findViewById(R.id.memo_dialog_chara04);
        memo_dialog_chara04.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara04.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(chkGiraffe.isChecked())
				{
					chkGiraffe.setChecked(false);
				}
				else
				{
					chkGiraffe.setChecked(true);
				}
			}
		});
        ImageView memo_dialog_chara05 = (ImageView)view.findViewById(R.id.memo_dialog_chara05);
        memo_dialog_chara05.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara05.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(chkElephant.isChecked())
				{
					chkElephant.setChecked(false);
				}
				else
				{
					chkElephant.setChecked(true);
				}
			}
		});
        if(memoApp != null && getFilterList()!= null)
        {
        	for(Category category : MemoActivity.getFilterList())
        	{
        		switch(category)
        		{
	        		case DUCK: chkDuck.setChecked(true);break;
	        		case BEAR: chkBear.setChecked(true);break;	
	        		case RABBIT: chkRabbit.setChecked(true);break;
	        		case GIRAFFE: chkGiraffe.setChecked(true);break;	
	        		case ELEPHANT: chkElephant.setChecked(true);break;
        		}
        	}
        }
        
        Button decisionBtn = (Button)view.findViewById(R.id.decisionBtn);
        decisionBtn.setTypeface(Util.setLightFont(MemoActivity.this));
        decisionBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				List<Category> categoryLit = new ArrayList<Category>();
		        if(chkDuck.isChecked())
		        {
		        	categoryLit.add(Category.DUCK);
		        }
		        if(chkBear.isChecked())
		        {
		        	categoryLit.add(Category.BEAR);
		        }
		        if(chkRabbit.isChecked())
		        {
		        	categoryLit.add(Category.RABBIT);
		        }
		        if(chkGiraffe.isChecked())
		        {
		        	categoryLit.add(Category.GIRAFFE);
		        }
		        if(chkElephant.isChecked())
		        {
		        	categoryLit.add(Category.ELEPHANT);
		        }
		        if(memoApp != null && categoryLit.size() > 0)
		        {
		        	MemoActivity.setFilterList(categoryLit);
		        }
		        else
		        {
		        	MemoActivity.setFilter(true);
		        	MemoActivity.setFilterList(null);
		        }
//		        MemoActivity.this.finish();
//		        startActivity(new Intent(MemoActivity.this,MemoActivity.class));
		        reloadList();
		        filterDialog.dismiss();
			}
		});
        
        filterDialog.setContentView(view);
        filterDialog.show();
    }
    
    AdapterView.OnItemLongClickListener memoListOnItemLongClick = new AdapterView.OnItemLongClickListener() {

		@Override
		public boolean onItemLongClick(AdapterView<?> parent, View view,
				final int position, long id) {
			if(position < mData.size())
			{
				// current adapter view 2012-10-18
//				AlertDialog dialog = null;
//				final Builder passwordbuilder = new android.app.AlertDialog.Builder(MemoActivity.this);
//				passwordbuilder.setTitle("パスワード入力");
//			    final String memoId = mData.get(position).get("memoId").toString();
//			    final String clockStatus = mData.get(position).get("memoClockStatus").toString();
//				if(clockStatus.equals(Util.HAS_PASSWORD_STATUS))
//		        {
//					//パスワード入力dialog
//					
//		        	LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
//		            View passwrodview = inflater.inflate(R.layout.memo_check_password, null); 
//		            final EditText currentPwdEdit = (EditText)passwrodview.findViewById(R.id.current_password);
//		            passwordbuilder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
//			        {
//			            public void onClick(DialogInterface dialog, int which) 
//			            {
//			            	dialog.dismiss();     	
//			            }
//			        });
//		            passwordbuilder.setNegativeButton("OK", new DialogInterface.OnClickListener()
//			        {
//			            public void onClick(DialogInterface dialog, int which) 
//			            {
//			            	String currentPwdStr = currentPwdEdit.getText().toString().trim();
//			            	if(memoApp.getMemoPassword() != null)
//		                    {
//			            		 if(currentPwdStr.equals(memoApp.getMemoPassword()))
//		                    	  {
//			            			 delMemoDialog(position,memoId);
//		         					 dialog.dismiss();
//		                    	  }
//			            		 else
//			            		 {
////			            			 dialog.dismiss();
//			            			 Util.WrongPassword(MemoActivity.this);
//			            		 }
//		                    }
//			            	else
//		                    {
//		                    	  if(currentPwdStr.equals(MemoActivity.DEFAULT_PASSWORD))
//		                    	  {
//		                    		  delMemoDialog(position,memoId);
//		                    		  dialog.dismiss();
//		                    	  }	
//		                    	  else
//		                    	  {
//				            			 Util.WrongPassword(MemoActivity.this);
////				            			 dialog.dismiss();
//		                    	  }
//		                    }
//			            }
//			        });
//		             dialog = passwordbuilder.create();
//				     dialog.setView(passwrodview,0,0,0,0);
//				     dialog.show();
//		        }
//				else
//				{
//					delMemoDialog(position,memoId);	
//				}
			
			// old 	adpter view 2012-10-17
			AlertDialog passworddialog = null;
			Builder longClickbuilder = new android.app.AlertDialog.Builder(MemoActivity.this);
			longClickbuilder.setIcon(null);
			String shortString = null;
			String category = null;
//			longClickbuilder.setSingleChoiceItems(editString, 0, singleClick); 
			try{
				
			if(null == mData.get(position).get("memoTitle") || "".equals(mData.get(position).get("memoTitle").toString()))
			{
				shortString = " ";
			}
			else
			{
				shortString = mData.get(position).get("memoTitle").toString();
			}
	        final String memoId = mData.get(position).get("memoId").toString();
	        final String clockStatus = mData.get(position).get("memoClockStatus").toString();
	        if(null != mData.get(position).get("memoCategory"))
	        {
	        	category = mData.get(position).get("memoCategory").toString();
	        }
	        longClickbuilder.setTitle(shortString==null?"":shortString);
	        itemClick = new ChoiceItemsOnClick(clockStatus,position,memoId,shortString,category);
			longClickbuilder.setItems(editString, itemClick);
	        longClickbuilder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
	        {
	            public void onClick(DialogInterface dialog, int which) 
	            {
	            	dialog.dismiss();     	
	            }
	        });
	        
	        longClickbuilder.show();
			}catch(Exception e){e.printStackTrace();}
            
            //old dialog 2012-10-18
//	        longClickbuilder.setNegativeButton("OK", new DialogInterface.OnClickListener()
//	        {
//	            public void onClick(DialogInterface dialog, int which) 
//	            {
	            	//削除
//	            	if(singleChoiceIndex == 0)
//	            	{
//	            		AlertDialog passworddialog = null;
//						final Builder passwordbuilder = new android.app.AlertDialog.Builder(MemoActivity.this);
//						passwordbuilder.setTitle("パスワード入力");
//						if(clockStatus.equals(Util.HAS_PASSWORD_STATUS))
//				        {
//							//パスワード入力dialog
//							
//				        	LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
//				            View view = inflater.inflate(R.layout.memo_check_password, null); 
//				            final EditText currentPwdEdit = (EditText)view.findViewById(R.id.current_password);
//				            passwordbuilder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
//					        {
//					            public void onClick(DialogInterface dialog, int which) 
//					            {
//					            	dialog.dismiss();     	
//					            }
//					        });
//				            passwordbuilder.setNegativeButton("OK", new DialogInterface.OnClickListener()
//					        {
//					            public void onClick(DialogInterface dialog, int which) 
//					            {
//					            	String currentPwdStr = currentPwdEdit.getText().toString().trim();
//					            	if(memoApp.getMemoPassword() != null)
//				                    {
//					            		 if(currentPwdStr.equals(memoApp.getMemoPassword()))
//				                    	  {
//					            			 	delMemoDialog(dialog,position,memoId,shortString);
//				         						dialog.dismiss();
//				                    	  }
//					            		 else
//					            		 {
//					            			 Util.WrongPassword(MemoActivity.this);
//					            		 }
//				                    }
//					            	else
//				                    {
//				                    	  if(currentPwdStr.equals(MemoActivity.DEFAULT_PASSWORD))
//				                    	  {
//				                    		  	  delMemoDialog(dialog,position,memoId,shortString);
//				                    			  dialog.dismiss();
//				                    	  }	
//				                    	  else
//				                    	  {
//						            			 Util.WrongPassword(MemoActivity.this);
//				                    	  }
//				                    }
//					            }
//					        });
//				            passworddialog = passwordbuilder.create();
//				            passworddialog.setView(view,0,0,0,0);
//				            passworddialog.show();
//				        }
//						else
//						{
//							delMemoDialog(dialog,position,memoId,shortString);
//						}
//	            	}
	            	//ショートカット
//	            	else if(singleChoiceIndex == 1)
//	            	{
//	            		if(null != mData.get(position).get("memoId"))
//	            		{
//	            			int resourceId = 0;
//	            			
//		            		Intent sender = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
//		            		Intent shortcutIntent = new Intent(MemoActivity.this, SCConfimActivity.class);
//		            		shortcutIntent.setAction(Intent.ACTION_VIEW);
//		            		
//		            		shortcutIntent.putExtra("memoId", memoId);
//		            		shortcutIntent.putExtra("position", String.valueOf(position));
//		            		shortcutIntent.putExtra("category", mData.get(position).get("memoCategory").toString());
//		            		shortcutIntent.putExtra("shortcut", "shortcut");
//		            		shortcutIntent.putExtra("checkPasswordStatus", String.valueOf(memoApp.isCheckPasswordStatus()));
//		            		
//		            		shortcutIntent.putExtra("password", memoApp.getMemoPassword());
//		            		sender.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
//		            		sender.putExtra(Intent.EXTRA_SHORTCUT_NAME, shortString);
//		            		
//		            		if(null != mData.get(position).get("memoCategory"))
//		            		{
//		            			String category =  mData.get(position).get("memoCategory").toString();
//		            			switch(Integer.parseInt(category))
//		            			{
//		            				case 0:resourceId = R.drawable.memo_sc01;break;
//		            				case 1:resourceId = R.drawable.memo_sc02;break;
//		            				case 2:resourceId = R.drawable.memo_sc03;break;
//		            				case 3:resourceId = R.drawable.memo_sc04;break;
//		            				case 4:resourceId = R.drawable.memo_sc05;break;
//		            				
//		            			}
//		            		}
//		            		sender.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
//		            				Intent.ShortcutIconResource.fromContext(MemoActivity.this,
//		            						resourceId));
//		            		shortcutShared.saveSettingSort(memoId,shortString,MemoSharedPreferences.SETTING_SHORTCUT);
////		            		sender.putExtra("duplicate", false);
//		            		sendBroadcast(sender);
//	            		}
//	            	}
//	            	singleChoiceIndex = 0;
//	            	dialog.dismiss();
//	            }
//	        });
//	        longClickbuilder.show();
			}
			return true;
			
		}
	};
    AdapterView.OnItemClickListener memoListOnItemClick = new AdapterView.OnItemClickListener() 
	{
		public void onItemClick(AdapterView<?> parent, View view, int position,long id) 
		{
			Intent intent = new Intent(MemoActivity.this,MemoEditActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			if(position < mData.size())
			{
			
			if(null != mData.get(position).get("memoClockStatus"))
			{
				String clockStatus = mData.get(position).get("memoClockStatus").toString();
				if(clockStatus.equals(Util.HAS_PASSWORD_STATUS) && !memoApp.isStartReceiver())
				{
					checkPasswordDialog(mData.get(position).get("memoId").toString(),
										String.valueOf(position),
										mData.get(position).get("memoCategory").toString()
										);
				}
				else
				{
					intent.putExtra("memoId", (String)mData.get(position).get("memoId"));
					intent.putExtra("position", String.valueOf(position));
					intent.putExtra("category", (String)mData.get(position).get("memoCategory"));
//					MemoActivity.this.finish();
					startActivity(intent);
					
				}
			}
			else
			{
				if(mData.get(position).get("memoId") != null)
				{
					intent.putExtra("memoId", (String)mData.get(position).get("memoId"));
					intent.putExtra("position", String.valueOf(position));
					intent.putExtra("category", (String)mData.get(position).get("memoCategory"));
//					MemoActivity.this.finish();
					startActivity(intent);
				}
	
				
			}
			}
		}
	};
	  private class SingleChoiceItemsOnClick implements DialogInterface.OnClickListener
	  {
		@Override
		public void onClick(DialogInterface dialog, int which) {
			singleChoiceIndex = which;
		}
		  
	  }
	private class ChoiceItemsOnClick implements DialogInterface.OnClickListener
	{
		private String clockStatus;
		private int position;
		private String memoId;
		private String shortString;
		private int choiceItemIndex;
		private String category;
		public ChoiceItemsOnClick(String clockStatus,int position,String memoId,String shortString,String category)
		{
			this.clockStatus= clockStatus;
			this.position = position;
			this.memoId = memoId;
			this.shortString = shortString;
			this.category = category;
		}
		@Override
		public void onClick(DialogInterface dialog, int which) {
			choiceItemIndex = which;
			AlertDialog passworddialog = null;
			final Builder passwordbuilder = new android.app.AlertDialog.Builder(MemoActivity.this);
			passwordbuilder.setTitle("パスワード入力");
			if(clockStatus.equals(Util.HAS_PASSWORD_STATUS))
	        {
				//パスワード入力dialog
				
	        	LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
	            View view = inflater.inflate(R.layout.memo_check_password, null); 
	            final EditText currentPwdEdit = (EditText)view.findViewById(R.id.current_password);
	            passwordbuilder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
		        {
		            public void onClick(DialogInterface dialog, int which) 
		            {
		            	dialog.dismiss();     	
		            }
		        });
	            passwordbuilder.setNegativeButton("OK", new DialogInterface.OnClickListener()
		        {
		            public void onClick(DialogInterface dialog, int which) 
		            {
		            	
		            	String currentPwdStr = currentPwdEdit.getText().toString().trim();
		            	if(memoApp.getMemoPassword() != null)
	                    {
		            		 if(currentPwdStr.equals(memoApp.getMemoPassword()))
	                    	  {
		            			 	if(choiceItemIndex == 0)
		            			 	{
		            			 		delMemoDialog(dialog,position,memoId,shortString);
		            			 	}
		            			 	else if(choiceItemIndex == 1)
		            			 	{
		            			 		createShortcutDialog(dialog,memoId,position,category,shortString);
		            			 	}
		            			 		
	         						dialog.dismiss();
	                    	  }
		            		 else
		            		 {
		            			 Util.WrongPassword(MemoActivity.this);
		            		 }
	                    }
		            	else
	                    {
	                    	  if(currentPwdStr.equals(MemoActivity.DEFAULT_PASSWORD))
	                    	  {
	                    		  if(choiceItemIndex == 0)
		            			 	{
		            			 		delMemoDialog(dialog,position,memoId,shortString);
		            			 	}
		            			 	else if(choiceItemIndex == 1)
		            			 	{
		            			 		createShortcutDialog(dialog,memoId,position,category,shortString);
		            			 	}
	                    			  dialog.dismiss();
	                    	  }	
	                    	  else
	                    	  {
			            			 Util.WrongPassword(MemoActivity.this);
	                    	  }
	                    }
		            }
		        });
	            passworddialog = passwordbuilder.create();
	            passworddialog.setView(view,0,0,0,0);
	            passworddialog.show();
	        }
			else
			{
				if(choiceItemIndex == 0)
            	{
					delMemoDialog(dialog,position,memoId,shortString);
            	}
				else if(choiceItemIndex == 1)
				{
					createShortcutDialog(dialog,memoId,position,category,shortString);
				}
			}
			
		}
	}
	@SuppressWarnings("static-access")
	private void searchMemoPassword()
	{
		 MemoDataBaseAdapter mda = new MemoDataBaseAdapter(this);
		 mda.open();
		 Cursor mCursor = mda.selectPassword();
		 if(mCursor != null && mCursor.getCount() != 0)
			{
			 	mCursor.moveToFirst();
			 	memoApp.setMemoPassword(mCursor.getString(mCursor.getColumnIndex( mda.MEMO_PASSWORD)));
			 	mCursor.close();
			 	mCursor = null;
			}
		 mda.close();
	}
	//ショートカット削除
	private void deleteFromLauncher(String key, String shoutCutName) {
		Intent shortcut = new Intent(
				"com.android.launcher.action.UNINSTALL_SHORTCUT");
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_NAME, shoutCutName);
		Intent respondIntent = new Intent(this, SCConfimActivity.class);
		respondIntent.setAction(Intent.ACTION_VIEW);
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_INTENT, respondIntent);
		shortcutShared.removeSettingSort(key , MemoSharedPreferences.SETTING_SHORTCUT);
		sendBroadcast(shortcut);
	}
	//パスワード Dialog
	private void checkPasswordDialog(final String memoId, final String memoPosition, final String memoCategory){
		AlertDialog dialog = null;
		builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null);
        builder.setTitle("パスワード");
        LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
        View view = inflater.inflate(R.layout.memo_password, null); 
        currentPwdEdit = (EditText)view.findViewById(R.id.current_password);
        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
//            	try{  
//                      Field field = dialog.getClass().getSuperclass().getDeclaredField("mShowing");  
//                      field.setAccessible(true);  
//                      field.set(dialog, true);  
//                      dialog.dismiss();   
//            	}catch(Exception e) {  
//                      e.printStackTrace();  
//                }  
            	dialog.dismiss();  
            }
        });
        
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	try{  
//            		 final Field field = dialog.getClass().getSuperclass().getDeclaredField("mShowing");  
//                     field.setAccessible(true);  
//                     field.set(dialog, false);
            		 Intent intent = new Intent(MemoActivity.this,MemoEditActivity.class);
            		 intent.putExtra("memoId",memoId);
     				 intent.putExtra("position",memoPosition);
     				 intent.putExtra("category", memoCategory);
     				
                      if(memoApp.getMemoPassword() != null)
                      {
                    	  if(currentPwdEdit.getText().toString().equals(memoApp.getMemoPassword()))
                    	  {
//                    		 field.set(dialog, true);
                    		 sendBroadcast(new Intent(TIMER_START_ACTION));
                    		 memoApp.setCheckPasswordStatus(true);
                    		 memoApp.setIsStartReceiver(true); 
                    		 dialog.dismiss();
                  			 startActivity(intent);
//                  			 MemoActivity.this.finish();
                    	  }
                    	  else
	          			  {
	          					Util.WrongPassword(MemoActivity.this);
	          					dialog.dismiss();
	          			  }
                      }
                      else
                      {
                    	  if(currentPwdEdit.getText().toString().equals(DEFAULT_PASSWORD))
                    	  {
//                    		  field.set(dialog, true);
                    		  sendBroadcast(new Intent(TIMER_START_ACTION));
                    		  memoApp.setCheckPasswordStatus(true);
                    		  memoApp.setIsStartReceiver(true);
                    		  dialog.dismiss();
                    		  startActivity(intent);
//                    		  MemoActivity.this.finish();
                    	  }
                    	  else
	          			  {
	          					Util.WrongPassword(MemoActivity.this);
	          					dialog.dismiss();
	          			  }
                      }
                      
            	}catch(Exception e) {  
                      e.printStackTrace();  
                }  
            }
        }); 
        dialog = builder.create();
        dialog.setView(view, 0, 0, 0, 0);
        dialog.show();
    }
	
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	 {
		 switch(keyCode)
		 {
			 case KeyEvent.KEYCODE_BACK:
				 MemoActivity.setFilterList(null);
				 MemoActivity.setFilter(false);
				 this.finish();
				 sendBroadcast(new Intent(APP_CLOSE_ACTION));
				 break;
		 }
		 return super.onKeyDown(keyCode, event);
	 }
//
	private void delMemoDialog(DialogInterface dialog, final int position, final String memoId, final String shortString)
	{
		if(null != memoId)
		{
			AlertDialog alertdialog = null;
			Builder delBuilder = new AlertDialog.Builder(MemoActivity.this);
			delBuilder.setTitle(shortString == null ? "" : shortString);
			delBuilder.setMessage("削除しますか？");
			delBuilder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
		    {
		            public void onClick(DialogInterface dialog, int which) 
		            {
		            	dialog.dismiss();     	
		            }
		    });
			delBuilder.setNegativeButton("OK", new DialogInterface.OnClickListener()
		    {
		            public void onClick(DialogInterface dialog, int which) 
		            {
		            	MemoDBOperate.deleteMemo(MemoActivity.this, memoId);
//            			deleteFromLauncher(memoId,shortString);
            			reloadList();
		            	dialog.dismiss();     	
		            }
		    });
			delBuilder.show();
			dialog.dismiss();
		}
	}
	private void sendToLauncher(String memoId,int position,String category,String title)
	{
		int resourceId = 0;
		Intent shortcutIntent = null;
		String mMemoSCName = title;
		Intent sender = new Intent();
		shortcutIntent = new Intent(MemoActivity.this, SCConfimActivity.class);
		shortcutIntent.setAction(Intent.ACTION_VIEW);
		shortcutIntent.putExtra("memoId", memoId);
		shortcutIntent.putExtra("position", String.valueOf(position));
//		shortcutIntent.putExtra("category", category);
		shortcutIntent.putExtra("shortcut", "shortcut");
		shortcutIntent.putExtra("checkPasswordStatus", String.valueOf(memoApp.isCheckPasswordStatus()));

		sender.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
		sender.putExtra(Intent.EXTRA_SHORTCUT_NAME, mMemoSCName);
		if(null != category)
		{
			switch(Integer.parseInt(category))
			{
				case 0:resourceId = R.drawable.memo_sc01;break;
				case 1:resourceId = R.drawable.memo_sc02;break;
				case 2:resourceId = R.drawable.memo_sc03;break;
				case 3:resourceId = R.drawable.memo_sc04;break;
				case 4:resourceId = R.drawable.memo_sc05;break;
			}
		}
		sender.putExtra(Intent.EXTRA_SHORTCUT_ICON,((BitmapDrawable)
						getResources().getDrawable(resourceId)).getBitmap());
		sender.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
		sendBroadcast(sender);
	}
	private void createShortcutDialog(DialogInterface dialog,final String memoId,final int position,final String category,final String title)
	{
		Builder builder = new android.app.AlertDialog.Builder(MemoActivity.this);
        builder.setIcon(null);
        builder.setTitle(title);
        builder.setMessage("ショートカット作成しますか？");
        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	dialog.dismiss();     	
            }
        });
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	sendToLauncher(memoId,position,category,title);
            	dialog.dismiss();
            }
        });
        
        builder.show();
        dialog.dismiss();
	}
	protected void onDestroy() 
	{
		mCommonReceiver.unRegister();
		super.onDestroy();
	}
	 private class CommonReceiver extends BroadcastReceiver
	 {
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction(APP_CLOSE_ACTION);
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			if (intent.getAction().equals(APP_CLOSE_ACTION)) 
		    {
	        	MemoActivity.this.finish();
		    }
		}
	}
	 
}