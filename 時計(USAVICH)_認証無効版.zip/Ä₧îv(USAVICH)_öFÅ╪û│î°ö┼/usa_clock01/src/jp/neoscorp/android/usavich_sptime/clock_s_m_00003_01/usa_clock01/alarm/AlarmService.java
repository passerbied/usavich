package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class AlarmService extends Service 
{
	public static String APP_CLOSE_ACTION    = "com.taiyo.clock.action.APP_CLOSE_ACTION";
	public IBinder onBind(Intent arg0) 
	{
		return null;
	}

	public void onStart(Intent intent, int startId) 
	{
		super.onStart(intent, startId);
		sendBroadcast(new Intent(APP_CLOSE_ACTION));
	}
	
}
