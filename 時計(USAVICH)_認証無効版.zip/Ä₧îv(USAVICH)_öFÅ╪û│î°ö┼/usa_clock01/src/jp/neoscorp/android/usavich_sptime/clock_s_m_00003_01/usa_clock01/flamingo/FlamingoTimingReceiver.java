package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.flamingo;

import jp.primeworks.android.flamingo.Flamingo;
import jp.primeworks.android.flamingo.FlamingoError;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class FlamingoTimingReceiver extends BroadcastReceiver {
	public static final String TAG = "FlamingoTimingReceiver";
	
	public static final String ACTION_FLAMINGO_TIMING = "jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.ACTION_FLAMINGO_TIMING";
	public static final String ACTION_WIDGET_SERVICE  = "jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.widget.ACTION_WIDGET_SERVICE";
	
	private static FlamingoTimingReceiver INSTANCE;
	
	private boolean mIsRegistered;
	
	private Context mContext;
	
	private FlamingoTimingReceiver(Context context) {
		mContext = context;
	}

	public static FlamingoTimingReceiver getInstance(
			Context context) {
		if (INSTANCE == null) {
			INSTANCE = new FlamingoTimingReceiver(context);
		}
		return INSTANCE;
	}

	public void onReceive(Context context, Intent intent) {
		Flamingo flamingo = new Flamingo(context.getApplicationContext());
		if (!flamingo.isValidApplication()) {
			flamingo.authorize(false, new Flamingo.OnAuthorizeListner() {
				
				public void onComplete(boolean authorizeOk) {
					mContext.startService(new Intent(ACTION_WIDGET_SERVICE));
				}
				
				public void onError(FlamingoError error) {
					mContext.startService(new Intent(ACTION_WIDGET_SERVICE));
				}
				
				public void onCancel() {
					mContext.startService(new Intent(ACTION_WIDGET_SERVICE));
				}
			});
		} 
	}
	
	public void register() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(ACTION_FLAMINGO_TIMING);
		mContext.registerReceiver(INSTANCE, filter);
		mIsRegistered = true;
	}

	public void unregister() {
		if (mIsRegistered) {
			mContext.unregisterReceiver(INSTANCE);
			mIsRegistered = false;
		}
	}

	public boolean isRegistered() {
		return mIsRegistered;
	}
}