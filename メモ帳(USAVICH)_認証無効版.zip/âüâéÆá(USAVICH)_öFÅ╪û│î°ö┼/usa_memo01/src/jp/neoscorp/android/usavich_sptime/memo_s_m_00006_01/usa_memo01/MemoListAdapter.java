package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.MemoApplication.Category;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db.MemoDataBaseAdapter;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.utils.Util;
import android.content.Context;
import android.database.Cursor;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TextView;

public class MemoListAdapter extends BaseAdapter {
	private LayoutInflater mInflater;
	private List<Map<String, Object>> mData; 
	private Context mContext;
	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
	private TableLayout.LayoutParams params;
	public MemoListAdapter(Context context,MemoDataBaseAdapter mDbadapter,MemoApplication memoApp)
	{	
		mContext = context;
		
		this.mInflater = LayoutInflater.from(context);
		mData = getData(mDbadapter,memoApp);
		params = new TableLayout.LayoutParams();
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return  mData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		MemoInforViewHolder holder = null;
		String memoType  = null;
		if (convertView == null) 
		{
			holder = new MemoInforViewHolder();
			convertView = mInflater.inflate(R.layout.memo_list, null);
			holder.memoImg = (ImageView) convertView.findViewById(R.id.memolock_img);
			holder.memoTitle = (TextView) convertView.findViewById(R.id.memo_title);
			holder.memoDate = (TextView) convertView.findViewById(R.id.memo_date);
			holder.momeLinear = (TableLayout)convertView.findViewById(R.id.memo_record_item);	
			holder.itemImg = (ImageView)convertView.findViewById(R.id.itemImage);
			
			convertView.setTag(holder);		
		} 
		else 
		{
			holder = (MemoInforViewHolder) convertView.getTag();
		}
		if(null != mData.get(position).get("memoCategory"))
		{
			memoType = mData.get(position).get("memoCategory").toString();
			switch(Integer.parseInt(memoType))
			{
				case 0:
					holder.itemImg.setBackgroundResource(R.drawable.memo_record_chara01);
					break;
				case 1:
					holder.itemImg.setBackgroundResource(R.drawable.memo_record_chara02);
					break;
				case 2:
					holder.itemImg.setBackgroundResource(R.drawable.memo_record_chara03);
					break;
				case 3:
					holder.itemImg.setBackgroundResource(R.drawable.memo_record_chara04);
					break;
				case 4:
					holder.itemImg.setBackgroundResource(R.drawable.memo_record_chara05);
					break;
				
			}
			if(Util.windowDisplay != null)
			{
				holder.itemImg.setLayoutParams(Util.getLinearLayoutPararm(480, 60, Util.windowDisplay));
				params.height = holder.itemImg.getLayoutParams().height;
				params.width = holder.itemImg.getLayoutParams().width;
				holder.momeLinear.setLayoutParams(params);
			}
		}
		if(mData.get(position).get("memoClockStatus").toString().equals("1"))
		{
			holder.memoImg.setVisibility(View.VISIBLE);
		}
		else
		{
			holder.memoImg.setVisibility(View.GONE);
		}
		holder.memoTitle.setText((String)  mData.get(position).get("memoTitle"));
		 Date date;
		try {
			date = format.parse((String)  mData.get(position).get("memoDate"));
			holder.memoDate.setText(format.format(date));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return convertView;
	}
	
	public final class MemoInforViewHolder 
	{
		public ImageView memoImg;	
		public TextView memoTitle;	
		public TextView memoDate;
		public TableLayout momeLinear;
		public ImageView itemImg;
	}
	
	public static List<Map<String, Object>> getData(MemoDataBaseAdapter mDbadapter, MemoApplication memoApp) 
	{		
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> map = null;
		List<Category> filterList = new ArrayList<Category>();
		Cursor mCursor  = sortList(mDbadapter,memoApp);
		String categoryIndex = null;
		if(mCursor != null && mCursor.getCount() != 0)
		{
			mCursor.moveToFirst();
			for(int i = 0; i < mCursor.getCount(); i++)
			{
				map = new HashMap<String, Object>();
				map.put("memoId", mCursor.getString(mCursor.getColumnIndex(mDbadapter.MEMO_ID)));
				map.put("memoTitle",  mCursor.getString(mCursor.getColumnIndex(mDbadapter.MEMO_TITLE)));
				map.put("memoContent",   mCursor.getString(mCursor.getColumnIndex(mDbadapter.MEMO_CONTENT)));
				map.put("memoDate", mCursor.getString(mCursor.getColumnIndex(mDbadapter.MEMO_DATE)));
				map.put("memoClockStatus",mCursor.getString(mCursor.getColumnIndex(mDbadapter.MEMO_CLOCK_STATUS)));
				categoryIndex = mCursor.getString(mCursor.getColumnIndex(mDbadapter.MEMO_TYPE));
				map.put("memoCategory",categoryIndex);
				if(memoApp !=  null &&  MemoActivity.getFilterList()!= null)
				{
					for(Category category : MemoActivity.getFilterList())
					{
						if(categoryIndex.equals(String.valueOf(category.ordinal())))
						{
							list.add(map);
						}
					}
				}
				
				mCursor.moveToNext();
			}
			
		}
		if(memoApp !=  null && MemoActivity.getFilterList()== null)
		{
			if(!MemoActivity.isFilter())
			{
				filterList.add(Category.DUCK);
				filterList.add(Category.BEAR);
				filterList.add(Category.ELEPHANT);
				filterList.add(Category.GIRAFFE);
				filterList.add(Category.RABBIT);
				MemoActivity.setFilterList(filterList);
			}
		}
		mCursor.close();
		mCursor = null;
		
		return list;
	}
	private static Cursor sortList(MemoDataBaseAdapter mDbadapter, MemoApplication memoApp)
	{
		String sqlWhere = " where 1=1 ";
		Cursor mCursor = null;
		if(null != memoApp)
		{
			if(null != memoApp.getSortName())
			{
				switch(memoApp.getSortName())
				{
					case DATE_ASCENDING: sqlWhere += "ORDER BY MEMO_DATE ASC" ; break;
					case DATE_DESCENDING: sqlWhere += "ORDER BY MEMO_DATE DESC"; break;
					case CONTENT_ASCENDING: sqlWhere += "ORDER BY MEMO_CONTENT ASC";break;
					case CONTENT_DESCENDING: sqlWhere += "ORDER BY MEMO_CONTENT DESC"; break;
				}
			}
			else
			{
					sqlWhere += " ORDER BY MEMO_DATE DESC ";
			}
		}
		
		mCursor = mDbadapter.select(sqlWhere);
		return mCursor;
	}
}
