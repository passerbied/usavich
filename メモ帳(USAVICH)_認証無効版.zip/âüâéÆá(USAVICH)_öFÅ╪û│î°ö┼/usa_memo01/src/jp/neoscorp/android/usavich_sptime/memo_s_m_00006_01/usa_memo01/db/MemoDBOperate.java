package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db;

import java.util.Calendar;

import android.content.Context;
import android.text.format.DateFormat;
import android.util.Log;

public class MemoDBOperate {

	 public static void deleteMemo(Context mContext, String memoId)
	 {
		 MemoDataBaseAdapter mda = new MemoDataBaseAdapter(mContext);
		 mda.open();
		 mda.deleteById(memoId);
		 mda.close();
	 }
	 public static void updateMemo(Context mContext, String memoId, String title, String content, String clockstatus, String category){
		 DateFormat format = new DateFormat();
		 String date = format.format("yyyy-MM-dd hh:mm:ss", Calendar.getInstance()).toString();
		 MemoDataBaseAdapter mda = new MemoDataBaseAdapter(mContext);
		 mda.open();
		 mda.update(memoId, title, content, date, clockstatus, category);
		 mda.close();
	 }
	 public static void addMemo(Context mContext, String title, String content, String clockstatus,String category)
	 {
		 DateFormat format = new DateFormat();
		 String date = format.format("yyyy-MM-dd hh:mm:ss", Calendar.getInstance()).toString();
		 MemoDataBaseAdapter mda = new MemoDataBaseAdapter(mContext);
		 mda.open();
		 mda.insert(title, content, date, clockstatus, category);
		 mda.close();
	 }
}
