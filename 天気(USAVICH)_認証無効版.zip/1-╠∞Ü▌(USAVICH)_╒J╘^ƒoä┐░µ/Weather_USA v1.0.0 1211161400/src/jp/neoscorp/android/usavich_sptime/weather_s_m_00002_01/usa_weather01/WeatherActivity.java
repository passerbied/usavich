package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01;

import java.util.ArrayList;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.UpdateService.MBinder;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Date;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Weather;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.wviews.ScreenConfig;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.wviews.TodayView;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.wviews.WeekView;
import jp.primeworks.android.flamingo.activity.FlamingoActivity;


import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.IBinder;
import android.util.DisplayMetrics;
//import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.FrameLayout.LayoutParams;

public class WeatherActivity extends FlamingoActivity implements OnClickListener {
	public static final String TAG = "WeatherActivity";

	private Context mContext;

	private MBinder mBinder;
	private UServiceConn mConn;
	private RefreshReceiver mReceiver;
	private SettingChangedReceiver mSettingReceiver;

	private Button mUpdateBtn;

	private TextView mTodayDate;
	private TextView mTodayCity;
	private WeekView mWeekView;
	private TodayView mTodayView;
	
	private View mBgIv;
	
	private ArrayList<Weather> mWeatherList;
	private ArrayList<Date> mDateList;

	private ProgressDialog mProgressDialog;
	private float screenW = 480;
	private float screenH = 854;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		Utils.setScreen(this, dm.widthPixels, dm.heightPixels);
		
		screenH = dm.heightPixels;
		screenW = dm.widthPixels;
		
		ScreenConfig.init(dm);
		
		setContentView(R.layout.main);
		mContext = WeatherActivity.this;

		Utils.startService(mContext);

		mConn = new UServiceConn();
		mConn.bind();

		mReceiver = new RefreshReceiver();
		mReceiver.register();
		
		mSettingReceiver = new SettingChangedReceiver();
		mSettingReceiver.register();

		commonInit();
		
	}

	private void commonInit() {
		
		initViews();
		Utils.initInfos(mContext);
		Utils.getInfosFromDB(mContext);
		
		Utils.checkDateMatched(mContext);
		
		setWeatherInfos();
	}
	
	private void initViews() {
		mBgIv = (View) findViewById(R.id.root_main);
		
		int scaleH = (int) ((screenW / 480.0f) * 255);
		LayoutParams params = new LayoutParams(LayoutParams.FILL_PARENT, 
				LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_VERTICAL);
		
		int bound = (int) ((screenW / 480.0f) * 20);
		
		if (screenH > 1000) {
			scaleH += 7;
		} else if (screenH >= 880 && screenH <= 1000) {
			// 调整Frame距顶部距离
		}
		
		params.setMargins(bound, scaleH, bound, 0);
	
		findViewById(R.id.root_main_weather).setLayoutParams(params);
		
		Typeface chaType = Utils.getWeekType(mContext);
//		Typeface numType = Utils.getTodayType(mContext);
		
		mUpdateBtn = (Button) findViewById(R.id.btn_main_update);
		mUpdateBtn.setTypeface(chaType);
		mUpdateBtn.setOnClickListener(this);
		Button setBtn = (Button) findViewById(R.id.btn_main_setting);
		setBtn.setTypeface(chaType);
		setBtn.setOnClickListener(this);

		mProgressDialog = new ProgressDialog(mContext);
		mProgressDialog.setMessage(getString(R.string.connecting_msg));
		mProgressDialog.setCancelable(false);
		
		mTodayDate = (TextView) findViewById(R.id.tv_main_today_date);
		mTodayDate.setTypeface(chaType);
		mTodayDate.setTextSize(ScreenConfig.dateSize);
		mTodayCity = (TextView) findViewById(R.id.tv_main_city);
		mTodayCity.setTypeface(chaType);
		mTodayCity.setTextSize(ScreenConfig.citySize);

		mTodayView = (TodayView) findViewById(R.id.todayview_main);
		mWeekView = (WeekView) findViewById(R.id.weekview_main);
	}
	
	private Bitmap getImageCroped(int resId) {
		Bitmap bitmap = BitmapFactory.decodeResource(getResources(), resId);
		float bmpW = bitmap.getWidth();
		float bmpH = bitmap.getHeight();
		
		float scaleW = screenW;
		float scaleH = bmpH / bmpW * screenW;
		Bitmap newBmp = Bitmap.createScaledBitmap(bitmap, (int) scaleW, (int) scaleH, true);
//		bitmap.recycle();
		
		Bitmap retBmp = Bitmap.createBitmap(newBmp, 0, 0, (int) screenW, (int) screenH);
//		newBmp.recycle();
		
		return retBmp;
	}

	private void setWeatherInfos() {
		mWeatherList = Utils.getWeatherList();
		mDateList = Utils.getDateList();

		if (!mUpdateBtn.isEnabled()) {
			mUpdateBtn.setEnabled(true);
			mUpdateBtn.setText(R.string.update);
		}

		Date todayD = mDateList.get(0);
		int todayDay = todayD.getDay(), todayMon = todayD.getMonth(), todayDate = todayD
				.getDate();
		mTodayDate.setText((todayMon == -1 ? "-" : todayMon) + "月"
				+ (todayDate == -1 ? "-" : todayDate) + "日("
				+ (todayDay == -1 ? "-" : Utils.getDayCast(todayDay)) + ")");
		mTodayCity.setText(Utils.getCity(mContext).getName());
		Weather weather = mWeatherList.get(0);
		mTodayView.setWeather(weather);
		mWeekView.setWeather(mWeatherList, mDateList);
		
		setBackgroundImg(Utils.getBGWeatherById(mContext, weather.getWeatherId()));
	}
	
	private void setBackgroundImg(String weather) {
		int bgId;
		if (weather.equals(Weather.SUNNY)) {
			bgId = R.drawable.bg01;
		} else if (weather.equals(Weather.SNOWY)) {
			bgId = R.drawable.bg03;
		} else if (weather.equals(Weather.RAINY)) {
			bgId = R.drawable.bg04;
		} else if (weather.equals(Weather.CLOUDY)) {
			bgId = R.drawable.bg02;
		} else {
			bgId = R.drawable.bg01;
		}
		
		Bitmap bgBmp = getImageCroped(bgId);
//		Bitmap bgBmp = getImageCroped(R.drawable.bg03);
		mBgIv.setBackgroundDrawable(new BitmapDrawable(bgBmp));
	}

	public void showProgressDlg() {
		mProgressDialog.show();
	}

	public void dismissProgressDlg() {
		if (mProgressDialog.isShowing()) {
			mProgressDialog.dismiss();
		}
	}
	
	private void ifSettingActivityAlive() {
		if (SettingActivity.INSTANCE != null) {
			SettingActivity.INSTANCE.finish();
		}
	}
	
//	@Override
//	 public void onAttachedToWindow() {
//		if (true) {
//			this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
//		}
//		super.onAttachedToWindow();
//	 }
	
//	@Override
//	public boolean onKeyDown(int keyCode, KeyEvent event) {
//	  if (keyCode == KeyEvent.KEYCODE_HOME || keyCode == KeyEvent.KEYCODE_BACK) {
//		  this.finish();
//	  }
//	  return super.onKeyDown(keyCode, event);
//	}
	
	@Override
	protected void onResume() {
		super.onResume();
		ifSettingActivityAlive();
		Utils.sActivityAlive = true;
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		Utils.sActivityAlive = false;
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (Utils.getWidgetIds(mContext).length <= 0) {
			Utils.stopService(mContext);
			Utils.sCanAuto = false;
		}
		if (mConn != null) {
			mConn.unBind();
			mConn = null;
		}
		if (mReceiver != null) {
			mReceiver.unRegister();
			mReceiver = null;
		}
		
		if (mSettingReceiver != null) {
			mSettingReceiver.unRegister();
			mSettingReceiver = null;
		}
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.btn_main_setting:
			Intent intent = new Intent(mContext, SettingActivity.class);
//			startActivityForResult(intent, 1);
			intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			startActivity(intent);
			break;
		case R.id.btn_main_update:
			showProgressDlg();
			mUpdateBtn.setEnabled(false);
			mUpdateBtn.setText(R.string.updating);
			mBinder.update();
			break;
		default:
			break;
		}
	}
	
	class RefreshReceiver extends BroadcastReceiver {

		public void register() {
			IntentFilter filter = new IntentFilter();
			filter.addAction(Utils.ACTION_DATA_RECEIVED);
			registerReceiver(this, filter);
		}

		public void unRegister() {
			unregisterReceiver(this);
		}

		@Override
		public void onReceive(Context context, Intent intent) {
//			int status = intent.getIntExtra(Utils.CONN_CODE, 1);
			boolean needRefresh = intent.getBooleanExtra(Utils.NEED_TO_REFRESH,
					true);
//			Log.v(TAG, "Activity - Update broadcast received! Status: "
//					+ status);
			if (needRefresh) {
				setWeatherInfos();
				dismissProgressDlg();
			} else {
				dismissProgressDlg();
			}
		}
	}
	
	class SettingChangedReceiver extends BroadcastReceiver {

		public void register() {
			IntentFilter filter = new IntentFilter();
			filter.addAction(getPackageName() + "/SettingChanged");
			registerReceiver(this, filter);
		}

		public void unRegister() {
			unregisterReceiver(this);
		}

		@Override
		public void onReceive(Context ctxt, Intent data) {
			if (data != null) {
//				boolean neend = data.getBooleanExtra("need-finish", false);
//				if (neend) {
//					return;
//				}
					
				boolean isChanged = data.getBooleanExtra(Utils.SETTING_CHANGED, false);
				long rate = Utils.getUpdateRate();
				if (rate == 0) {
					mBinder.cancelServiceTimer();
				} else if (rate > 0) {
					mBinder.resetTimer();
				}

				if (isChanged && rate > 0) {
					mBinder.update();
					mBinder.resetUpdateCount();
				} else {
					Utils.getInfosFromDB(mContext);
					setWeatherInfos();
					Utils.updateWidget(mContext);
				}
			}
		}
	}

	class UServiceConn implements ServiceConnection {
		public void bind() {
			bindService(new Intent(Utils.ACTION_UPDATESERVICE), this,
					BIND_AUTO_CREATE);
		}

		public void unBind() {
			unbindService(this);
		}

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			mBinder = (MBinder) service;
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
		}
	}
}