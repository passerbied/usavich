package jp.primeworks.android.flamingo.widget;

import jp.primeworks.android.flamingo.R;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;

public class AdView extends LinearLayout {

    public AdView(Context context) {
        this(context, null);
    }

    public AdView(Context context, AttributeSet attrs) {
        super(context, attrs);
        
        setGravity(Gravity.CENTER);
        setLayoutParams(new LayoutParams(0, 0));
        
        setClickable(true);
        setFocusable(true);
        setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setData(Uri.parse(getContext().getString(R.string.ad_uri)));
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                try {
                    getContext().startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    // FIXME: worning message
                }
            }
        });
        
        int adBannerId = getResources().getIdentifier("ad_banner", "drawable", context.getPackageName());
        if(adBannerId > 0) {
            ImageView imageView = new ImageView(context);
            imageView.setImageResource(adBannerId);
            imageView.setScaleType(ScaleType.FIT_CENTER);
            DisplayMetrics metrics = getContext().getResources().getDisplayMetrics();
            addView(imageView, new LayoutParams(
                    (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 320, metrics),
                    (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 48, metrics)));
            
            return;
        }

        adBannerId = getResources().getIdentifier("ad_banner", "layout", context.getPackageName());
        if(adBannerId > 0) {
            LayoutInflater inflator = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            inflator.inflate(adBannerId, this);

            return;
        }
        
        setVisibility(View.GONE);
    }

    public static boolean isVisibleBanner(Context context) {
        if((context.getResources().getIdentifier("ad_banner", "drawable", context.getPackageName()) > 0)) {
            return true;
        }
        
        return false;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if(getVisibility() != View.GONE) {
            DisplayMetrics metrics = getContext().getResources().getDisplayMetrics();
            int width = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 320, metrics);
            int height = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 48, metrics);
            
            setMeasuredDimension(width, height);
            //super.onMeasure(width, height);
        }
    }

}
