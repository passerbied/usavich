package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;

import java.util.List;
import java.util.Map;

import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db.MemoDBOperate;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db.MemoDataBaseAdapter;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.utils.Util;
import jp.primeworks.android.flamingo.activity.FlamingoActivity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MemoEditActivity extends FlamingoActivity implements OnTouchListener, View.OnCreateContextMenuListener {
	private Button btn_back;
	private Button animalChoose,addPassword;
	private Intent editIntent;
	private String memoTitle;
	private String clockStatus;
	private EditTestText editContent;
	private Button btn_del,shortCutBtn,sendEmail,addMemo;
	private GestureDetector detector;
	private List<Map<String,Object>> mData;
	private MemoApplication memoApp;
	private String memoId,categoryStr;
	private int position;
	private String category,saveCategpry;
	private RelativeLayout linearContent;
	private RelativeLayout relative;
	private TextView memoEditTitle;
	private ImageView editBg,animalTopBg;
	private boolean isDoubleClick;
	private DisplayMetrics dm;
	private static final int SWIPE_MAX_OFF_PATH = 200;
	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_THRESHOLD_VELOCITY = 120;
	private static final String DEFAULT_CONTENT = "ダブルタップして編集してね。";
	private MemoSharedPreferences shortcutShared;
	private boolean isCategoryChange = false,isPasswordStatusChange = false;
	private Dialog categoryDialog;
	public static boolean mbBackanimalChooseActionStatus = false,mbBackanimalAddActionStatus = false;
	private static final String TAG = "MemoEditActivity";
	private boolean mbBackEditActionStatus = false , keybordChange = false;
	private static final int HAS_CHANGE = 1;
	private static final int NO_CHANGE = 0;
	private RelativeLayout.LayoutParams params,alphaParams;
	private View bottom,alphaLinear;
	private  int bottomH,topMargin,popupHight;
	private static String APP_CLOSE_ACTION = "com.taiyo.memoedit.action.APP_CLOSE_ACTION";
	public static MemoEditActivity editActivity;
	private CommonReceiver mCommonReceiver;
		@Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.memo_edit);
	        // modified by 2012-11-02
	        mCommonReceiver = new CommonReceiver();
			mCommonReceiver.register();
			editActivity = this;
	    }
		protected void onResume()
		{
			super.onResume();
			reload();
		}	
	 private void reload()
	 {
		 shortcutShared = new MemoSharedPreferences(this);
	        memoApp = (MemoApplication)this.getApplication();
	        mData = memoApp.getPositionMap();
	        if (mData == null) {
		        MemoDataBaseAdapter mdba = new MemoDataBaseAdapter(this);
		        mdba.open();
		        mData = MemoListAdapter.getData(mdba,memoApp);
			}
	        dm = new DisplayMetrics();
	        getWindowManager().getDefaultDisplay().getMetrics(dm);
	        linearContent = (RelativeLayout)findViewById(R.id.linearContent);
	        relative = (RelativeLayout)findViewById(R.id.relativeLayout);
	        editContent = (EditTestText)findViewById(R.id.editContent);
	        btn_del = (Button)findViewById(R.id.delBtn);
	        btn_del.setLayoutParams(Util.getLinearLayoutPararm(96, 62, dm));
	        
	        bottom = findViewById(R.id.bottomLinear);
	        //modified 2012-10-24
	        animalTopBg = (ImageView)findViewById(R.id.animalTopBg);
	        animalTopBg.setLayoutParams(Util.getLinearLayoutPararm(480, 280, dm));
	        final LinearLayout.LayoutParams animalTopParams =(LinearLayout.LayoutParams)animalTopBg.getLayoutParams();
	        
	        alphaLinear = findViewById(R.id.alphaLayout);
	        alphaParams = (RelativeLayout.LayoutParams)alphaLinear.getLayoutParams();
	        
			final LinearLayout.LayoutParams btnparams = (LinearLayout.LayoutParams) btn_del.getLayoutParams();
			params = (RelativeLayout.LayoutParams)bottom.getLayoutParams();
			bottomH = btnparams.height;
			final InputHandler mHandler = new InputHandler(); 
			
			editContent.getBackground().setAlpha(0);
			editContent.setSizeChangedListener(new EditTestText.OnSizeChangedListener() {
				
				@Override
				public void onTextSizeChanged(boolean needVisible , int changeSize) {
						
						 Message msg = new Message(); 
			             msg.what = 1; 
			             if(needVisible)
			             {
			            	 msg.arg1 = HAS_CHANGE; 
			            	 int screenHeight = getWindowManager().getDefaultDisplay().getHeight();
			            	 int animalHeight = animalTopParams.height;
			            	 popupHight= screenHeight - changeSize - animalHeight - Util.dip2px(MemoEditActivity.this, 52);
			            	 if(keybordChange == false)
			            	 {
			            		 topMargin =  -(popupHight/4);
			            		 keybordChange = true;
			            	 }
			            		 
			             }
			             else
			             {
			            	 msg.arg1 = NO_CHANGE;
			             }
			            
			             
			             mHandler.sendMessage(msg); 
						
				}
			});
			
	        editIntent = getIntent();
	        
	        clockStatus = Util.UN_PASSWORD_STATUS;
	        memoEditTitle = (TextView)findViewById(R.id.memoEditTitle);
	        memoEditTitle.setTypeface(Util.setMediumFont(this));
	        
	        if(editIntent != null )
	        {
	        	if(editIntent.getStringExtra("category") != null)
	        	{
//	        		String shortcutCategory = shortcutShared.loadShortCut("memoId",MemoSharedPreferences.SHORTCUT_CATEGORY);
	        		category = editIntent.getStringExtra("category");
//	        		if(!shortcutCategory.equals(""))
//	        		{
//	        			category = shortcutCategory;
//	        		}
//	        		saveCategpry = category;
	        		showCategory(category);
	        	}
	        	if(editIntent.getStringExtra("memoId") != null)
	        	{
		        	memoId = editIntent.getStringExtra("memoId");
		        	if(null != editIntent.getStringExtra("shortcut"))
		        	{
		        		int positionNum = 0;
		        		for(Map<String, Object> data : mData)
		        		{
		        			if(data.get("memoId").toString().equals(memoId))
		        			{
		        				position = positionNum;
		        			}
		        			positionNum ++ ;
		        		}
		        		
		        	}
		        	else if(null != editIntent.getStringExtra("position"))
		        	{
		        		position = Integer.parseInt(editIntent.getStringExtra("position"));	
		        	}
		        }
	        }
	        
			editContent.setFocusable(false);
			editContent.setOnLongClickListener(new View.OnLongClickListener() {
				
				@Override
				public boolean onLongClick(View v) {
					if(isDoubleClick)
						return false;
					else
						return true;
				}
			});
	        detector = new GestureDetector(this, new LearnGestureListener());
	        editContent.setOnTouchListener(this);
	        relative.setOnTouchListener(new View.OnTouchListener() {
				
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					return detector.onTouchEvent(event); 
				}
			});
	        relative.setLongClickable(true);
	        
	        if(null != editIntent && memoId!= null){
	        	showMemo(this,memoId);
	        }
	        //delete
	        btn_del.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					if(null != editIntent &&  memoId!= null){
						
					AlertDialog dialog = null;
					final Builder passwordbuilder = new android.app.AlertDialog.Builder(MemoEditActivity.this);
					passwordbuilder.setTitle("パスワード入力");
					if(clockStatus.equals(Util.HAS_PASSWORD_STATUS))
			        {
						//パスワード入力dialog
						
			        	LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
			            View view = inflater.inflate(R.layout.memo_check_password, null); 
			            final EditText currentPwdEdit = (EditText)view.findViewById(R.id.current_password);
			            passwordbuilder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
				        {
				            public void onClick(DialogInterface dialog, int which) 
				            {
				            	dialog.dismiss();     	
				            }
				        });
			            passwordbuilder.setNegativeButton("OK", new DialogInterface.OnClickListener()
				        {
				            public void onClick(DialogInterface dialog, int which) 
				            {
				            	String currentPwdStr = currentPwdEdit.getText().toString().trim();
				            	if(memoApp.getMemoPassword() != null)
			                    {
				            		 if(currentPwdStr.equals(memoApp.getMemoPassword()))
			                    	  {
				            			 	delMemoDialog();
			         						dialog.dismiss();
			                    	  }
				            		 else
				            		 {
//				            			 dialog.dismiss();
				            			 Util.WrongPassword(MemoEditActivity.this);
				            		 }
			                    }
				            	else
			                    {
			                    	  if(currentPwdStr.equals(MemoActivity.DEFAULT_PASSWORD))
			                    	  {
			                    		  	  delMemoDialog();
			                    			  dialog.dismiss();
			                    	  }	
			                    	  else
			                    	  {
					            			 Util.WrongPassword(MemoEditActivity.this);
//					            			 dialog.dismiss();
			                    	  }
			                    }
				            }
				        });
			             dialog = passwordbuilder.create();
					     dialog.setView(view,0,0,0,0);
					     dialog.show();
			        }
					else
					{
						delMemoDialog();	
					}
				}
				}
			});
	        btn_back = (Button)findViewById(R.id.backBtn);
	        btn_back.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
				
					if(mbBackEditActionStatus == false)
					{
						mbBackEditActionStatus = true;
						backSave();
						if(editIntent.getStringExtra("shortcut") != null)
						{
							sendBroadcast(new Intent(APP_CLOSE_ACTION));
						}	
						if(editIntent.getStringExtra("shortcut") != null)
						{
							startActivity(new Intent(MemoEditActivity.this,MemoActivity.class));
						}
						MemoEditActivity.this.finish();
						
					}
				}
			});
	        animalChoose = (Button)findViewById(R.id.animalChoose); 
	        animalChoose.setLayoutParams(Util.getLinearLayoutPararm(96, 62, dm));
	        animalChoose.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					if(mbBackanimalChooseActionStatus == false)
					{
						
						mbBackanimalChooseActionStatus = true;
						Intent intent = new Intent(MemoEditActivity.this,MemoEditActivity.class);
						if(editIntent.getStringExtra("shortcut") != null)
						{
							intent.putExtra("shortcut", "shortcut");
						}
						 
						categoryDialog = new Dialog(MemoEditActivity.this,R.style.AlertDialog);
						
						LayoutInflater inflater=(LayoutInflater)MemoEditActivity.this.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);  
				        inflater =  categoryDialog.getLayoutInflater();
				        View view = inflater.inflate(R.layout.memo_category, null); 
				        final RadioButton radio01 = (RadioButton)view.findViewById(R.id.radio0);
//				        radio01.setLayoutParams(Util.getRadioGroupPararm(75,dm));
				        final RadioButton radio02 = (RadioButton)view.findViewById(R.id.radio1);
//				        radio02.setLayoutParams(Util.getRadioGroupPararm(75,dm));
				        final RadioButton radio03 = (RadioButton)view.findViewById(R.id.radio2);
//				        radio03.setLayoutParams(Util.getRadioGroupPararm(75,dm));
				        final RadioButton radio04 = (RadioButton)view.findViewById(R.id.radio3);
//				        radio04.setLayoutParams(Util.getRadioGroupPararm(75,dm));
				        final RadioButton radio05 = (RadioButton)view.findViewById(R.id.radio4);
				        radio01.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
							
							@Override
							public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
								if(isChecked)
								{
									radio02.setChecked(false);
									radio03.setChecked(false);
									radio04.setChecked(false);
									radio05.setChecked(false);
									categoryStr = "0";
								}	
							}
						});
				        radio02.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
							
							@Override
							public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
								if(isChecked)
								{
									radio01.setChecked(false);
									radio03.setChecked(false);
									radio04.setChecked(false);
									radio05.setChecked(false);
									categoryStr = "1";
								}	
							}
						});
				        radio03.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
							
							@Override
							public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
								if(isChecked)
								{
									radio01.setChecked(false);
									radio02.setChecked(false);
									radio04.setChecked(false);
									radio05.setChecked(false);
									categoryStr = "2";
								}	
							}
						});
				        radio04.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
							
							@Override
							public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
								if(isChecked)
								{
									radio01.setChecked(false);
									radio02.setChecked(false);
									radio03.setChecked(false);
									radio05.setChecked(false);
									categoryStr = "3";
								}	
							}
						});
				        radio05.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
							
							@Override
							public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
								if(isChecked)
								{
									radio01.setChecked(false);
									radio02.setChecked(false);
									radio03.setChecked(false);
									radio04.setChecked(false);
									categoryStr = "4";
								}	
							}
						});
				        if(category != null)
				        {
				        	switch(Integer.parseInt(category))
				        	{
					        	case 0:radio01.setChecked(true);break;
				        		case 1:radio02.setChecked(true);break;
				        		case 2:radio03.setChecked(true);break;
				        		case 3:radio04.setChecked(true);break;
				        		case 4:radio05.setChecked(true);break;
				        	}
				        }
				        
				        ImageView memo_dialog_chara01 = (ImageView)view.findViewById(R.id.memo_dialog_chara01);
				        memo_dialog_chara01.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
				        memo_dialog_chara01.setOnClickListener(new View.OnClickListener() {
							
							@Override
							public void onClick(View v) {
								radio01.setChecked(true);
							}
						});
				        ImageView memo_dialog_chara02 = (ImageView)view.findViewById(R.id.memo_dialog_chara02);
				        memo_dialog_chara02.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
				        memo_dialog_chara02.setOnClickListener(new View.OnClickListener() {
							
							@Override
							public void onClick(View v) {
								radio02.setChecked(true);
							}
						});
				        ImageView memo_dialog_chara03 = (ImageView)view.findViewById(R.id.memo_dialog_chara03);
				        memo_dialog_chara03.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
				        memo_dialog_chara03.setOnClickListener(new View.OnClickListener() {
							
							@Override
							public void onClick(View v) {
								radio03.setChecked(true);
							}
						});
				        ImageView memo_dialog_chara04 = (ImageView)view.findViewById(R.id.memo_dialog_chara04);
				        memo_dialog_chara04.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
				        memo_dialog_chara04.setOnClickListener(new View.OnClickListener() {
							
							@Override
							public void onClick(View v) {
								radio04.setChecked(true);
							}
						});
				        ImageView memo_dialog_chara05 = (ImageView)view.findViewById(R.id.memo_dialog_chara05);
				        memo_dialog_chara05.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
				        memo_dialog_chara05.setOnClickListener(new View.OnClickListener() {
							
							@Override
							public void onClick(View v) {
								radio05.setChecked(true);
							}
						});
				        categoryDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
							
							@Override
							public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
								if (keyCode == KeyEvent.KEYCODE_BACK)
								{
									MemoEditActivity.mbBackanimalChooseActionStatus = false;
								}
								return false;
							}
						});
				        
//				        final RadioGroup  radioGroup = (RadioGroup)view.findViewById(R.id.radioGroup1);
				        Button decisionBtn = (Button)view.findViewById(R.id.decisionBtn);
				        decisionBtn.setTypeface(Util.setLightFont(MemoEditActivity.this));
				        decisionBtn.setOnClickListener(new View.OnClickListener() {
							
							@Override
							public void onClick(View v) {
//								switch(radioGroup.getCheckedRadioButtonId())
//								{
//									case  R.id.radio0: 
//										categoryStr = "0";
//									break;
//									case  R.id.radio1: 
//										categoryStr = "1";
//									break;
//									case  R.id.radio2: 
//										categoryStr = "2";
//									break;
//									case  R.id.radio3: 
//										categoryStr = "3";
//									break;
//									case  R.id.radio4: 
//										categoryStr = "4";
//									break;
//								}
								
								MemoEditActivity.mbBackanimalChooseActionStatus = false;
								if(categoryStr != null && !categoryStr.equals(""))
								{
									if(!categoryStr.equals(category))
									{
										category = categoryStr;
										showCategory(categoryStr);
										isCategoryChange = true;
									}
									
								}
								categoryDialog.dismiss();
							}
						});
				        categoryDialog.setContentView(view);
				        categoryDialog.show();
					}
				}
			});
	        addPassword = (Button)findViewById(R.id.addPassword);
	        addPassword.setLayoutParams(Util.getLinearLayoutPararm(96, 62, dm));
	        addPassword.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					AlertDialog dialog = null;
					Builder builder = new android.app.AlertDialog.Builder(MemoEditActivity.this);
			        builder.setIcon(null);
			        if(clockStatus == null || clockStatus.equals(Util.UN_PASSWORD_STATUS))
			        {
			        	//builder.setTitle("パスワード追加しますか？");
			        	builder.setTitle("パスワード入力");
			        	LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
			            View view = inflater.inflate(R.layout.memo_check_password, null); 
			            final EditText currentPwdEdit = (EditText)view.findViewById(R.id.current_password);
			            builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
				        {
				            public void onClick(DialogInterface dialog, int which) 
				            {
				            	dialog.dismiss();     	
				            }
				        });
				        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
				        {
				            public void onClick(DialogInterface dialog, int which) 
				            {
				            	String currentPwdStr = currentPwdEdit.getText().toString().trim();
				            	if(memoApp.getMemoPassword() != null)
			                    {
				            		 if(currentPwdStr.equals(memoApp.getMemoPassword()))
			                    	  {
			                    		 clockStatus = Util.HAS_PASSWORD_STATUS;
//			                    		 memoApp.setCheckPasswordStatus(false);
			                    		 addPassword.setBackgroundResource(R.drawable.memo_footer_icon01_push);
			                    		 dialog.dismiss();
			                    	  }
				            		 else
				            		 {
//				            			 dialog.dismiss();
				            			 Util.WrongPassword(MemoEditActivity.this);
				            		 }
			                    }
				            	else
			                    {
			                    	  if(currentPwdStr.equals(MemoActivity.DEFAULT_PASSWORD))
			                    	  {
			                    		  clockStatus = Util.HAS_PASSWORD_STATUS;
//			                    		  memoApp.setCheckPasswordStatus(false);
			                    		  addPassword.setBackgroundResource(R.drawable.memo_footer_icon01_push);
			                    		  dialog.dismiss();
			                    	  }
			                    	  else
			                    	  {
					            			 Util.WrongPassword(MemoEditActivity.this);
//					            			 dialog.dismiss();
			                    	  }
			                    }
				            	isPasswordStatusChange = true;
				            	dialog.dismiss();
				            }
				        });
				        dialog = builder.create();
				        dialog.setView(view,0,0,0,0);
				        dialog.show();
			        }
			        else if(clockStatus.equals(Util.HAS_PASSWORD_STATUS))
			        {
					    clockStatus = Util.UN_PASSWORD_STATUS;
					    memoApp.setCheckPasswordStatus(true);
					    addPassword.setBackgroundResource(R.drawable.memo_footer_icon01);
			        }
			        
					
				}
			});
	        shortCutBtn = (Button)findViewById(R.id.shortCutBtn);
	        shortCutBtn.setLayoutParams(Util.getTableRowPararm(96, 62, dm));
	        shortCutBtn.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					if(null != editIntent &&  memoId!= null){
						String title = Util.truncationString(editContent.getText().toString(), 6);
						if(null == title || "".equals(title))
						{
							title = " ";
						}
						Builder builder = new android.app.AlertDialog.Builder(MemoEditActivity.this);
				        builder.setIcon(null);
				        builder.setTitle(title);
				        builder.setMessage("ショートカット作成しますか？");
				        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
				        {
				            public void onClick(DialogInterface dialog, int which) 
				            {
				            	dialog.dismiss();     	
				            }
				        });
				        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
				        {
				            public void onClick(DialogInterface dialog, int which) 
				            {
				            	String subTitle = editContent.getText().toString();
				            	if(subTitle.length() > 0 && !subTitle.equals(DEFAULT_CONTENT)){
				            		sendToLauncher();
				            		backSave();
				            	}
				            	dialog.dismiss();
				            }
				        });
				        
				        builder.show();
						
					}
				}
			});
	        sendEmail = (Button)findViewById(R.id.sendEmail);
	        sendEmail.setLayoutParams(Util.getLinearLayoutPararm(96, 62, dm));
	        sendEmail.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					 String content = editContent.getText().toString();
					 String  emailSubject = "";
					 String emailBody = "";
//					 Intent email = new Intent(android.content.Intent.ACTION_SEND);
//					 email.setType("plain/text");
//					 String[] emailReciver = new String[]{};
					 if(!editContent.getText().toString().equals(DEFAULT_CONTENT)
							 || editContent.getText().toString().equals(""))
					 {
						 emailBody = content;
						 emailSubject = Util.truncationString(editContent.getText().toString(),20);
					 }
//					 	 
//					 
//					 email.putExtra(android.content.Intent.EXTRA_EMAIL, emailReciver);
//					 email.putExtra(android.content.Intent.EXTRA_SUBJECT, emailSubject);
//					 email.putExtra(android.content.Intent.EXTRA_TEXT, emailBody);
//					 startActivity(Intent.createChooser(email, "メールへ転送"));
//					 startActivity(email);
					 Intent intent = new Intent(); 
					 intent.setAction(Intent.ACTION_SENDTO);

					 intent.setData(android.net.Uri.parse("mailto:"));
					 intent.putExtra(Intent.EXTRA_SUBJECT, emailSubject);
					 intent.putExtra(Intent.EXTRA_TEXT, emailBody);

					 try {
					     startActivity(intent);
					 } catch (ActivityNotFoundException e) {
					     Log.e(TAG,"ActivityNotFoundException e =" + e.getMessage());
					 }
				}
			});
	        addMemo = (Button)findViewById(R.id.addMemo);
	        addMemo.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					if(mbBackanimalAddActionStatus == false)
					{
						mbBackanimalAddActionStatus = true;
						Intent intent = new Intent(MemoEditActivity.this,MemoEditActivity.class);
						intent.putExtra("CreateFromEdit", "true");
						if(editIntent.getStringExtra("shortcut") != null)
						{
							intent.putExtra("shortcut", "shortcut");
						}
						CategoryDialog categorydialog = new CategoryDialog(MemoEditActivity.this,intent);
						categorydialog.showCategoryDialog(getWindowManager().getDefaultDisplay().getWidth()
												,getWindowManager().getDefaultDisplay().getHeight(),
												dm
												,1
												);
					}
				}
			});
	        if(!editContent.getText().toString().equals(""))
	        {
	        	editContent.setText(Util.EmailConvert(editContent.getText().toString()));
	 	       
	        }else
	        {
	        	editContent.setText(DEFAULT_CONTENT);
	        }
	         
	        if(clockStatus.equals(Util.HAS_PASSWORD_STATUS))
	        {
	        	addPassword.setBackgroundResource(R.drawable.memo_footer_icon01_push);
	        }
	        else
	        {
	        	addPassword.setBackgroundResource(R.drawable.memo_footer_icon01);
	        }
	 }
	 //戻るボタン/BACK KEY 
	 private void backSave()
	 {
		 String subTitle = editContent.getText().toString();
		 memoTitle = Util.truncationString(editContent.getText().toString(), 6);
			if(null != editIntent && memoId != null){
				if(subTitle.length() > 0 && !subTitle.equals(DEFAULT_CONTENT)){
					MemoDBOperate.updateMemo(MemoEditActivity.this,
							memoId,
							memoTitle,
							subTitle,
							clockStatus,
							category
					);
					//ショートカット エディタ
//					resetShortCut();
					
				}
	        }else{
	        	
	        	if(subTitle.length() > 0 && !subTitle.equals(DEFAULT_CONTENT)){
	        		MemoDBOperate.addMemo(MemoEditActivity.this,memoTitle,subTitle,String.valueOf(clockStatus), category);
		        }
	        }
			
	 }
	 //ショートカット エディタ
	 private void resetShortCut()
	 {
		String shortCutName = shortcutShared.loadShortCut(memoId, MemoSharedPreferences.SETTING_SHORTCUT);
		if(!shortCutName.equals(""))
		{
			if(!shortCutName.equals(Util.truncationString(editContent.getText().toString(),6)))
			{
				deleteFromLauncher(memoId,shortCutName);
				saveCategpry = category;
				sendToLauncher();
			}
			else if(isCategoryChange)
			{
				deleteFromLauncher(memoId,shortCutName);
				saveCategpry = category;
				sendToLauncher();
				isCategoryChange = false;
			}
		}
	 }
	 
	 private void showCategory(String category)
	 {
		 switch(Integer.parseInt(category))
 		{
 			case 0: animalTopBg.setImageResource(R.drawable.memo_tpl01);
// 					linearContent.setBackgroundColor(Color.parseColor("#fdf6cc"));
 					linearContent.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.memo_tpl_bg01));
// 					relative.setBackgroundColor(Color.parseColor("#fdf6cc"));
 					break;
 			case 1: animalTopBg.setImageResource(R.drawable.memo_tpl02);
// 					linearContent.setBackgroundColor(Color.parseColor("#fcd8da"));
 					linearContent.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.memo_tpl_bg02));
// 					relative.setBackgroundColor(Color.parseColor("#fcd8da"));
 					break;
 			case 2: animalTopBg.setImageResource(R.drawable.memo_tpl03);
// 					linearContent.setBackgroundColor(Color.parseColor("#dbf2f0"));
 					linearContent.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.memo_tpl_bg03));
// 					relative.setBackgroundColor(Color.parseColor("#dbf2f0"));
 					break;
 			case 3: animalTopBg.setImageResource(R.drawable.memo_tpl04);
// 					linearContent.setBackgroundColor(Color.parseColor("#dfec94"));
 					linearContent.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.memo_tpl_bg04));
// 					relative.setBackgroundColor(Color.parseColor("#dfec94"));
 					break;
 			case 4: animalTopBg.setImageResource(R.drawable.memo_tpl05);
				linearContent.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.memo_tpl_bg05));
				break;
 		}
//		 relative.getBackground().setAlpha(100);
	 }
	//ショートカット
	private void sendToLauncher() {
		int resourceId = 0;
		Intent shortcutIntent = null;
//		String category = editIntent.getStringExtra("category");
		String mMemoSCName = Util.truncationString(editContent.getText().toString(),6);
		Intent sender = new Intent();
		shortcutIntent = new Intent(MemoEditActivity.this, SCConfimActivity.class);
		shortcutIntent.setAction(Intent.ACTION_VIEW);
		shortcutIntent.putExtra("memoId", memoId);
		shortcutIntent.putExtra("position", String.valueOf(position));
//		shortcutIntent.putExtra("category", category);
		shortcutIntent.putExtra("shortcut", "shortcut");
		shortcutIntent.putExtra("checkPasswordStatus", String.valueOf(memoApp.isCheckPasswordStatus()));
		
		sender.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
		sender.putExtra(Intent.EXTRA_SHORTCUT_NAME, mMemoSCName);
		if(null != category)
		{
			switch(Integer.parseInt(category))
			{
				case 0:resourceId = R.drawable.memo_sc01;break;
				case 1:resourceId = R.drawable.memo_sc02;break;
				case 2:resourceId = R.drawable.memo_sc03;break;
				case 3:resourceId = R.drawable.memo_sc04;break;
				case 4:resourceId = R.drawable.memo_sc05;break;
			}
		}
//		sender.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
//				Intent.ShortcutIconResource.fromContext(getApplicationContext(),
//						resourceId));
		sender.putExtra(Intent.EXTRA_SHORTCUT_ICON,((BitmapDrawable)
				getResources().getDrawable(resourceId)).getBitmap());
		sender.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
//		shortcutShared.saveSettingSort(memoId,mMemoSCName,MemoSharedPreferences.SETTING_SHORTCUT);
//		shortcutShared.saveSettingSort(memoId,saveCategpry,MemoSharedPreferences.SHORTCUT_CATEGORY);
		sendBroadcast(sender);
	}
	
	//ショートカット削除
	private void deleteFromLauncher(String key, String shoutCutName) {
		Intent shortcut = new Intent(
				"com.android.launcher.action.UNINSTALL_SHORTCUT");
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_NAME, shoutCutName);
		Intent respondIntent = new Intent(this, SCConfimActivity.class);
		respondIntent.setAction(Intent.ACTION_VIEW);
		shortcut.putExtra(Intent.EXTRA_SHORTCUT_INTENT, respondIntent);
		shortcutShared.removeSettingSort(key , MemoSharedPreferences.SETTING_SHORTCUT);
		shortcutShared.removeSettingSort(key , MemoSharedPreferences.SHORTCUT_CATEGORY);
		sendBroadcast(shortcut);
		
	} 
	
	 private void showMemo(Context mContext, String memoId)
	 {
		 MemoDataBaseAdapter mda = new MemoDataBaseAdapter(mContext);
		 mda.open();
		 Cursor mCursor  =  mda.selectById(memoId);
		 if(mCursor != null && mCursor.getCount() != 0)
			{
				mCursor.moveToFirst();
				for(int i = 0; i < mCursor.getCount(); i++)
				{
					editContent.setText(mCursor.getString(mCursor.getColumnIndex(mda.MEMO_CONTENT)));
					clockStatus = mCursor.getString(mCursor.getColumnIndex(mda.MEMO_CLOCK_STATUS));
					mCursor.moveToNext();
				}
			}
		 mda.close();
	 }
	 public class LearnGestureListener extends GestureDetector.SimpleOnGestureListener{
		 
		 @Override
		 public boolean onSingleTapUp(MotionEvent ev) {
//			 editContent.setInputType(InputType.TYPE_NULL); // disable soft input      
			 return false;
		 }
		 @Override
		 public void onShowPress(MotionEvent ev) {
		 }
		 @Override
		 public void onLongPress(MotionEvent ev) {
			 super.onLongPress(ev);
		 }
		 @Override
		 public boolean onScroll(MotionEvent e1, MotionEvent e2,  float distanceX, float distanceY) {
			 
			 return false;
		 }
		 @Override
		 public boolean onDown(MotionEvent ev) {
			 
			 return false;
		 }
		 @Override
		 public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				 float velocityY) {
			 if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
					return false;
			 
				int offset = 0;
				if(!isDoubleClick)
				{
					if(clockStatus.equals(Util.HAS_PASSWORD_STATUS))
				    {
				       addPassword.setBackgroundResource(R.drawable.memo_footer_icon01_push);
				    }
					else
					{
						addPassword.setBackgroundResource(R.drawable.memo_footer_icon01);
					}
					if(e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
							&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY)
					{
						offset = 1;
						for(int i=0 ; i<mData.size() ; i++)
						{
							if(position - offset >= 0 && null != mData.get(position - offset))
							{
								if(mData.get(position - offset).get("memoClockStatus").toString().equals(Util.UN_PASSWORD_STATUS))
								{
									editContent.setText(mData.get(position - offset).get("memoContent").toString());
									memoId = mData.get(position - offset).get("memoId").toString();
									category = mData.get(position - offset).get("memoCategory").toString();
									clockStatus = mData.get(position - offset).get("memoClockStatus").toString();
									showCategory(category);
									editIntent.putExtra("category", category);
									position = position - offset;
									
									break;
								}
								else
								{
									offset++;
								}
							}
						}
					}else if(e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
							&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY)
					{
						offset = 1;
						for(int i=0 ; i<mData.size() ; i++)
						{
							if(position + offset<= mData.size()-1 && null != mData.get(position + offset))
							{
								if(mData.get(position + offset).get("memoClockStatus").toString().equals(Util.UN_PASSWORD_STATUS))
								{
									editContent.setText(mData.get(position + offset).get("memoContent").toString());
									memoId = mData.get(position + offset).get("memoId").toString();
									category = mData.get(position + offset).get("memoCategory").toString();
									clockStatus = mData.get(position + offset).get("memoClockStatus").toString();
									showCategory(category);
									editIntent.putExtra("category", category);
									position = position + offset;
									break;
								}
								else
								{
									offset++;
								}
							}
						}
					}
					editContent.setFocusable(false);
			}
			 return true;
		 }
		 public boolean onDoubleTap(MotionEvent event){
			 editContent.setFocusableInTouchMode(true);
//			 int inType = editContent.getInputType();
//			 editContent.setInputType(inType);
			 //editContent.setInputType(InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE); // disable soft input
//		
			 detector.onTouchEvent(event);
			 isDoubleClick = true;
			 if(editContent.getText().toString().equals(DEFAULT_CONTENT))
			 {
				 editContent.setText("");
			 }
			 return true;
		 }
	 }
	 
	 public boolean onKeyDown(int keyCode, KeyEvent event) 
	 {
		 switch(keyCode)
		 {
			 case KeyEvent.KEYCODE_BACK:
				 backSave();
				 
				 if(editIntent.getStringExtra("shortcut") != null)
				 {
					 Intent intent = new Intent(MemoEditActivity.this,MemoActivity.class);
					 startActivity(intent);
				 }
				 if(editIntent.getStringExtra("shortcut") != null)
				 {
					 sendBroadcast(new Intent(APP_CLOSE_ACTION));
				 }	
				 MemoEditActivity.this.finish();
				 break;
		 }
		 return super.onKeyDown(keyCode, event);
	 }
	
	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
	
		 return detector.onTouchEvent(event);
	} 
	// 削除MEMO dialog
	private void delMemoDialog()
	{
		// 削除dialog
		final Builder builder = new android.app.AlertDialog.Builder(MemoEditActivity.this);
		String title = Util.truncationString(editContent.getText().toString(), 6);
		if(null == title || "".equals(title))
		{
			title = " ";
		}
		
		builder.setTitle(title);
		builder.setMessage("削除しますか？");
		builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
	    {
	        public void onClick(DialogInterface dialog, int which) 
	        {
	             dialog.dismiss();   
	        }
	     });
		builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
	    {
	        public void onClick(DialogInterface dialog, int which) 
	        {
	        	if(null != editIntent &&  memoId!= null){
	        		 MemoDBOperate.deleteMemo(MemoEditActivity.this,memoId);
	//	        	 deleteFromLauncher(memoId,Util.truncationString(editContent.getText().toString(),6));
		        	 dialog.dismiss(); 
		        	 startActivity(new Intent(MemoEditActivity.this,MemoActivity.class));
		             MemoEditActivity.this.finish();
		             if(editIntent.getStringExtra("shortcut") != null)
		 			 {
		 				sendBroadcast(new Intent(APP_CLOSE_ACTION));
		 			 }	
	        	}
	        }
	    });
		builder.show();
	}
	class InputHandler extends Handler { 
        @Override 
        public void handleMessage(Message msg) { 
            switch (msg.what) { 
            case 1:  
                if (msg.arg1 == HAS_CHANGE) { 
					params.height = 0;
					bottom.setLayoutParams(params); 
					alphaParams.topMargin = topMargin;
					alphaLinear.setLayoutParams(alphaParams);
					
                } else { 
                	params.height = bottomH;
                	bottom.setLayoutParams(params); 
					alphaParams.topMargin = 18;
					alphaLinear.setLayoutParams(alphaParams);
					keybordChange = false;
                } 
                
                break; 
 
            default: 
                break; 
                
            } 
            super.handleMessage(msg); 
        } 
    }
	protected void onDestroy() 
	{
		mCommonReceiver.unRegister();
		super.onDestroy();
		
	}
	 private class CommonReceiver extends BroadcastReceiver
	 {
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction(APP_CLOSE_ACTION);
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			if (intent.getAction().equals(APP_CLOSE_ACTION)) 
		    {
	        	MemoEditActivity.this.finish();
		    }
		}
	}
}
