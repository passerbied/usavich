package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class MemoDatabaseHelper extends SQLiteOpenHelper {

	private final static String DB_NAME = "MEMO.db";
	private final static String TABLE_NAME   = "memo_table";
	private final static String PASSWORD_TABLE_NAME   = "memo_password_table";
	private final static String SORT_TABLE_NAME = "memo_sort_table";
	public final static String MEMO_ID   = "memo_id";
	public final static String MEMO_TITLE   = "memo_title";
	public final static String MEMO_CONTENT   = "memo_content"; 
	public final static String MEMO_DATE   = "memo_date";
	public final static String MEMO_TYPE   = "memo_type";
	public final static String MEMO_PASSWORD_ID   = "memo_password_id"; 
	public final static String MEMO_PASSWORD   = "memo_password"; 
	public final static String MEMO_CLOCK_STATUS   = "memo_clock_status"; 
	public final static String MEMO_SORT_ID   = "memo_sort_id"; 
	public final static String MEMO_SORT_NAME   = "memo_sort_name";
	public MemoDatabaseHelper(Context context) {
		super(context, DB_NAME, null, 1);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " (" + 
				MEMO_ID      + " INTEGER primary key autoincrement, " + 
				MEMO_TITLE   + " text, " + 						
				MEMO_CONTENT    + " text, " + 
				MEMO_DATE + " text, " + 
				MEMO_CLOCK_STATUS + " text, " + 
				MEMO_TYPE + " text );");
		db.execSQL("CREATE TABLE IF NOT EXISTS " + PASSWORD_TABLE_NAME + " (" + 
		MEMO_PASSWORD_ID  + " INTEGER primary key autoincrement, " + 
		MEMO_PASSWORD   + " text);");
		
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
		db.execSQL("DROP TABLE IF EXISTS " + PASSWORD_TABLE_NAME);
		this.onCreate(db);
	}

}
