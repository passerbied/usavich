package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver 
{
	private String nextAlarm = "", alarmId = "", nowTime = "", nowHour = "", nowMinutes = "", nextTime = "";
	private AlarmDataBaseAdapter mAlarmDB;
	private ArrayList<String> alarm;
	
	public void onReceive(Context context, Intent intent) 
	{
		if(Utils.MAIN_TAB_ACTIVITY_STATUS.equals("onStop") && 
		   Utils.MAIN_TAB_ACTIVITY_DESTROYED_STATUS == false &&
		   Utils.ALARMLIST_ACTIVITY_DESTROYED_STATUS == true && 
		   Utils.TIMEROPTION_ACTIVITY_DESTROYED_STATUS == true)
		{
			context.startService(new Intent(Utils.ACTION_ALARM_SERVICE));
		}
		
		mAlarmDB = new AlarmDataBaseAdapter(context);
	    nowTime    = new SimpleDateFormat ("HH:mm").format(new Date(System.currentTimeMillis()));
	    nowHour    = nowTime.split(":")[0];
	    nowMinutes = nowTime.split(":")[1];
		Alarm.cancelAlarm(context, intent.getStringExtra("alarmid"));
		mAlarmDB.open();
	    mAlarmDB.updateSingleSameAlarmOnOff(nowHour, nowMinutes, "OFF");
	    mAlarmDB.close();
	    
	    alarm = Alarm.getNextAlarmTimeData(context); 
	    nextAlarm = alarm.get(0);
	    alarmId   = alarm.get(1);
        nextTime  = alarm.get(2);
		
        if(!nextAlarm.equals("-- : --"))
        {
        	Alarm.sendAlarm(context, alarmId, Long.parseLong(nextTime));
        }
        
		intent.setClass(context, AlarmAlert.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
		context.startActivity(intent);
	}
}