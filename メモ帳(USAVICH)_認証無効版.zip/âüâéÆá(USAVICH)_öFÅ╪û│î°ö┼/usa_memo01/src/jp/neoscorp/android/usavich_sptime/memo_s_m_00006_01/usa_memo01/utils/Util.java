package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.SCConfimActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.URLSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TableRow;

public class Util {
	public final static String HAS_PASSWORD_STATUS = "1";
	public final static String UN_PASSWORD_STATUS = "0";
	public final static String DEFAULT_PASSWORD = "0000";
	private final static int ORG_SCREEN_WIDTH = 480; 
	public static DisplayMetrics windowDisplay;
	private static boolean  isDismiss;
	private static Context mContext;
	public static SpannableString EmailConvert(String content)
	{
		String matcherStr = null;
		Pattern pattern = Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");
		Matcher matcher = pattern.matcher(content);
		SpannableString ss = new SpannableString(content);
		while(matcher.find())
		{
			matcherStr = matcher.group();
			Log.i("matcherStr = ", matcherStr);
			ss.setSpan(new URLSpan("mailto:"+matcherStr), 0, matcherStr.length()-1,
	                   Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		}
		
		return ss;
	}
	public static void WrongPassword(Context context)
	{
		
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle("パスワードが間違っています。");
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		builder.show();
	}
	public static void WrongPassword(Context context,String title)
	{
		
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle(title);
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		builder.show();
	}
	public static void ShortcutWrongPassword(final Context context)
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("パスワードが間違っています。");
		builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
			
			@Override
			public void onCancel(DialogInterface dialog) {
				dialog.dismiss();
				((Activity)context).finish();
			}
		});
		builder.setOnKeyListener(new DialogInterface.OnKeyListener() {
			
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK)
			    {
					dialog.dismiss();
					((Activity)context).finish();
			    }
				return false;
			}
		});
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				((Activity)context).finish();
				dialog.dismiss();
			}
		});
		builder.show();
	}
	
	public static Typeface setLightFont(Context context)
	{
			return Typeface.createFromAsset(context.getAssets(), "fonts/memo_A-OTF-ShinMGoPro-Light.otf");
	}
	public static Typeface setMediumFont(Context context)
	{
		return Typeface.createFromAsset(context.getAssets(), "fonts/memo_A-OTF-ShinMGoPro-Medium.otf");
	}
	
	//
	public static String truncationString(String original , int truncationLength)
	{
		String newString = null;
//		newString = trimBefore(original);
		newString = original;
		 String[] items = newString.split("\n");
         for (String item : items) {
//             if(!TextUtils.isEmpty(item)) {
            	 newString = item;
            	 break;
//             }
         }
		if(newString.length() >= truncationLength)
		{
			newString = newString.substring(0, truncationLength) + "...";
		}
		return newString.replace("\n", "");
	}
	private static  String trimBefore(String str)
    {
    	char[] ch = str.toCharArray();
    	int insertCount = 0;
    	for(int i=0 ; i<ch.length; i++ )
    	{
    		if(ch[i] != ' ' && Character.getNumericValue(ch[i]) != 10)
    		{
    			insertCount = i;
    			break;
    		}
    	}
    	return str.substring(insertCount);
    	
    }
	
	public static LinearLayout.LayoutParams getLinearLayoutPararm(int x, int y, int w, int h, DisplayMetrics dm)
	{
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.leftMargin = dm.widthPixels * x / ORG_SCREEN_WIDTH;
		params.topMargin =  dm.widthPixels * y / ORG_SCREEN_WIDTH;
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		
		return params;
	}
	public static LinearLayout.LayoutParams getLinearLayoutPararm(int w, int h, DisplayMetrics dm)
	{
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		
		return params;
	}
	public static LinearLayout.LayoutParams getLinearLayoutPararm(int w, DisplayMetrics dm)
	{
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		
		return params;
	}
	public static LinearLayout.LayoutParams getLinearLayoutFormHeightPararm(int h, DisplayMetrics dm)
	{
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		return params;
	}
	public static TableRow.LayoutParams getTableRowPararm(int w, int h, DisplayMetrics dm)
	{
		TableRow.LayoutParams params = new TableRow.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		return params;
	}
	public static RadioGroup.LayoutParams getRadioGroupPararm(int w, DisplayMetrics dm)
	{
		RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.gravity = Gravity.CENTER;
		return params;
	}
	public static RelativeLayout.LayoutParams getRelativeLayoutPararm(int w, int h, DisplayMetrics dm)
	{
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		return params;
	}
	public static int dip2px(Context context, float dpValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}
	
}
