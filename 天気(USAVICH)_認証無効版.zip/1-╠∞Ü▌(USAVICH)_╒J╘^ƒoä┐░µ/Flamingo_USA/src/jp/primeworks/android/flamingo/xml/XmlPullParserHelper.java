package jp.primeworks.android.flamingo.xml;

import java.io.IOException;
import java.io.InputStream;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class XmlPullParserHelper {

	public static XmlPullParser getXmlPullParser(InputStream is) throws XmlPullParserException {
		return getXmlPullParser(is, "UTF-8");
	}

	public static XmlPullParser getXmlPullParser(InputStream is, String encoding) throws XmlPullParserException {
		XmlPullParserFactory parserFactory = XmlPullParserFactory.newInstance();
		parserFactory.setNamespaceAware(true);
		XmlPullParser parser = parserFactory.newPullParser();
		parser.setInput(is, encoding);
		return parser;
	}

	public boolean skipUntilStartTagEvent(XmlPullParser parser, XmlTag tag) throws XmlPullParserException, IOException {
		return skipUntilStartTagEvent(parser, tag.getPrefix(), tag.getName());
	}

    public boolean skipUntilStartTagEvent(XmlPullParser parser, String name) throws XmlPullParserException, IOException {
    	return skipUntilStartTagEvent(parser, name, null);
    }

    public boolean skipUntilStartTagEvent(XmlPullParser parser, String namespace, String name) throws XmlPullParserException, IOException {
        while(!isStartTagEvent(parser, namespace, name)) {
            parser.next();
        }

        if(parser.getEventType() == XmlPullParser.END_DOCUMENT) {
        	return false;
        } else {
        	return true;
        }
    }

	public boolean skipUntilEndTagEvent(XmlPullParser parser, XmlTag tag) throws XmlPullParserException, IOException {
		return skipUntilEndTagEvent(parser, tag.getPrefix(), tag.getName());
	}

    public boolean skipUntilEndTagEvent(XmlPullParser parser, String name) throws XmlPullParserException, IOException {
    	return skipUntilEndTagEvent(parser, name, null);
    }

    public boolean skipUntilEndTagEvent(XmlPullParser parser, String namespace, String name) throws XmlPullParserException, IOException {
        while(!isEndTagEvent(parser, namespace, name)) {
            parser.next();
        }
        parser.next();
        
        if(parser.getEventType() == XmlPullParser.END_DOCUMENT) {
        	return false;
        } else {
        	return true;
        }
    }

	public boolean isStartTagEvent(XmlPullParser parser, XmlTag tag) throws XmlPullParserException, IOException {
		return isStartTagEvent(parser, tag.getPrefix(), tag.getName());
	}

    public boolean isStartTagEvent(XmlPullParser parser, String name) throws XmlPullParserException {
    	return isStartTagEvent(parser, name, null);
    }

    public boolean isStartTagEvent(XmlPullParser parser, String namespace, String name) throws XmlPullParserException {

        int eventType = parser.getEventType();
        return eventType == XmlPullParser.END_DOCUMENT
                || (eventType == XmlPullParser.START_TAG
                                && (namespace == null || namespace.equals(parser.getPrefix()))
                                && name.equals(parser.getName()));
        
    }

	public boolean isEndTagEvent(XmlPullParser parser, XmlTag tag) throws XmlPullParserException, IOException {
		return isEndTagEvent(parser, tag.getPrefix(), tag.getName());
	}

    public boolean isEndTagEvent(XmlPullParser parser, String name) throws XmlPullParserException {
    	return isEndTagEvent(parser, name, null);
    }

    public boolean isEndTagEvent(XmlPullParser parser, String namespace, String name) throws XmlPullParserException {

        int eventType = parser.getEventType();
        return eventType == XmlPullParser.END_DOCUMENT
                || (eventType == XmlPullParser.END_TAG
                                && (namespace == null || namespace.equals(parser.getPrefix()))
                                && name.equals(parser.getName()));
        
    }

    public String getAttributeValue(XmlPullParser parser, XmlAttribute attr) {
    	return parser.getAttributeValue(null, attr.getName());
    }

}
