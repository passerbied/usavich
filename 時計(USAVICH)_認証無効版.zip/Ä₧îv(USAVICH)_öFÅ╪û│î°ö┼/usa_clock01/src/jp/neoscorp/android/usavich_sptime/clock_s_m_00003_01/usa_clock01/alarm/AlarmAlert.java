package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.R;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class AlarmAlert extends Activity 
{
	public static String ALARM_UPDATE_ACTION = "com.taiyo.clock.action.ALARM_UPDATE_ACTION";
	private String mAlarmId;
	private MediaPlayer mMediaPlayer;
	private AlarmDataBaseAdapter mAlarmDB;
	private Cursor mCursor;
	private ImageView alertImageView;
	private Button mAlarmCancelBtn, mAlarmSnoozeBtn;
	private TextView mAlarmTime, mAlarmTitle;
	private String mHour, mMinutes, mAlarmSnooze, mAlarmWeek,mAlarmSoundPath;
	private Vibrator mVibrator;
	private boolean mbVibrator = false;
	private TelephonyManager mTelephonyManager;
	private AlarmReceiver mAlarmReceiver;
	private Typeface tf0, tf1, tf2;
	private Context mContext;
    //アニメ
    private Thread AnimationThread;
    private boolean AnimationStatus = false;
    private AnimationPlayHandler mAnimationPlay;
    private int popupPos = 0;
    
    //アニメ　popup
    private int popup_timecount = 0;
    private int[] popup = new int[]
		{
			R.drawable.popup_anime01,
			R.drawable.popup_anime02,
			R.drawable.popup_anime03,
			R.drawable.popup_anime04		
		};
    private int[] popup_time = new int[]{ 100, 100, 100, 100 };

	 private class AnimationPlayHandler extends Handler 
	 {
	        public void handleMessage(Message msg) 
	        {
	            super.handleMessage(msg);
	            alertImageView.setImageResource(popup[popupPos - 1]);  
	    	}	
	 }
	    
   private void AnimationStart()
   {
   	 mAnimationPlay = new AnimationPlayHandler();
   	 AnimationStatus = true;
   	 AnimationThread = new Thread(new Runnable()
   	 {
          public void run () {
          	while(AnimationStatus)
          	{
          		if(popup_timecount == 0)
       			{
	           		if(popupPos == popup.length)
	           			popupPos = 0;
	           		popupPos++ ;
	               	mAnimationPlay.sendMessage(mAnimationPlay.obtainMessage());
	               	popup_timecount = popup_time[popupPos - 1];
       			}
          		popup_timecount = popup_timecount - 100;
       			
          		try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}	
          	}
          }
      });
	   AnimationThread.start();
   }
   
   private void AnimationStop()
   {
	   	AnimationStatus = false;
	   	AnimationThread.interrupt();
	   	AnimationThread = null;
	   	mAnimationPlay = null;    	
   }

	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);  
		getWindow().setBackgroundDrawableResource(R.color.alertbgcolor);
		setContentView(R.layout.alarmalertpopview);
		
		mAlarmReceiver = new AlarmReceiver();
		mAlarmReceiver.register();
		
		mContext = AlarmAlert.this;
        mTelephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        mTelephonyManager.listen(mPhoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
		tf0 = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/settings_A-OTF-ShinMGoPro-Medium.otf");
		tf1 = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/clock_SHOWG.ttf");
		tf2 = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/clock_A-OTF-ShinMGoPro-Light.otf");
		
		mAlarmCancelBtn = (Button)findViewById(R.id.alarmCancelBtn);
        mAlarmSnoozeBtn = (Button)findViewById(R.id.alarmSnoozeBtn);
        mAlarmTitle = (TextView)findViewById(R.id.alarmTitle);
        mAlarmTime = (TextView)findViewById(R.id.alarmTime);
		mAlarmTime.setTextColor(Color.rgb(255, 255, 255));
        alertImageView = (ImageView)findViewById(R.id.alertImageView);
        mAlarmTitle.setTypeface(tf0);
        mAlarmCancelBtn.setTypeface(tf2);
        mAlarmSnoozeBtn.setTypeface(tf2);
        mAlarmTime.setTypeface(tf1);
                 
        AnimationStart();
        
		mAlarmId = getIntent().getStringExtra("alarmid");
		mAlarmDB = new AlarmDataBaseAdapter(this);
		mAlarmDB.open();
		mCursor = mAlarmDB.selectByAlarmId(Integer.parseInt(mAlarmId));
		mCursor.moveToFirst();
		mAlarmSoundPath = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_SOUNDPATH));
		
		if(!mAlarmSoundPath.trim().equals(""))
		{
			AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);  
			am.adjustStreamVolume (AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_PLAY_SOUND);  
			Uri sound = Utils.getRingtoneByUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE, mAlarmSoundPath);
			mMediaPlayer = MediaPlayer.create(getApplicationContext(), sound);  
			mMediaPlayer.setLooping(true);
			mMediaPlayer.start();
		}
		
		if(((String)mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_VIBRATE))).equals("ON"))
		{
			mbVibrator = true;
			mVibrator = (Vibrator) getApplication().getSystemService(Service.VIBRATOR_SERVICE);  
	        mVibrator.vibrate(new long[]{100,10,100,1000}, 0);  
		}
		else{
			mbVibrator = false;
		}
        
        mHour = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_HOUR)).trim();
        mMinutes = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_MINUTES)).trim();
        mAlarmSnooze = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_SNOOZE));
        mAlarmWeek = mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_WEEK));
        
        mAlarmTitle.setText(Utils.formartStringLength(mCursor.getString(mCursor.getColumnIndex(mAlarmDB.ALARM_TITLE))));
        mAlarmTime.setText(mHour + ":" + mMinutes);           
        
        mAlarmCancelBtn.setOnClickListener(new OnClickListener()
		{			
			public void onClick(View arg0) {
				stopAlarm();
			}
		});
        
        mAlarmSnoozeBtn.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				if(!mAlarmSoundPath.trim().equals("")){ mMediaPlayer.stop();}
				if(mbVibrator){ mVibrator.cancel(); }
                //SNOOZE
	            Alarm.sendAlarm(mContext, mAlarmId, System.currentTimeMillis() + 60000 * (new Integer(mAlarmSnooze)));
	            
				AlarmAlert.this.finish();
			}
		});   
	}
	
	private void stopAlarm()
	{
		if(!mAlarmSoundPath.trim().equals("")){ mMediaPlayer.stop();}
		if(mbVibrator){ mVibrator.cancel(); }
		mAlarmDB.updateSingleSameAlarmOnOff(mHour, mMinutes, "OFF");
		
		if(Alarm.IsHaveSkipIdNotification(mContext, Integer.parseInt(mAlarmId))){
		}
		else{
			if(mAlarmWeek.equals(""))
			{
				Alarm.delNotification(mContext);
			}
		}

		Intent intentNextAlarmTime = new Intent(ALARM_UPDATE_ACTION);
		intentNextAlarmTime.putExtra("nextalarmtime", Alarm.getNextAlarmTimeData(mContext).get(0));
		sendBroadcast(intentNextAlarmTime);	
		AlarmAlert.this.finish();
	}
	
	protected void onStop()
	{
		super.onStop();
		stopAlarm();
	}
	
	protected void onDestroy() 
	{  
        super.onDestroy();
        mAlarmReceiver.unRegister();
        mAlarmDB.close();  
        mCursor.close();
        mCursor = null;
        AnimationStop();
        alertImageView.setImageDrawable(null);
	} 
	
	private class AlarmReceiver extends BroadcastReceiver
	{
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction("android.intent.action.SCREEN_OFF");
    		filter.addAction("android.intent.action.SCREEN_ON");
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			if (intent.getAction().equals("android.intent.action.SCREEN_OFF") || intent.getAction().equals("android.intent.action.SCREEN_ON")) 
			{
				if(!mAlarmSoundPath.trim().equals("")){ mMediaPlayer.stop();}
				if(mbVibrator){ mVibrator.cancel(); }
			}		
		}
	}
	
	 private PhoneStateListener mPhoneStateListener = new PhoneStateListener() 
	 {
        public void onCallStateChanged(int state, String ignored) {
            if (state == TelephonyManager.CALL_STATE_RINGING) 
            {
				if(!mAlarmSoundPath.trim().equals("")){ mMediaPlayer.stop();}
				if(mbVibrator){ mVibrator.cancel(); }
            }
        }
	 };
}
