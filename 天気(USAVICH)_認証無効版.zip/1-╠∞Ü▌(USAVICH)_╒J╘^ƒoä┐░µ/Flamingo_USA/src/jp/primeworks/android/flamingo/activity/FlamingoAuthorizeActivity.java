package jp.primeworks.android.flamingo.activity;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import jp.primeworks.android.flamingo.Flamingo;
import jp.primeworks.android.flamingo.FlamingoError;
import jp.primeworks.android.flamingo.R;
import jp.primeworks.android.flamingo.util.FlamingoResources;
import jp.primeworks.android.flamingo.util.FlamingoSharedPreferences;
import jp.primeworks.android.flamingo.util.FlamingoUtil;
import jp.primeworks.android.flamingo.util.Logging;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import com.samsung.zirconia.LicenseCheckListener;
import com.samsung.zirconia.Zirconia;


/**
 * FlamingoAuthorizeActivity
 *
 * <p>
 * 認証処理を行うActivity.
 *
 */
public class FlamingoAuthorizeActivity extends Activity {

    public static final String INTENT_CATEGORY_ZIRCONIA = "jp.neoscorp.android.flamingo.intent.category.ZIRCONIA";

	/**
	 * 処理状態enum値
	 *
	 */
	private enum EnumAuthState {

		/**
		 * 処理なし 値:0
		 */
		AUTH_STATE_NONE(0), //

		/**
		 * １回目のアプリ認可中 値:1
		 */
		AUTH_STATE_BUSY_APP_AUTH1(1), //

		/**
		 * ユーザ認証中 値:2
		 */
		AUTH_STATE_WAIT_USER_AUTH(2), //

		/**
		 * ２回目のアプリ認可中 値:3
		 */
		AUTH_STATE_BUSY_APP_AUTH2(3);

		/**
		 * enum定義に対応する値
		 */
		private int value;


		/**
		 * コンストラクタ
		 *
		 * @param value
		 *            enum定義に対応する値
		 */
		private EnumAuthState(int value) {

			this.value = value;
		}


		/**
		 * enum定義に対応する値を取得する.
		 *
		 * @return enum定義に対応する値
		 */
		public int getValue() {

			return value;
		}
	};

	/**
	 * 現在の処理状態
	 */
	protected EnumAuthState enumAuthState = EnumAuthState.AUTH_STATE_NONE;

	/**
	 * Basic認証ユーザ名<BR>
	 * ※本項目はstring_static.xmlに配置しない.
	 */
	private static final String BASIC_AUTHENTICATION_USER = "pwmainte";

	/**
	 * Basic認証パスワード<BR>
	 * ※本項目はstring_static.xmlに配置しない.
	 */
	private static final String BASIC_AUTHENTICATION_PASSWORD = "maintepass";

	/**
	 * URLエンコード/デコードのキャラクタセット指定
	 */
	private static final String URL_ENCODE_DECODE_CHARSET = "UTF-8";

	/**
	 * １回目のアプリケーション認可処理要求フラグ
	 */
	private boolean isRequestAppAuthorize1 = false;

	/**
	 * ユーザ認証応答データUri
	 */
	private Uri stockIntentUri = null;

	/**
	 * onCreateイベント発生回数
	 */
	private int countOnCreate = 0;

	/**
	 * onResumeイベント発生回数
	 */
	private int countOnResume = 0;


	/**
	 * onCreate
	 *
	 * 主に以下の処理を行う.<BR>
	 * ・過去のUUIDがプリファレンスに残っていれば消す.<BR>
	 * ・onCreateがアプリケーション側からのauthorizeメソッドによるものか判定する.<BR>
	 * ・authorizeメソッドによるものであれば、1回目のアプリ認証に進むフラグを設定する.<BR>
	 *
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		boolean hasBrowserRedirect = false;
		super.onCreate(savedInstanceState);

		countOnCreate = countOnCreate + 1;
		Logging.v("onCreate() called. countOnCreate =" + countOnCreate);

		// プリファレンスに残されたUUIDは一旦消す.
		FlamingoSharedPreferences.getInstance().removeUuid(getApplicationContext());

		Intent intent = getIntent();

		Uri uri = intent.getData();

		hasBrowserRedirect = (uri != null);

		switch (enumAuthState) {

		case AUTH_STATE_NONE: {

			if ((!hasUuid()) && (!hasBrowserRedirect)) {
				// UUIDを保持していない、かつブラウザからのリダイレクトでもない場合、アプリ側からの要求による起動.

				isRequestAppAuthorize1 = true;
			}
			break;
		}

		case AUTH_STATE_BUSY_APP_AUTH1:
		case AUTH_STATE_WAIT_USER_AUTH:
		case AUTH_STATE_BUSY_APP_AUTH2:
		default: {
			break;
		}

		}
	}


	/**
	 * onNewIntent
	 * <p>
	 * ブラウザからのリダイレクト用に以下の処理を行う.<BR>
	 * ・インテントに含まれるURIを自クラスのメンバ変数に格納する.<BR>
	 *
	 * @see android.app.Activity#onNewIntent(android.content.Intent)
	 */
	@Override
	protected void onNewIntent(Intent intent) {

		Logging.v("onNewIntent() called. intent=" + intent.toString());
		super.onNewIntent(intent);
		stockIntentUri = intent.getData();
	}


	/**
	 * onResume
	 * <p>
	 * 現在の処理状態に合わせて、処理の振り分けを行う.<BR>
	 * 主に次のことを行う.<BR>
	 * ・１回目のアプリ認可開始<BR>
	 * ・ユーザ認証の開始<BR>
	 *
	 * @see android.app.Activity#onResume()
	 */
	@Override
	public void onResume() {

		countOnResume = countOnResume + 1;
		Logging.v("onResume() called. countOnResume =" + countOnResume);

		super.onResume();

		// 何らかのステップで終了処理（アクティビティの終了）が入っていれば処理を継続しない.
		if (isFinishing()) {
			return;
		}

		switch (enumAuthState) {

		case AUTH_STATE_NONE: {

			if (isRequestAppAuthorize1) {
				// １回目のアプリケーション認可処理を行う.

				enumAuthState = EnumAuthState.AUTH_STATE_BUSY_APP_AUTH1;
				Logging.d("[enumAuthState]=" + enumAuthState.name() + "(" + enumAuthState.getValue() + ")");

                Set<String> categories = getIntent().getCategories();
                if(categories != null && categories.contains(INTENT_CATEGORY_ZIRCONIA)) {
                    requestZirconiaAuthorize();
                } else {
                    requestApplicationAuthorize();

                    isRequestAppAuthorize1 = false;
                }

			} else {

				finishActivity();

			}
			break;
		}

		case AUTH_STATE_BUSY_APP_AUTH1: {
			break;
		}

		case AUTH_STATE_WAIT_USER_AUTH: {

			if (stockIntentUri != null) {

				if (hasUuid()) {

					// UUIDを保持中、かつブラウザからのリダイレクトの場合

					// ユーザ認証結果の確認や２回目のアプリケーション認可処理に進む.

					checkCertifyResponse(stockIntentUri);

				}
				stockIntentUri = null;

			} else {

				// ブラウザのリダイレクトではない場合

				// 認証キャンセルを通知する.
				noticeAuthorizeCancelMessage();

			}
			break;
		}

		case AUTH_STATE_BUSY_APP_AUTH2: {
			break;
		}

		default: {
			break;
		}

		}
	}


	/**
	 * キーを常に英小文字化したうえで扱うHashMap<String, String>クラス
	 * <p>
	 * 本クラスはキーの入出力について必ず英小文字化を実施することにより、<BR>
	 * キーの英大小文字を同一視したマップとして機能する.
	 *
	 */
	private static class HashMapLowerCaseKey extends HashMap<String, String> {

		/**
		 * serialVersionUID<BR>
		 * デフォルト・シリアル・バージョンで扱う.
		 */
		private static final long serialVersionUID = 1L;


		/**
		 * 指定するキーがマップに存在するか調べる.
		 *
		 * @see java.util.HashMap#containsKey(java.lang.Object)
		 */
		@Override
		public boolean containsKey(Object key) {

			if (key instanceof String) {
				return super.containsKey(((String) key).toLowerCase(Locale.ENGLISH));
			} else {
				return super.containsKey(key);
			}
		}


		/**
		 * 指定するキーに対応する値を取得する.
		 *
		 * @see java.util.HashMap#get(java.lang.Object)
		 */
		@Override
		public String get(Object key) {

			if (key instanceof String) {
				return super.get(((String) key).toLowerCase(Locale.ENGLISH));
			} else {
				return super.get(key);
			}
		}


		/**
		 * マップにエントリを追加する.
		 *
		 * @see java.util.HashMap#put(java.lang.Object, java.lang.Object)
		 */
		@Override
		public String put(String key, String value) {

			return super.put(((String) key).toLowerCase(Locale.ENGLISH), value);
		}
	};


	// ＜メモ＞現行の版では GraceDays に対応しないことになったため、メソッドをコメントアウトする.
	// /**
	// * デフォルトの期限超過後猶予日数（単位:日）を取得する.
	// *
	// * @return デフォルトの期限超過後猶予日数
	// */
	// private String getDefaultGraceDays() {
	//
	//
	// Resources res = getResources();
	//
	// Logging.d("flamingo_default_grace_days=" + res.getString(R.string.flamingo_default_grace_days));
	// return res.getString(R.string.flamingo_default_grace_days);
	//
	// return "";
	// }

    /**
     * Zirconia認証要求.
     * 
     * Samsung Android DRM Library, Zirconia, の認証要求を開始する。
     * 認証は非同期で実行し、{@link #noticeAuthorizeCompleteMessage}で通知する。
     */
    private void requestZirconiaAuthorize() {
        new AsyncTask<Void, Integer, Boolean>() {

            /**
             * 動作中表示を行うダイアログ
             */
            private ProgressDialog mProgressDialog = null;

            /**
             * Zirconia認証結果フラグ.
             */
            private boolean mZirconiaResult = false;

            /**
             * onPreExecute<BR>
             * 非同期処理開始<BR>
             *
             * @see android.os.AsyncTask#onPreExecute()
             */
            @Override
            protected void onPreExecute() {

                super.onPreExecute();
                Logging.d("");

                mProgressDialog = new ProgressDialog(FlamingoAuthorizeActivity.this);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.setMessage(FlamingoResources.getResources(FlamingoAuthorizeActivity.this).getString(R.string.flamingo_authorize_confirm_busy_message));
                mProgressDialog.setCancelable(false);
                mProgressDialog.show();
                Logging.d("");
            }

            @Override
            protected Boolean doInBackground(Void... params) {
                Zirconia zirconia = new Zirconia(FlamingoAuthorizeActivity.this);
                zirconia.setLicenseCheckListener(new LicenseCheckListener() {
                    @Override
                    public void licenseCheckedAsValid() {
                        mZirconiaResult = true;
                    }
                    @Override
                    public void licenseCheckedAsInvalid() {
                        mZirconiaResult = false;
                    }
                });
                zirconia.checkLicense(false, true);
                
                return mZirconiaResult;
            }

            /**
             * onPostExecute<BR>
             * 非同期処理終了<BR>
             * <p>
             * 認証処理に成功した場合、resultにtrueを渡すこと.<BR>
             * 失敗した場合(ネットワークエラーやタイムアウトで処理が正常に行えなかった場合)、resultにfalseを渡すこと.
             */
            @Override
            protected void onPostExecute(Boolean result) {

                super.onPostExecute(result);
                Logging.d("");
                if (mProgressDialog != null) {
                    mProgressDialog.dismiss();
                }

                noticeAuthorizeCompleteMessage(result);
                Logging.d("");
            }

        }.execute();
    }

	/**
	 * アプリケーション認可を開始する.
	 */
	private void requestApplicationAuthorize() {

		Logging.v("call requestApplicationAuthorize()");

		/**
		 * アプリケーション認可を非同期で行うためのタスク.
		 *
		 */
		class RequestApplicationAuthorizeTask extends AsyncTask<Void, Void, Boolean> {

			/**
			 * 動作中表示を行うダイアログ
			 */
			private ProgressDialog progressDialog = null;

			/**
			 * 認証レスポンスの結果を格納する.
			 */
			private Map<String, String> response = null;


			/**
			 * onPreExecute<BR>
			 * 非同期処理開始<BR>
			 *
			 * @see android.os.AsyncTask#onPreExecute()
			 */
			@Override
			protected void onPreExecute() {

				super.onPreExecute();
				Logging.d("");

				progressDialog = new ProgressDialog(FlamingoAuthorizeActivity.this);
				progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
				progressDialog.setMessage(FlamingoResources.getResources(FlamingoAuthorizeActivity.this).getString(R.string.flamingo_authorize_confirm_busy_message));
				progressDialog.setCancelable(false);
				progressDialog.show();
				Logging.d("");
			}


			/**
			 * doInBackground<BR>
			 * 非同期処理本体<BR>
			 *
			 * @see android.os.AsyncTask#doInBackground(Params[])
			 */
			@Override
			protected Boolean doInBackground(Void... params) {

				Logging.d("");

				ApplicationAuthorize applicationAuthorize = new ApplicationAuthorize(getApplicationContext());
				response = applicationAuthorize.request();

				Boolean hasResponse = (response != null);
				Logging.d("hasResponse " + hasResponse);
				return hasResponse;
			}


			/**
			 * onPostExecute<BR>
			 * 非同期処理終了<BR>
			 * <p>
			 * 認証処理に成功した場合、resultにtrueを渡すこと.<BR>
			 * 失敗した場合(ネットワークエラーやタイムアウトで処理が正常に行えなかった場合)、resultにfalseを渡すこと.
			 */
			@Override
			protected void onPostExecute(Boolean result) {

				super.onPostExecute(result);
				Logging.d("");
				if (progressDialog != null) {
					progressDialog.dismiss();
				}

				if (result) {
					onPostApplicationAuthorized(response);
				} else {
					onPostApplicationAuthorized(null);
				}
				Logging.d("");
			}
		}

		RequestApplicationAuthorizeTask task = new RequestApplicationAuthorizeTask();
		task.execute((Void) null);
		Logging.d("");
	}


	/**
	 * ユーザ認証を開始する.
	 */
	private void requestUserCertificate() {

		Logging.v("call requestUserCertificate()");

		enumAuthState = EnumAuthState.AUTH_STATE_WAIT_USER_AUTH;
		Logging.d("[enumAuthState]=" + enumAuthState.name() + "(" + enumAuthState.getValue() + ")");

		UserCertificate userCertificate = new UserCertificate(getApplicationContext());
		userCertificate.request();
	}


	/**
	 * アプリケーション認可を行うクラス.
	 */
	private class ApplicationAuthorize {

		/**
		 * コンテキスト
		 */
		private Context mContext;

		/**
		 * アプリケーション認可用URI
		 */
		private ApplicationAuthorizeUri applicationAothorizeUri;


		/**
		 * コンストラクタ
		 *
		 * @param context
		 *            コンテキスト
		 */
		ApplicationAuthorize(Context context) {

			Logging.d("");
			mContext = context;
			applicationAothorizeUri = new ApplicationAuthorizeUri(mContext);
			Logging.d("");
		}


		/**
		 * アプリケーション認可を行う.
		 *
		 * @return HTTPから取得した項目マップ
		 */
		public Map<String, String> request() {

			Logging.d("");
			Map<String, String> map = null;
			Uri uri = getUri();

			Logging.d("uri=" + uri.toString());
			InputStream in = null;

			// アプリケーション認証の応答について疑似データを作成する（動作テスト用）
			boolean useAppAuthorizeTestData = false;
			useAppAuthorizeTestData = Boolean.valueOf(FlamingoResources.getResources(FlamingoAuthorizeActivity.this).getString(R.string.flamingo_use_app_authorize_test_data));

			if (useAppAuthorizeTestData) {
				return makeDebugData();
			}

			// 正規のHTTPアクセス処理
			final DefaultHttpClient httpClient = new DefaultHttpClient();

			// Basic認証
			Credentials credentials = new UsernamePasswordCredentials(BASIC_AUTHENTICATION_USER, BASIC_AUTHENTICATION_PASSWORD);
			AuthScope scope = new AuthScope(uri.getHost(),uri.getPort() );
			httpClient.getCredentialsProvider().setCredentials(scope, credentials);

		    HttpGet httpGet = new HttpGet(uri.toString());
		    HttpResponse response = null;

		    // HTTP request
		    try {
		    	response = httpClient.execute(httpGet);
		    	
			    if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
					// データを取得
					in = response.getEntity().getContent();

					ResponseParser parser = new ResponseParser();
					map = parser.read(in);
					Logging.v(map.toString());

					if (map != null) {
						Logging.d("Result of Application Authorize ----- map.size()=" + map.size());
						for (Map.Entry<String, String> e : map.entrySet()) {
							Logging.d("map key=" + e.getKey() + ", data=" + e.getValue());
						}
					}
			    } else {
			    	Logging.w("getResponseCode() is not HTTP_OK. getResponseCode()=" + response.getStatusLine().getStatusCode());
			    }
		    } catch (ClientProtocolException e) {

		    	Logging.e(e.toString());

		    } catch (IOException e) {

		    	Logging.e(e.toString());

		    } catch (XmlPullParserException e) {

		    	Logging.e(e.toString());

		    } finally {
		    	try {
		    		if (in != null) {
		    			in.close();
		    			in = null;
		    		}
		    	} catch (Exception e) {

		    		Logging.e(e.toString());

		    	}
		    }
			return map;
		}


		/**
		 * アプリケーション認証応答の疑似データ作成（動作テスト用）
		 *
		 * @return HTTPから取得した項目マップの擬似データ
		 */
		private Map<String, String> makeDebugData() {

			//

			if (Logging.DEBUG < Logging.getLogLevel()) {
				// ログが必ず出力されるようにする.
				Logging.setLogLevel(Logging.DEBUG);
			}

			Logging.w("== TEST ROUTINE IS RUNNING. USE APP AUTHORIZE TEST DATA. == ==");

			HashMapLowerCaseKey map = new HashMapLowerCaseKey();

			int testMode = 0;

			Logging.d("testMode=" + testMode);

			switch (testMode) {

			case 0:
				map.put("reSuLT", "OK");
				map.put("LicenSE", "NG");
				break;

			case 1:
				map.put("result", "OK");
				map.put("licenSE", "OK");
				break;

			case 2:
				map.put("result", "NG");
				map.put("licenSE", "OK");
				break;

			case 3:
				map.put("RESULT", "Ok");
				map.put("LICENSE", "ok");
				map.put("validateDate", "20120607T233000Z");
				map.put("graceDays", "3");
				break;

			case 4:
				map.put("result", "OK");
				map.put("licenSe", "ok");
				map.put("validateDate", "20120630T233000Z");
				map.put("graceDays", "3");
				break;

			case 5:
				map.put("RESULT", "Ok");
				map.put("LICENSE", "NG");
				map.put("validateDate", "20120607T233000Z");
				map.put("graceDays", "3");
				break;

			case 6:
				map.put("RESULT", "Ok");
				map.put("LICENSE", "ok");
				map.put("validateDate", "20120607");
				map.put("graceDays", "3");
				break;

			case 7:
				map.put("RESULT", "Ok");
				map.put("LICENSE", "ok");
				map.put("validateDate", "20120608");
				map.put("graceDays", "3");
				break;

			case 99:
				return null;

			default:
				// no item
				break;
			}

			return map;
		}


		/**
		 * アプリケーション認可用URIを取得する.
		 *
		 * @return アプリケーション認可用URI
		 */
		private Uri getUri() {

			Logging.d("");
			return applicationAothorizeUri.getUriInquiryApproval();
		}


		/**
		 * アプリケーション認可のレスポンスデータを解析する.
		 *
		 */
		private class ResponseParser {

			private static final String XML_TAG_ROOT = "flamingo";


			/**
			 * アプリケーション認可のレスポンスデータを解析しMap型に変換する.<BR>
			 * <BR>
			 * Mapのキーにはレスポンスデータのタグ名、値にはレスポンスデータのタグに設定されたテキストが格納される.<BR>
			 * ※キーについては必ず英小文字変換した結果を返す.<BR>
			 * ※値については特に英大文字小文字の変換は行わない.
			 *
			 * @param in
			 *            InputStreamクラスのインスタンス
			 * @return レスポンスデータのMap.<BR>
			 *         キー=レスポンスデータのタグ名 値=タグに対するデータ<BR>
			 *         ※キーについては必ず英小文字変換した結果を返す.
			 * @throws XmlPullParserException
			 *             パーサー処理失敗の場合
			 * @throws IOException
			 *             IO例外の場合
			 */
			public Map<String, String> read(InputStream in) throws XmlPullParserException, IOException {

				Logging.d("");

				XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
				parser.setInput(new InputStreamReader(in, "UTF-8"));

				// キーハンドリングを常に英小文字化して扱うHashMapを用いる.
				Map<String, String> map = new HashMapLowerCaseKey();

				int eventType = parser.getEventType();
				Logging.d("parser.getEventType=" + eventType);

				while (!isEndTagEvent(parser, XML_TAG_ROOT)) {
					switch (parser.next()) {
					case XmlPullParser.START_TAG:
						String name = parser.getName();
						if (XML_TAG_ROOT.equals(name)) {
							// ignore <root> tag body. it's empty.
							break;
						}

						eventType = parser.next();
						if (eventType == XmlPullParser.TEXT) {
							map.put(name, parser.getText());
							Logging.v("result: " + name + "=" + parser.getText());
						}

						break;
					case XmlPullParser.END_TAG:
						break;

					default:
						break;
					}

				}

				Logging.d("");
				return map;
			}


			/**
			 * 指定タグの終了を検出したか判定する.
			 *
			 * @param parser
			 *            XMLパーサ
			 * @param tag
			 *            タグ
			 * @return 終了を検出したときtrueを返す.
			 * @throws XmlPullParserException
			 *             分割処理エラーの場合
			 */
			private boolean isEndTagEvent(XmlPullParser parser, String tag) throws XmlPullParserException {

				int eventType = parser.getEventType();
				return eventType == XmlPullParser.END_DOCUMENT || (eventType == XmlPullParser.END_TAG && tag.equals(parser.getName()));
			}
		}


		/**
		 * アプリケーション認可時に使用するURIを表すクラス.
		 */
		class ApplicationAuthorizeUri {

			/**
			 * コンテキスト
			 */
			private Context mContext;


			/**
			 * コンストラクタ
			 *
			 * @param context
			 *            コンテキスト
			 */
			ApplicationAuthorizeUri(Context context) {

				mContext = context;
			}


			/**
			 * サーバー側のスキーマ名を取得する.<BR>
			 * 例) "http","https"
			 *
			 * @return スキーマ名
			 */
			private String getScheme() {

				Resources res = FlamingoResources.getResources(FlamingoAuthorizeActivity.this);
				return res.getString(R.string.flamingo_server_scheme);
			}


			/**
			 * アプリケーション認可接続先のAuthority（ホスト名）を取得する.<BR>
			 * 例)"stg.www.custamo.com"
			 *
			 * @return アプリケーション認可接続先のAuthority
			 */
			private String getUrlApplicationAuthority() {

				Resources res = FlamingoResources.getResources(FlamingoAuthorizeActivity.this);
				return res.getString(R.string.flamingo_application_authorize_url_authority);
			}


			/**
			 * アプリケーション認可接続先のパスを取得する.<BR>
			 * 例) "/smartp/FLM001"
			 *
			 * @return アプリケーション認可接続先のパス
			 */
			private String getUrlApplicationPath() {

				Resources res = FlamingoResources.getResources(FlamingoAuthorizeActivity.this);
				return res.getString(R.string.flamingo_application_authorize_url_path);
			}


			/**
			 * IMEIを取得する.
			 *
			 * @return IMEI
			 */
			private String getImei() {

				return FlamingoUtil.getIncetance().getImei(getApplicationContext());
			}


			/**
			 * IMSIを取得する.
			 *
			 * @return IMSI
			 */
			private String getImsi() {

				return FlamingoUtil.getIncetance().getImsi(getApplicationContext());
			}


			/**
			 * アプリケーションのパッケージ名を取得する.
			 *
			 * @return アプリケーションのパッケージ名
			 */
			private String getUserPackageName() {

				return FlamingoUtil.getIncetance().getUserPackageName(mContext);
			}


			/**
			 * アプリケーション認可問合わせのURIを取得する.<BR>
			 * <BR>
			 * キーには下記のものを用いる.<BR>
			 * ・IMEI<BR>
			 * ・IMSI<BR>
			 * ・パッケージ名<BR>
			 * ・アイテムID（任意項目のため、現在は利用しない.） <BR>
			 * URI文字列の例）<BR>
			 * http://www.example.com/flamingo/auth?imei=abcdefg&imsi=1234567890&packageName=jp.neos.android.example
			 *
			 * @return URIインスタンス
			 */
			public Uri getUriInquiryApproval() {

				String imei = getImei();
				String imsi = getImsi();
				String packageName = getUserPackageName();

				Uri.Builder builder = new Uri.Builder();
				builder.scheme(getScheme());
				builder.authority(getUrlApplicationAuthority());
				builder.path(getUrlApplicationPath());
				builder.appendQueryParameter("imei", imei);
				builder.appendQueryParameter("imsi", imsi);
				builder.appendQueryParameter("packageName", packageName);

				Uri uri = builder.build();

				Logging.v("ApplicationAuthorize Uri = " + uri.toString());

				return uri;
			}
		}
	}


	/**
	 * ユーザ認証を行うクラス
	 *
	 */
	private class UserCertificate {

		/**
		 * コンテキスト
		 */
		private Context mContext;

		/**
		 * ユーザ認証用URI
		 *
		 */
		private UserCertificateUri uri;


		/**
		 * コンストラクタ
		 *
		 * @param context
		 *            コンテキスト
		 */
		UserCertificate(Context context) {

			Logging.d("");
			mContext = context;
			uri = new UserCertificateUri(mContext);
			Logging.d("uri:" + uri);
		}


		/**
		 * ユーザ認証を開始する.
		 */
		public void request() {

			Logging.d("");

			String uuid = FlamingoUtil.getIncetance().createUuid();

			Uri tempUri = getUri(uuid);

			Logging.d("tempUri=" + tempUri.toString() + ", uuid:" + uuid);

			// プリファレンスにuuidを保持する.
			FlamingoSharedPreferences.getInstance().setUuid(mContext, uuid);

			// skipBrowserは動作テスト用
			boolean skipBrowser = false;
			skipBrowser = Boolean.valueOf(FlamingoResources.getResources(FlamingoAuthorizeActivity.this).getString(R.string.flamingo_skip_user_authorize_browser));

			if (!skipBrowser) {

				// ブラウザを起動する.

				Logging.d("Send browser intent. url=" + tempUri.toString());
				Intent i = new Intent(Intent.ACTION_VIEW, tempUri);
				i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(i);

			} else {

				// テスト用機能
				// ブラウザではなく認証結果受信Activityへ直接遷移する.

				if (Logging.DEBUG < Logging.getLogLevel()) {
					// ログが必ず出力されるようにする.
					Logging.setLogLevel(Logging.DEBUG);
				}

				Logging.w("== TEST ROUTINE IS RUNNING. SKIP USER AUTHORIZE BRPWSER. Return to result receive activity. == ==");

				Logging.d("uuid:" + uuid);

				Intent i = new Intent(getApplicationContext(), FlamingoAuthorizeActivity.class);

				// 末尾のRESULT=OK,NG部分を設定する.
				int resultTestMode = 0;

				Logging.d("resultTestMode=" + resultTestMode);

				String result = "";

				switch (resultTestMode) {

				case 0:
					result = "OK";
					break;

				case 1:
					result = "NG";
					break;

				case 2:
					result = "XX";
					break;

				default:
					result = "XXSX";
					break;
				}

				Logging.d("resultTestMode=" + resultTestMode + ", result=" + result);

				// getRedirectUri(uuid)の例
				// flamingo://jp.neos.android.dormouse.standalone/auth/callback/b4fdb467..

				Logging.d(uri.getRedirectUri(uuid));

				i.setData(Uri.parse(uri.getRedirectUri(uuid) + "?result=" + result));

				// 自アプリの戻り先アクティビティを呼び出す.
				startActivity(i);
			}
		}


		/**
		 * ユーザ認証時に使用するURIを取得する.
		 *
		 * @param uuid
		 *            UUID
		 * @return ユーザ認証用
		 */
		private Uri getUri(String uuid) {

			return uri.getUri(uuid);
		}


		/**
		 * ユーザ認証時に使用するURIを表すクラス.
		 */
		private class UserCertificateUri {

			/**
			 * コンテキスト
			 */
			private Context mContext;


			/**
			 * コンストラクタ
			 *
			 * @param context
			 *            コンテキスト
			 */
			UserCertificateUri(Context context) {

				mContext = context;
			}


			/**
			 * ユーザ認証接続先のスキーマ名を取得する<BR>
			 * 例) "http","https"
			 *
			 * @return ユーザ認証接続先スキーマ名
			 */
			private String getScheme() {

				Resources res = FlamingoResources.getResources(FlamingoAuthorizeActivity.this);
				return res.getString(R.string.flamingo_server_scheme);
			}


			/**
			 * ユーザ認証接続先に渡すリダイレクト用スキーマ名を取得する.<BR>
			 * 例)"flamingo"
			 *
			 * @return リダイレクト用スキーマ名
			 */
			private String getRedirectScheme() {

				Resources res = FlamingoResources.getResources(FlamingoAuthorizeActivity.this);
				return res.getString(R.string.flamingo_redirect_scheme);
			}


			/**
			 * ユーザ認証接続先に渡すリダイレクト用プリフィックスを取得する.<BR>
			 * 例) "/auth/callback/"
			 *
			 * @return リダイレクト用プリフィックス
			 */
			private String getRedirectPathPrefix() {

				Resources res = FlamingoResources.getResources(FlamingoAuthorizeActivity.this);
				return res.getString(R.string.flamingo_redirect_PathPrefix);
			}


			/**
			 * ユーザ認証接続先のAuthority（ホスト名）を取得する.<BR>
			 * 例) "stg.www.custamo.com"
			 *
			 * @return ユーザ認証接続先のAuthority
			 */
			private String getUrlAuthority() {

				Resources res = FlamingoResources.getResources(FlamingoAuthorizeActivity.this);
				return res.getString(R.string.flamingo_user_certificate_url_authority);
			}


			/**
			 * ユーザ認証接続先のパスを取得する.<BR>
			 * 例) "/smartp/FLM002"
			 *
			 * @return ユーザ認証接続先のパス
			 */
			private String getUrlPath() {

				Resources res = FlamingoResources.getResources(FlamingoAuthorizeActivity.this);
				return res.getString(R.string.flamingo_user_certificate_url_path);
			}


			/**
			 * IMEIを取得する.
			 *
			 * @return IMEI
			 */
			private String getImei() {

				return FlamingoUtil.getIncetance().getImei(getApplicationContext());
			}


			/**
			 * IMSIを取得する.
			 *
			 * @return IMSI
			 */
			private String getImsi() {

				return FlamingoUtil.getIncetance().getImsi(getApplicationContext());
			}


			/**
			 * アプリケーションのパッケージ名を取得する.
			 *
			 * @return アプリケーションのパッケージ名
			 */
			private String getUserPackageName() {

				return FlamingoUtil.getIncetance().getUserPackageName(getApplicationContext());
			}


			/**
			 * ユーザ認証に用いるリダイレクト用のURI文字列を取得する.
			 * <p>
			 * リダイレクト用のURI文字列の一部には引数で渡すUUIDも含まれる.
			 *
			 * @param uuid
			 *            UUID
			 * @return リダイレクト用のURI文字列
			 */
			public String getRedirectUri(String uuid) {

				String scheme = getRedirectScheme();
				String host = getUserPackageName();
				String pathPrefix = getRedirectPathPrefix() + uuid;

				Uri.Builder builder = new Uri.Builder();
				builder.scheme(scheme);
				builder.authority(host);
				builder.path(pathPrefix);

				Uri uri = builder.build();

				return uri.toString();
			}


			/**
			 * ユーザ認証用URIを取得する.
			 * <p>
			 * 例)http://www.xxxx.com/flamingo/auth?imei=12345&imsi=67890&redirect=flamingo%3A%2F%2Fjp.xxxxx.android.example%2Fcallback%2F12345
			 *
			 * @param uuid
			 *            UUID
			 * @return Uri文字列
			 */
			public Uri getUri(String uuid) {

				Uri.Builder builder = new Uri.Builder();
				builder.scheme(getScheme());
				builder.authority(getUrlAuthority());
				builder.path(getUrlPath());
				builder.appendQueryParameter("imei", getImei());
				builder.appendQueryParameter("imsi", getImsi());

				// URIエンコードがかかる.uuid部分に'-'が含まれていた場合、その部分は変換されない.
				builder.appendQueryParameter("redirect", getRedirectUri(uuid));

				Uri uri = builder.build();

				return uri;
			}
		}
	}


	/**
	 * 認可失敗通知API
	 *
	 * @param errorCode
	 *            エラー番号
	 */
	private void noticeAuthorizeErrorMessage(int errorCode) {

		Logging.d("errorCode=" + errorCode);
		FlamingoUtil flamingoUtil = FlamingoUtil.getIncetance();
		Intent intent = new Intent(flamingoUtil.getUserPackageName(getApplicationContext()));
		// 認証処理エラーを返す.
		intent.putExtra(Flamingo.CERTIFICATE_REQUEST_RESULT, Flamingo.CERTIFICATE_ERROR);
		intent.putExtra(Flamingo.CERTIFICATE_ERRORCODE, errorCode);
		sendBroadcast(intent);

		// アクティビティを終了する.
		finishActivity();

		Logging.d("");
	}


	/**
	 * 認可完了通知API
	 *
	 * @param hasLicense
	 *            ライセンスありフラグ
	 */
	private void noticeAuthorizeCompleteMessage(boolean hasLicense) {

		Logging.d("hasLicense = " + hasLicense);
		FlamingoUtil flamingoUtil = FlamingoUtil.getIncetance();
		Intent intent = new Intent(flamingoUtil.getUserPackageName(getApplicationContext()));
		// 認証処理成功を返す.
		intent.putExtra(Flamingo.CERTIFICATE_REQUEST_RESULT, Flamingo.CERTIFICATE_COMPLETE);
		// 認証結果を返す.
		intent.putExtra(Flamingo.CERTIFICATE_RESULT, hasLicense);
		sendBroadcast(intent);

		// アクティビティを終了する.
		finishActivity();

		Logging.d("");
	}


	/**
	 * 認可キャンセル通知API
	 */
	private void noticeAuthorizeCancelMessage() {

		Logging.d("");
		FlamingoUtil flamingoUtil = FlamingoUtil.getIncetance();
		Intent intent = new Intent(flamingoUtil.getUserPackageName(getApplicationContext()));
		// 認証処理キャンセルを返す.
		intent.putExtra(Flamingo.CERTIFICATE_REQUEST_RESULT, Flamingo.CERTIFICATE_CANCEL);
		sendBroadcast(intent);

		// アクティビティを終了する.
		finishActivity();

		Logging.d("");
	}


	/**
	 * ユーザ認証API レスポンスデータの検証.
	 *
	 * ユーザ認証APIのレスポンスデータとして渡されたデータの整合性を検証する. ユーザ認証OKであれば２回目のアプリ認証への遷移する. レスポンス内容に誤りがある場合、アプリケーション側へ通知を行う.
	 *
	 * @param intentUri
	 *            ユーザ認証の結果であるインテントのUri情報
	 */
	private void checkCertifyResponse(Uri intentUri) {

		String result = intentUri.getQueryParameter("result");

		List<String> list = intentUri.getPathSegments();
		String savedUuid = FlamingoSharedPreferences.getInstance().getUuid(getApplicationContext());

		String uuid = "";

		if (0 < list.size()) {
			String encodeUuid = list.get(list.size() - 1);

			try {
				uuid = URLDecoder.decode(encodeUuid, URL_ENCODE_DECODE_CHARSET);
			} catch (UnsupportedEncodingException e) {
				Logging.w("encodeUuid:" + encodeUuid + " " + e.toString());
				uuid = "";
			}
			Logging.d("encodeUuid: " + encodeUuid + ", Uuid:" + uuid + ", saved uuid:" + savedUuid);
		}

		if (uuid.length() != 0) {

			if (uuid.equalsIgnoreCase(savedUuid)) {

				// UUIDが一致した場合

				// 消費したUUIDはプリファレンスから消す.
				FlamingoSharedPreferences.getInstance().removeUuid(getApplicationContext());

				Logging.d("uuid match. result=[" + result + "]");

				if ((result != null) && ((0 < result.length()))) {
					if (result.equalsIgnoreCase("OK")) {
						// ユーザ認証成功

						Logging.d("User authorize is OK.");

						// 2回目のアプリケーション認可を実施

						enumAuthState = EnumAuthState.AUTH_STATE_BUSY_APP_AUTH2;
						Logging.d("[enumAuthState]=" + enumAuthState.name() + "(" + enumAuthState.getValue() + ")");

						requestApplicationAuthorize();

					} else if (result.equalsIgnoreCase("NG")) {
						// ユーザ認証失敗

						Logging.d("User authorize is NG.");

						// プリファレンスを初期化し、エラーで返す.
						// TODO: 2012/06/04 加藤(利) ネオス殿と認識合わせしたうえで、一旦プリファレンスデータを除去する実装はコメントアウトした.
						// （なお、ここでプリファレンスを削除する実装が正しいわけではない.プリファレンスを削除する実装を追加する場合、組み込み箇所を再検討すること.）
						// FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();
						// pref.removeAll(getApplicationContext());

						// アプリケーションは利用不可.
						noticeAuthorizeCompleteMessage(false);

					} else {

						Logging.d("unknown result. result =" + result);

						// サーバーエラーを通知する.
						noticeAuthorizeErrorMessage(FlamingoError.ERROR_CODE_SERVER);

					}
				} else {

					Logging.d("result is null or length is zero.");

					// サーバーエラーを通知する.
					noticeAuthorizeErrorMessage(FlamingoError.ERROR_CODE_SERVER);

				}
			} else {

				Logging.d("uuid not match");

				// サーバーエラーを通知する.
				noticeAuthorizeErrorMessage(FlamingoError.ERROR_CODE_SERVER);

			}
		} else {

			// UUIDが受け取れていない、あるいは異常なUUIDの場合

			Logging.w("uuid nothing");

			// サーバーエラーを通知する.
			noticeAuthorizeErrorMessage(FlamingoError.ERROR_CODE_SERVER);

		}
	}


	/**
	 * １回目のアプリケーション認可に対する結果受信コールバック
	 *
	 * @param response
	 *            レスポンスデータ
	 */
	private void onApplicationAuthorizeResult1(Map<String, String> response) {

		Logging.v("response = " + response);

		FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();

		try {
			// レスポンスデータの検証
			verifyAuthorizeResponse(response);
		} catch (FlamingoError e) {
			Logging.d("verifyAuthorizeResponse is error.");

			// プリファレンスを「認可なし」状態でクリアする.
			pref.setValidApplicationFlag(getApplicationContext(), false);
			pref.removeValidateDate(getApplicationContext());
			pref.removeGraceDays(getApplicationContext());

			// 認証エラー
			noticeAuthorizeErrorMessage(e.getErrorCode());
			return;
		}

		Logging.d("");
		// アプリケーション認可(1回目)に成功

		// 認証状態、期限の日時、期限超過後猶予日数を取得する.
		boolean hasLicense = false;
		String license = response.get("license");
		String validateDate = response.get("validateDate");
		String graceDays = response.get("graceDays");

		hasLicense = (license != null) && (license.equalsIgnoreCase("OK"));
		Logging.d("license = " + license + ", hasLicense = " + hasLicense);

		// プリファレンスに認証状態、期限の日時、期限超過後猶予日数を格納する.
		pref.setValidApplicationFlag(getApplicationContext(), hasLicense);
		pref.setValidateDate(getApplicationContext(), validateDate);
		pref.setGraceDays(getApplicationContext(), graceDays);

		if (!hasLicense) {
			Logging.d("not authorize");
			// 未認証の場合

			// ユーザ認証を開始する.
			requestUserCertificate();
			return;
		}

		// 認証済みの場合

		if (validateDate != null) {
			// 期限日時がnullでない場合 = 月額課金

			Logging.d("validateDate is not null");

			// この時点での期間チェックには「期限超過後猶予日数」は使用しない.
			if (FlamingoUtil.getIncetance().checkValidDate(validateDate, null)) {

				// 期間内であればユーザ認証は行わず、アプリケーションは利用可能とする.

				Logging.d("checkValidDate is OK.");

				// ここで処理を終えるため通知を行う.（アプリケーションは「利用可能」）
				noticeAuthorizeCompleteMessage(hasLicense);

			} else {

				Logging.d("checkValidDate is NG.");

				// ユーザ認証を開始する.
				requestUserCertificate();

			}
		} else {

			// 従量課金の場合

			Logging.d("valiateDate is null");

			// ユーザ認証の必要はない.
			// ここで処理を終えるため通知を行う.（アプリケーションは「利用可能」）
			noticeAuthorizeCompleteMessage(hasLicense);

		}
	}


	/**
	 * ２回目のアプリケーション認可に対する結果受信コールバック
	 *
	 * @param response
	 *            レスポンスデータ
	 */
	private void onApplicationAuthorizeResult2(Map<String, String> response) {

		Logging.v("response = " + response);

		FlamingoSharedPreferences pref = FlamingoSharedPreferences.getInstance();

		Logging.d("");

		// アプリケーション認可(2回目)に成功

		try {
			// レスポンスデータの検証
			verifyAuthorizeResponse(response);
		} catch (FlamingoError e) {
			Logging.d("verifyAuthorizeResponse is error.");

			// プリファレンスを「認可なし」状態でクリアする.
			pref.setValidApplicationFlag(getApplicationContext(), false);
			pref.removeValidateDate(getApplicationContext());
			pref.removeGraceDays(getApplicationContext());

			// 認証エラー
			noticeAuthorizeErrorMessage(e.getErrorCode());
			return;
		}

		// 認証状態、期限の日時、期限超過後猶予日数を取得する.
		boolean hasLicense = false;
		String license = response.get("license");
		String validateDate = response.get("validateDate");
		String graceDays = response.get("graceDays");

		hasLicense = (license != null) && (license.equalsIgnoreCase("OK"));
		Logging.d("license = " + license + ", hasLicense = " + hasLicense);

		// プリファレンスに認証状態、期限の日時、期限超過後猶予日数を格納する.
		pref.setValidApplicationFlag(getApplicationContext(), hasLicense);
		pref.setValidateDate(getApplicationContext(), validateDate);
		pref.setGraceDays(getApplicationContext(), graceDays);

		if (hasLicense) {

			// 認証済みの場合

			if (validateDate != null) {

				// 期限日時がnullでない場合 = 月額課金

				Logging.d("validateDate is not null");

				// この時点での期間チェックには「期限超過後猶予日数」は使用しない.
				if (FlamingoUtil.getIncetance().checkValidDate(validateDate, null)) {

					// 期間内であればアプリケーションは利用可能とする.

					Logging.d("checkValidDate is OK.");

					// ここで処理を終えるため通知を行う.
					noticeAuthorizeCompleteMessage(hasLicense);

				} else {

					Logging.d("checkValidDate is NG.");

					// 2回目の認可でも期日を超えているのでアプリケーションは利用不可とする.
					noticeAuthorizeCompleteMessage(false);

				}

			} else {

				// 従量課金の場合

				Logging.d("valiateDate is null");

				// ここで処理を終えるため通知を行う.（アプリケーションは「利用可能」）
				noticeAuthorizeCompleteMessage(hasLicense);

			}

		} else {

			Logging.d("not authorize");
			// 未認証の場合

			// 2回目の認可でも未認証なのでアプリケーションは利用不可.
			noticeAuthorizeCompleteMessage(false);

		}
	}


	/**
	 * アプリケーション認可の結果を受け取ったときに呼ばれるコールバック.
	 *
	 * @param response
	 *            レスポンスデータの結果.<BR>
	 *            有効なレスポンスデータがない場合、nullを設定すること.
	 */
	private void onPostApplicationAuthorized(Map<String, String> response) {

		switch (enumAuthState) {

		case AUTH_STATE_NONE: {
			break;
		}

		case AUTH_STATE_BUSY_APP_AUTH1: {
			onApplicationAuthorizeResult1(response);
			break;
		}

		case AUTH_STATE_WAIT_USER_AUTH: {
			break;
		}

		case AUTH_STATE_BUSY_APP_AUTH2: {
			onApplicationAuthorizeResult2(response);
			break;
		}

		default: {
			break;
		}

		}
	}


	/**
	 * アプリケーション認可API レスポンスデータの検証.
	 *
	 * <p>
	 * アプリケーション認可APIのレスポンスデータとして渡されたデータの整合性を検証する.<BR>
	 * 想定外のデータが格納されている場合は FlamingoError で通信エラーをアプリケーション側へ通知する.
	 *
	 * @param response
	 *            レスポンスデータ
	 * @throws FlamingoError
	 *             レスポンスデータが誤っている場合
	 */
	private void verifyAuthorizeResponse(Map<String, String> response) throws FlamingoError {

		// ネットワークエラー発生時
		if (response == null) {
			// ネットワークエラーを通知する.
			Logging.d("error authorize ");
			throw new FlamingoError(this, FlamingoError.ERROR_CODE_NETWORK);
		}

		// 認可結果を確認する.
		String resultStr = response.get("result");

		// 認可の結果がNG
		if ((resultStr == null) || (!resultStr.equalsIgnoreCase("OK"))) {
			// サーバーエラーを通知する.
			Logging.d("result NG");
			throw new FlamingoError(this, FlamingoError.ERROR_CODE_SERVER);
		}

		// 認証状態を確認する.
		String license = response.get("license");
		if (license == null) {
			throw new FlamingoError(this, FlamingoError.ERROR_CODE_SERVER);
		}
	}


	/**
	 * 後始末とアクティビティのfinishを行う.<BR>
	 * <BR>
	 * ・enumAuthState をクリアする.<BR>
	 * ・プリファレンスのUUIDを消去する.<BR>
	 * ・Activityのfinish()を行う.<BR>
	 */
	private void finishActivity() {

		Logging.d("Activity#finish.");

		enumAuthState = EnumAuthState.AUTH_STATE_NONE;
		Logging.d("[enumAuthState]=" + enumAuthState.name() + "(" + enumAuthState.getValue() + ")");
		FlamingoSharedPreferences.getInstance().removeUuid(this);
		finish();
	}


	/**
	 * onDestroy
	 *
	 * <p>
	 * 以下の処理を行う.<BR>
	 * ・プリファレンスのUUIDを消す.
	 *
	 * @see android.app.Activity#onDestroy()
	 */
	@Override
	protected void onDestroy() {

		Logging.d("onDestroy.");

		// プリファレンスに残されたUUIDは確実に消す.
		FlamingoSharedPreferences.getInstance().removeUuid(getApplicationContext());

		super.onDestroy();
	}


	/**
	 * プリファレンスにUUIDを保持しているかを取得する.
	 *
	 * @return プリファレンスにUUIDを保持しているとき true を返す.
	 */
	private boolean hasUuid() {

		String uuid = FlamingoSharedPreferences.getInstance().getUuid(this);

		boolean foundUuid = (uuid != null) && (uuid.length() != 0);
		return foundUuid;
	}
}
