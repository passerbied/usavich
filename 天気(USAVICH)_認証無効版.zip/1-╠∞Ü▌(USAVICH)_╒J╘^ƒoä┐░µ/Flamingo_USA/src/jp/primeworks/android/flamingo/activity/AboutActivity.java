package jp.primeworks.android.flamingo.activity;

import jp.primeworks.android.flamingo.R;
import jp.primeworks.android.flamingo.widget.AdView;
import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Flamingo common about activity.
 * 
 * @author takimura
 *
 */
public class AboutActivity extends Activity {

	/**
	 * Activity生成コールバック.
	 * 
	 * @param savedInstanceState
	 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.flamingo_about);

        PackageManager pm = getPackageManager();
        PackageInfo pkgInfo = null;
        ApplicationInfo appInfo = null;
        try {
            pkgInfo = pm.getPackageInfo(getPackageName(), 0);
            appInfo = pm.getApplicationInfo(getPackageName(), 0);
        } catch (NameNotFoundException e) {
            return;
        }

        // application version
        // string - app_name
        TextView appName = (TextView)findViewById(R.id.flamingo_about_app_name);
        appName.setText(appInfo.loadLabel(pm));

        // application icon
        // drawable - ic_launcher
        ImageView iconView = (ImageView)findViewById(R.id.flamingo_about_app_icon);
        iconView.setImageDrawable(appInfo.loadIcon(pm));

        // application version
        // string - app_version
        TextView version = (TextView)findViewById(R.id.flamingo_about_version);
        version.setText(pkgInfo.versionName);

        // provider
        // string - provider
        View providerLayout = findViewById(R.id.flamingo_about_provider_layout);
        if(getString(R.string.provider).length() == 0) {
        	providerLayout.setVisibility(View.GONE);
        }

        // copyright
        // string-array - copyright
        View copyrightLayout = findViewById(R.id.flamingo_about_copyright_layout);
        TextView copyright = (TextView)findViewById(R.id.flamingo_about_copyright);
        StringBuilder builder = new StringBuilder();
        String[] strArray = getResources().getStringArray(R.array.copyright);
        if(strArray != null && strArray.length > 0) {
            for(String str : strArray) {
            	if(builder.length() > 0) {
                    builder.append("\n");
            	}
                builder.append(str);
            }
            copyright.setText(builder.toString());
        } else {
        	copyrightLayout.setVisibility(View.GONE);
        }

        // use condition
        // string - condition
        View conditionLayout = findViewById(R.id.flamingo_about_condition_layout);
        if(getString(R.string.condition).length() == 0) {
        	conditionLayout.setVisibility(View.GONE);
        }

        // provider site
        // string - provider_home, provider_uri
        View providerSiteLayout = findViewById(R.id.flamingo_about_provider_site_layout);
        if(getString(R.string.provider_home).length() > 0) {
            TextView providerSite = (TextView)findViewById(R.id.flamingo_about_provider_site);
            providerSite.setMovementMethod(LinkMovementMethod.getInstance());
            providerSite.setText(Html.fromHtml(
            		"<a href=\"" + getString(R.string.provider_uri) + "\">" +
            		getString(R.string.provider_home) + "</a>"));
        } else {
        	providerSiteLayout.setVisibility(View.GONE);
        }

        // support site
        // string - support_home, support_uri
        View supportSiteLayout = findViewById(R.id.flamingo_about_support_site_layout);
        if(getString(R.string.support_home).length() > 0) {
        	supportSiteLayout.setVisibility(View.VISIBLE);
	        TextView supportSite = (TextView)findViewById(R.id.flamingo_about_support_site);
	        supportSite.setMovementMethod(LinkMovementMethod.getInstance());
	        supportSite.setText(Html.fromHtml(
	        		"<a href=\"" + getString(R.string.support_uri) + "\">" +
	        		getString(R.string.support_home) + "</a>"));
        } else {
        	supportSiteLayout.setVisibility(View.GONE);
        }

        // note
        // string - note
        View noteLayout = findViewById(R.id.flamingo_about_note_layout);
        if(getString(R.string.note).length() == 0) {
        	noteLayout.setVisibility(View.GONE);
        }

        // AdView
        // bool - flamingo_ad_on_about
        View adView = findViewById(R.id.flamingo_about_ad);
        if(getResources().getBoolean(R.bool.flamingo_ad_on_about)
        		&& AdView.isVisibleBanner(this)) {
        	adView.setVisibility(View.VISIBLE);
        }
    }

}
