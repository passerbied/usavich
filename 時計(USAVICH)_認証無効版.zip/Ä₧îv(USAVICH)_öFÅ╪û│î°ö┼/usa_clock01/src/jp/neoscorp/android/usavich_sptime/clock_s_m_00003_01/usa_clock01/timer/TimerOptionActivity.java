package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.timer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.R;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm.AlarmReceiver;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import jp.primeworks.android.flamingo.activity.FlamingoFragmentActivity;
import android.app.AlarmManager;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

public class TimerOptionActivity extends FlamingoFragmentActivity 
{
	public static String APP_CLOSE_ACTION = "com.taiyo.clock.action.APP_CLOSE_ACTION";
	public static String TIMER_STOP_ACTION = "com.taiyo.clock.action.TIMER_STOP_ACTION";
	private Button mBackBtn;
	private TextView mTimerTimeItem, mTimerSoundItem, mTimerTitleText;
	private CheckBox mTimerVibrateItem;
	private LinearLayout mSoundOption, mTimerTimeOption;
	private CommonReceiver mCommonReceiver;
	private boolean mbBackBtnActionStatus = false; 
	private List<String> mSoundNameList = new ArrayList<String>();
	private static MediaPlayer mMediaPlayer;
	private TimePicker picker;
	private static Uri mSoundUri;
	private static int mSoundSelectId = 0;
	private Dialog timeDialog = null, soundDialog = null;
	private boolean mbDialogStatus = false;
	private DisplayMetrics dm;
	private ImageView mMainBg;
	private final int ORG_SCREEN_WIDTH = 480; 
	private Typeface tf;
	
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		Utils.TIMEROPTION_ACTIVITY_DESTROYED_STATUS = false;
		setContentView(R.layout.timeroptionview);
		dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);	
        Utils.MAIN_TAB_SHOW_STATUS = true;
		mMainBg = (ImageView) findViewById(R.id.timeroptionbg);        
		tf = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/settings_A-OTF-ShinMGoPro-Medium.otf");
		mBackBtn = (Button) findViewById(R.id.backBtn);
		mSoundOption = (LinearLayout) findViewById(R.id.soundOption);
		mTimerTimeOption =  (LinearLayout) findViewById(R.id.timerTimeOption);
		mTimerTitleText =  (TextView) findViewById(R.id.timerTitleText);
		mTimerTimeItem = (TextView) findViewById(R.id.timertimeitem);
		mTimerSoundItem = (TextView) findViewById(R.id.timersounditem);
		mTimerVibrateItem = (CheckBox) findViewById(R.id.timervibrateitem);
		
		mBackBtn.setTypeface(tf);
		mTimerTitleText.setTypeface(tf);
		mTimerTitleText.setTextColor(Color.WHITE);
		mBackBtn.setTextColor(Color.WHITE);		
        
		mCommonReceiver = new CommonReceiver();
		mCommonReceiver.register();
		mbBackBtnActionStatus = false;
		mTimerTimeItem.setText(Utils.TIMER.split(":")[0] + ":" + Utils.TIMER.split(":")[1]);
		mTimerSoundItem.setText(Utils.TIMER_SOUNDNAME.equals("") ? "サイレント" : Utils.TIMER_SOUNDNAME);
		mSoundUri = Utils.getRingtoneByUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE,  Utils.getRingtoneUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE, 0, ""));
		
		if(mSoundUri != null)
		{
			mMediaPlayer = MediaPlayer.create(getApplicationContext(), mSoundUri);   
		}
		
		if(Utils.TIMER_VIBRATE.equals("ON")){
			mTimerVibrateItem.setChecked(true);
		}
		else{
			mTimerVibrateItem.setChecked(false);
		}
				
		mBackBtn.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				if(mbBackBtnActionStatus == false)
				{
					mbBackBtnActionStatus = true;
					Utils.TIMER = mTimerTimeItem.getText().toString() + ":00";
					TimerOptionActivity.this.finish();
				}
			}
		});
		
		mTimerTimeOption.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) 
			{
				if(mbDialogStatus == false)
				{
					mTimerTimeOption.setBackgroundColor(Color.TRANSPARENT);
					timeDialog = createTimeDialog();
					timeDialog.show(); 
			        timeDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD); 
			        mbDialogStatus = true;
			        timeDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
					{ 
						public void onDismiss(DialogInterface dialog) { 
							mbDialogStatus = false;	
						} 
					});
			        timeDialog.setOnKeyListener(new android.content.DialogInterface.OnKeyListener()
			        {  
			    	   public boolean onKey(DialogInterface dialog, int keyCode,KeyEvent event) 
			    	   {             	
			    	        switch (keyCode) 
			    	        {  
					          case KeyEvent.KEYCODE_BACK:  
					        	    timeDialog.dismiss();
									mTimerTimeOption.setBackgroundColor(Color.TRANSPARENT);
					        		mbDialogStatus = false;
				    	            return true;  					        	  
					          case KeyEvent.KEYCODE_HOME: 
					          case KeyEvent.KEYCODE_POWER:
					        	    timeDialog.dismiss();
									mTimerTimeOption.setBackgroundColor(Color.TRANSPARENT);
					        		mbDialogStatus = false;
					        		sendBroadcast(new Intent(APP_CLOSE_ACTION));
					        		TimerOptionActivity.this.finish();
				    	            return true;  
			    	        }  
			    	        return false;  
			    	    }  
			    	}); 
				}
			}
		});
		
		mSoundOption.setOnClickListener(new OnClickListener() 
		{			
			public void onClick(View arg0) {
				if(mbDialogStatus == false)
				{
					mSoundOption.setBackgroundColor(Color.TRANSPARENT);
					soundDialog = createSoundDialog();
					soundDialog.show();
					soundDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD); 
					mbDialogStatus = true;
					soundDialog.setOnDismissListener(new DialogInterface.OnDismissListener()
					{ 
						public void onDismiss(DialogInterface dialog) { 
							mbDialogStatus = false;	
						} 
					});
					soundDialog.setOnKeyListener(new android.content.DialogInterface.OnKeyListener()
			        {  
			    	   public boolean onKey(DialogInterface dialog, int keyCode,KeyEvent event) 
			    	   {             	
			    	        switch (keyCode) 
			    	        {  
					          case KeyEvent.KEYCODE_BACK:  
					        	  	soundDialog.dismiss();
					        		if(mSoundUri != null)
					        		{
					            		if(mMediaPlayer.isPlaying()){
					            			mMediaPlayer.stop();
					            		}
					        		}
					        		mSoundOption.setBackgroundColor(Color.TRANSPARENT);
					        		mbDialogStatus = false;
				    	            return true;  					        	  
					          case KeyEvent.KEYCODE_HOME: 
					          case KeyEvent.KEYCODE_POWER:
					        	  	soundDialog.dismiss();
					        		if(mSoundUri != null)
					        		{
					            		if(mMediaPlayer.isPlaying()){
					            			mMediaPlayer.stop();
					            		}
					        		}
					        		mSoundOption.setBackgroundColor(Color.TRANSPARENT);
					        		mbDialogStatus = false;
					        		sendBroadcast(new Intent(APP_CLOSE_ACTION));
					        		TimerOptionActivity.this.finish();
				    	            return true;  
			    	        }  
			    	        return false;  
			    	    }  
			    	}); 
				}
			}
		});
		
		mTimerVibrateItem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					Utils.TIMER_VIBRATE = "ON";
				} else {
					Utils.TIMER_VIBRATE = "OFF";
				}
			}
		});
	}
	
	protected void onResume()
	{
		super.onResume();
		if (Utils.TIMER_STATUS.equals("ON")) 
		{  
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); 
		} 
		else 
		{			
			getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		}
		mMainBg.setImageResource(R.drawable.watch_bg);
		mMainBg.setLayoutParams(getLinearLayoutPararm(0, 0, 480, 854));
	}
	
	public Dialog createTimeDialog()
	{
		Dialog dialog = null;
    	Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null); 
        builder.setTitle("時間");
        LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
        View view = inflater.inflate(R.layout.timepicker, null); 
        builder.setView(view);
        
        picker = (TimePicker) view.findViewById(R.id.time_picker);
		picker.setIs24HourView(true);
		
		picker.setCurrentHour(Integer.parseInt(Utils.TIMER.split(":")[0]));
		picker.setCurrentMinute(Integer.parseInt(Utils.TIMER.split(":")[1]));
    	
        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	mTimerTimeOption.setBackgroundColor(Color.TRANSPARENT);
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
            	picker.clearFocus();
            	mTimerTimeOption.setBackgroundColor(Color.TRANSPARENT);
            	Utils.TIMER = Utils.formartDigits(picker.getCurrentHour().intValue()) + ":" + Utils.formartDigits(picker.getCurrentMinute().intValue()) + ":00";
            	mTimerTimeItem.setText(Utils.TIMER.split(":")[0] + ":" + Utils.TIMER.split(":")[1]);
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        dialog = builder.create();
        
        return dialog;
	}
	
	public Dialog createSoundDialog()
	{
		Dialog dialog = null;
    	Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setIcon(null); 
        builder.setTitle("アラーム音");

        mSoundNameList = Utils.getSoundTitleList(getApplicationContext());
        
        for(int i = 0; i < mSoundNameList.size(); i++)
        {
        	if(mSoundNameList.get(i).equals(mTimerSoundItem.getText().toString().trim()))
        	{
        		mSoundSelectId = i;
        		break;
        	}
        }
        mSoundUri = null;
        builder.setSingleChoiceItems(mSoundNameList.toArray(new CharSequence[mSoundNameList.size()]), mSoundSelectId, 
        	new DialogInterface.OnClickListener()
        	{
        		public void onClick(DialogInterface dialog, int which) 
        		{
        			mSoundSelectId = which;
        			if(which == 0)
        			{
	            		if(mMediaPlayer.isPlaying())
	            		{
	            			mMediaPlayer.stop();
	            		}
	            		mSoundUri = null;
        			}
        			else
        			{
        				AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);  
        				am.adjustStreamVolume (AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_PLAY_SOUND); 
        				if(mMediaPlayer.isPlaying())
	            		{
	            			mMediaPlayer.stop();
	            			mSoundUri = null;
	            		}
	            		mSoundUri = Utils.getRingtoneByUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE,  Utils.getRingtoneUriPath(getApplicationContext(), RingtoneManager.TYPE_RINGTONE, which - 1, ""));
	            		try 
	            		{
	            			mMediaPlayer.reset();
							mMediaPlayer.setDataSource(getApplicationContext(), mSoundUri);
							mMediaPlayer.prepare();
							mMediaPlayer.start();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (SecurityException e) {
							e.printStackTrace();
						} catch (IllegalStateException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						} 
        		   }
               }
        });
        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
        		if(mSoundUri != null)
        		{
            		if(mMediaPlayer.isPlaying()){
            			mMediaPlayer.stop();
            		}
        		}
        		mSoundOption.setBackgroundColor(Color.TRANSPARENT);
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which) 
            {
        		if(mSoundUri != null)
        		{
            		if(mMediaPlayer.isPlaying()){
            			mMediaPlayer.stop();
            		}
        		}
        		mSoundOption.setBackgroundColor(Color.TRANSPARENT);
        		Utils.TIMER_SOUNDNAME = mSoundNameList.get(mSoundSelectId);
        		Utils.TIMER_SOUNDPATH = mSoundUri == null ? "" : mSoundUri.toString();
            	mTimerSoundItem.setText(Utils.TIMER_SOUNDNAME);
            	dialog.dismiss();
            	mbDialogStatus = false;
            }
        });
        
        dialog = builder.create();
        return dialog;
	}
    		            
	public void setTimer(int hour, int minute, int second, int alarmid)
	{
		AlarmManager alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);      
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(System.currentTimeMillis());
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, minute);
		calendar.set(Calendar.SECOND, second);
		calendar.set(Calendar.MILLISECOND, 0);
		
		Intent intent = new Intent();
		intent = new Intent(this,AlarmReceiver.class);  
		intent.putExtra("alarmid", ""+alarmid);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), alarmid, intent, PendingIntent.FLAG_UPDATE_CURRENT);
		alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
	}
	
    private class CommonReceiver extends BroadcastReceiver
	 {
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction(APP_CLOSE_ACTION);
			filter.addAction(TIMER_STOP_ACTION);
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			if (intent.getAction().equals(APP_CLOSE_ACTION)) 
		    {
	        	mMainBg.setImageDrawable(null);
	        	TimerOptionActivity.this.finish();
		    }
			if (intent.getAction().equals(TIMER_STOP_ACTION)) 
			{
				getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
			}				
		}
	}

	 protected void onDestroy() 
	 {
		 //Log.v("CLOCK", "TimerOptionActivity onDestroy");
		 Utils.TIMEROPTION_ACTIVITY_DESTROYED_STATUS = true;
		 mCommonReceiver.unRegister();
		 mMainBg.setImageDrawable(null);
		 super.onDestroy();
	 }
		
	 public LinearLayout.LayoutParams getLinearLayoutPararm(int x, int y, int w, int h)
	 {
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		params.leftMargin = dm.widthPixels * x / ORG_SCREEN_WIDTH;
		params.topMargin =  dm.widthPixels * y / ORG_SCREEN_WIDTH;
		params.width = dm.widthPixels * w / ORG_SCREEN_WIDTH;
		params.height = dm.widthPixels * h / ORG_SCREEN_WIDTH;
		
		return params;
	 }
	 
	 public void onAttachedToWindow() 
	 {
		  if (true) 
		  {
			  this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
		  }
		  super.onAttachedToWindow();
		  
	 }
	 
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		 switch(keyCode)
		 {
			 case KeyEvent.KEYCODE_BACK:
					if(mbBackBtnActionStatus == false)
					{
						mbBackBtnActionStatus = true;
						Utils.TIMER = mTimerTimeItem.getText().toString() + ":00";
						TimerOptionActivity.this.finish();
					}
					break;		
			 case KeyEvent.KEYCODE_HOME:
					if(mSoundUri != null)
					{
						if(mMediaPlayer.isPlaying()){
							mMediaPlayer.stop();
							mMediaPlayer.release();
						}
					}
					sendBroadcast(new Intent(APP_CLOSE_ACTION));
					TimerOptionActivity.this.finish();	
					break;
		 }
		return super.onKeyDown(keyCode, event);
    }
}
