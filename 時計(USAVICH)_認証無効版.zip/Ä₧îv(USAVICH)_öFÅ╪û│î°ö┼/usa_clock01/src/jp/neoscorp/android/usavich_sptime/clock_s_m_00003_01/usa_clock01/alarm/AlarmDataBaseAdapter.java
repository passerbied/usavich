package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class AlarmDataBaseAdapter 
{
	private Context mContext = null;
	private SQLiteDatabase mSQLiteDatabase = null;
	private AlarmDatabaseHelper dh = null;
	
	private final static String DB_NAME = "CLOCK.db";
	private final static int DB_VERSION = 1;
	private final static String TABLE_NAME   = "alarm_table";
	public final  String ALARM_ID            = "alarm_id";
	public final  String ALARM_TITLE         = "alarm_title";
	public final  String ALARM_HOUR          = "alarm_hour";
	public final  String ALARM_MINUTES       = "alarm_minutes";
	public final  String ALARM_SECOND        = "alarm_second";
	public final  String ALARM_WEEK          = "alarm_week";
	public final  String ALARM_WEEKTEXT      = "alarm_weektext";
	public final  String ALARM_ONOFF         = "alarm_onoff";
	public final  String ALARM_SOUNDNAME     = "alarm_soundname";
	public final  String ALARM_SOUNDPATH     = "alarm_soundpath";
	public final  String ALARM_VIBRATE       = "alarm_vibrate";
	public final  String ALARM_SNOOZE        = "alarm_snooze";
	
	private final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" + 
											ALARM_ID      + " INTEGER primary key autoincrement, " + 
											ALARM_TITLE   + " text, " + 						
											ALARM_HOUR    + " text, " + 
											ALARM_MINUTES + " text, " + 
											ALARM_SECOND  + " text, " + 
											ALARM_WEEK    + " text, " + 
											ALARM_WEEKTEXT + " text, " + 
											ALARM_ONOFF   + " text, " + 
											ALARM_SOUNDNAME   + " text, " + 
											ALARM_SOUNDPATH   + " text, " + 
											ALARM_VIBRATE + " text, " + 
											ALARM_SNOOZE  + " text  );";
	
	public AlarmDataBaseAdapter(Context context){
		mContext = context;
	}

	public void open(){
		dh = new AlarmDatabaseHelper(mContext,DB_NAME,null,DB_VERSION,CREATE_TABLE,TABLE_NAME);
		mSQLiteDatabase = dh.getWritableDatabase();
	}

	public void close(){
		dh.close();
		dh = null;
		mSQLiteDatabase.close();
		mSQLiteDatabase = null;
		mContext = null;
	}
	
	public Cursor selectAllByAlarmIdAsc()
	{
		try{
			String sql = "SELECT * FROM " + TABLE_NAME + "  ORDER BY " + ALARM_ID  + " ASC ";
			return mSQLiteDatabase.rawQuery(sql, null);
		}catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	}

	public boolean selectAllDescSkipAlarmIdOnOff(int skipAlarmId, String onoff)
	{
		Cursor cursor = null;
		try{
			String sql = "SELECT * FROM " + TABLE_NAME + " WHERE " + ALARM_ID + " <> " + skipAlarmId + " AND ALARM_ONOFF = '" + onoff + "' ORDER BY " + ALARM_ID  + " DESC ";
			cursor =  mSQLiteDatabase.rawQuery(sql, null);
			if(cursor.getCount() > 0)
			{
				cursor.close();
				cursor = null;
				return true;
			}
			else
			{
				cursor.close();
				cursor = null;
				return false;
			}
		}catch(Exception ex){
			cursor.close();
			cursor = null;
			ex.printStackTrace();
			return false;
		}
	}
	
	public Cursor selectByAlarmId(int alarmId) 
	{
		try{
			String sql = "SELECT * FROM " + TABLE_NAME + " WHERE " + ALARM_ID  + " = " + alarmId;
			return mSQLiteDatabase.rawQuery(sql, null);
			
		}catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	
	
	public int selectMaxAlarmId() 
	{
		Cursor cursor = null;
		int maxalarmid = -1;
		try{
			String sql = "SELECT " + ALARM_ID + " FROM " + TABLE_NAME + " ORDER BY " + ALARM_ID  + " DESC ";
			cursor = mSQLiteDatabase.rawQuery(sql, null);
			if(cursor.getCount() == 0)
			{
				cursor.close();
				cursor = null;
				return -1;
			}
			else{
				cursor.moveToFirst();
				maxalarmid = cursor.getInt(cursor.getColumnIndex(ALARM_ID));
				cursor.close();
				cursor = null;
			}
		}catch(Exception ex){
			cursor.close();
			cursor = null;
			ex.printStackTrace();
			return -1;
		}
		return maxalarmid;
	}
	
	public String selectAlarmId(String hour, String minutes, int week) 
	{
		Cursor cursor = null;
		String alarmId = "";
		
		try{
			String sql = "SELECT * FROM " + TABLE_NAME + " WHERE " + ALARM_HOUR + " = '" + hour + "' AND " + ALARM_MINUTES + " = '" + minutes + "' AND " + ALARM_WEEK + " = '" + week + "'";
			cursor = mSQLiteDatabase.rawQuery(sql, null);

			if(cursor == null){
				return null;
			}
			else if(cursor.getCount() > 0){
				cursor.moveToFirst();
				alarmId = "" + cursor.getInt(cursor.getColumnIndex(ALARM_ID));
				cursor.close();
				cursor = null;
			}
		}catch(Exception ex){
			cursor.close();
			cursor = null;
			ex.printStackTrace();
			return null;
		}
		
		return alarmId;
	}
	
	public void insert(String title,	
                       String hour, 
                       String minutes, 
                       String second, 
                       String week, 
                       String weektext, 
                       String onoff, 
                       String soundname, 
                       String soundpath,
                       String vibrate, 
			           String snooze) 
	{
		try{
			ContentValues cv = new ContentValues();
			cv.put(ALARM_TITLE, title);
			cv.put(ALARM_HOUR, hour);
			cv.put(ALARM_MINUTES, minutes);
			cv.put(ALARM_SECOND, second);
			cv.put(ALARM_WEEK, week);
			cv.put(ALARM_WEEKTEXT, weektext);
			cv.put(ALARM_ONOFF, onoff);
			cv.put(ALARM_SOUNDNAME, soundname);
			cv.put(ALARM_SOUNDPATH, soundpath);
			cv.put(ALARM_VIBRATE, vibrate);
			cv.put(ALARM_SNOOZE, snooze);
			mSQLiteDatabase.insert(TABLE_NAME, null, cv);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public void deleteByAlarmId(int alarmId) 
	{
		try{
			mSQLiteDatabase.delete(TABLE_NAME, " ALARM_ID = " + alarmId, null);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public void update( int alarmid, 
			            String title, 					
						String hour, 
						String minutes, 
						String second, 
						String week, 
						String weektext, 
						String onoff, 
	                    String soundname, 
	                    String soundpath,
						String vibrate, 
						String snooze) 
	{
		try{
			String sql = "UPDATE " + TABLE_NAME + " SET " + 
								ALARM_TITLE + " = '" + title + "', " +
								ALARM_HOUR + " = '" + hour + "', " +
								ALARM_MINUTES + " = '" + minutes + "', " +
								ALARM_SECOND + " = '" + second + "', " +
								ALARM_WEEK + " = '" + week + "', " +
								ALARM_WEEKTEXT + " = '" + weektext + "', " +
								ALARM_ONOFF + " = '" + onoff + "', " +
								ALARM_SOUNDNAME + " = '" + soundname + "', " +
								ALARM_SOUNDPATH + " = '" + soundpath + "', " +
								ALARM_VIBRATE + " = '" + vibrate + "', " +
								ALARM_SNOOZE + " = '" + snooze + "' " +
								" WHERE " + ALARM_ID + " = " + Integer.toString(alarmid);
			
			mSQLiteDatabase.execSQL(sql);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void updateAlarmOnOffByAlarmId( String alarmId, String onoff) 
	{
		try{
			String sql = "UPDATE "+ TABLE_NAME + " SET " + ALARM_ONOFF + " = '" + onoff + "' WHERE " + ALARM_ID + " = " + alarmId;
			
			mSQLiteDatabase.execSQL(sql);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}	
	
	public void updateSingleSameAlarmOnOff(String hour, String minutes, String onoff) 
	{
		try{
			String sql = "UPDATE "+ TABLE_NAME + " SET " + ALARM_ONOFF + " = '" + onoff + "' WHERE " + ALARM_WEEK + " = '' AND " + ALARM_HOUR  + " = '" + hour + "' AND " + ALARM_MINUTES  + " = '" + minutes + "'";
			
			mSQLiteDatabase.execSQL(sql);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}	
	
	public void updateAllAlarmToOff() 
	{
		try{
			String sql = "UPDATE "+ TABLE_NAME + " SET " + ALARM_ONOFF + " = 'OFF' ";
			
			mSQLiteDatabase.execSQL(sql);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}	

}

