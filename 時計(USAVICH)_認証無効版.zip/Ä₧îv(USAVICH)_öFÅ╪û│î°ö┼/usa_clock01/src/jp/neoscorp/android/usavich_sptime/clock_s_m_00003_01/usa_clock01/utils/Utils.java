package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;

public class Utils 
{
	public static boolean sCanAuto = false;
	public static final int PENDING_FLAMINGO_TIMING = 1001;
	public static final long AUTHORIZE_RATE = 6 * 60 * 60 * 1000;	
	public static final String ACTION_WIDGET_SERVICE = "jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.widget.ACTION_WIDGET_SERVICE";
	public static final String ACTION_TIMER_SERVICE = "jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.timer.ACTION_TIMER_SERVICE";
	public static final String ACTION_ALARM_SERVICE = "jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm.ACTION_ALARM_SERVICE";
	public static int TAB_ID = 1;
	public static boolean MAIN_TAB_SHOW_STATUS = false;
	public static boolean MAIN_TAB_ACTIVITY_DESTROYED_STATUS = false;
	public static boolean ALARMLIST_ACTIVITY_DESTROYED_STATUS = true;
	public static boolean TIMEROPTION_ACTIVITY_DESTROYED_STATUS = true;
	public static String  MAIN_TAB_ACTIVITY_STATUS = "";
	public static boolean ALARM_ICON = false;
	public static String TIMER = "00:00:00";
	public static String TIMER_SOUNDNAME = "";
	public static String TIMER_SOUNDPATH = "";
	public static String TIMER_VIBRATE   = "OFF";
	public static String TIMER_STATUS    = "OFF";
	
	
	public static void initTimerData()  
	{
		Utils.TIMER           = "00:00:00";
		Utils.TIMER_SOUNDNAME = "";
		Utils.TIMER_SOUNDPATH = "";
		Utils.TIMER_VIBRATE   = "OFF";
		Utils.TIMER_STATUS    = "OFF";
	}
	
	public static String formartStringLength(String input)
	{
        char c[] = input.toCharArray();      
        for (int i = 0; i < c.length; i++) {      
          if (c[i] == ' ') {      
            c[i] = '\u3000';     
          } else if (c[i] < '\177') {    
            c[i] = (char) (c[i] + 65248);  
          }      
        }  
        
        String str = new String(c);
        if(str.length() >= 12){
        	str = str.substring(0, 10) + "..";
        }
        
       return  str;     
	}
	
	public static String formartDigits(int n)
	{ 
		  NumberFormat formatter = NumberFormat.getNumberInstance();   
		  formatter.setMinimumIntegerDigits(2);   
		  formatter.setGroupingUsed(false);   
		  return formatter.format(n); 
	}
	
	
	public static List<String> getSoundTitleList(Context mCtx) 
	{
		List<String> mSoundNameList = new ArrayList<String>();
		mSoundNameList.add("サイレント");
		
		RingtoneManager manager = new RingtoneManager(mCtx);
		manager.setType(RingtoneManager.TYPE_RINGTONE);
		Cursor cursor = manager.getCursor();

		if (cursor.moveToFirst())
		{
		    do {
		    	mSoundNameList.add(cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX));
			} while (cursor.moveToNext());
		}
		
		return mSoundNameList;
	}
	
	public static Uri getRingtoneByUriPath(Context mCtx, int type, String uriPath) 
	{
		RingtoneManager manager = new RingtoneManager(mCtx);

		manager.setType(type);

		return Uri.parse(uriPath);
	}
	
	public static String getRingtoneUriPath(Context mCtx, int type,int pos,String def)
	{ 
		List<Uri> mSoundUriList = new ArrayList<Uri>();
		RingtoneManager manager = new RingtoneManager(mCtx);
		manager.setType(type);
		Cursor cursor = manager.getCursor();

		if (cursor.moveToFirst()) {
			do {
				Uri uri = manager.getRingtoneUri(cursor.getPosition());
				mSoundUriList.add(uri);
			} while (cursor.moveToNext());
		}
		cursor.close();
	 
	    Uri uri = mSoundUriList.get(pos);
	 
	    return uri == null ? def : uri.toString(); 
	} 
}
