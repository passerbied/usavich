package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.parsers.ParserConfigurationException;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.flamingo.FlamingoTimingReceiver;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.flamingo.WidgetFlamingoActivity;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.City;
import jp.primeworks.android.flamingo.Flamingo;
import jp.primeworks.android.flamingo.Flamingo.OnAuthorizeListner;
import jp.primeworks.android.flamingo.FlamingoError;

import org.xml.sax.SAXException;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.widget.RemoteViews;

public class UpdateService extends Service {
	public static final String TAG = "UpdateService";
	private static final String URL_SITE = "http://www.custamo.com/smartp/weather/?code=";

	private static final int SHOW_TOAST = 1;
	
	private Context mContext;
	private City mCurrCity;
	private long mUpdateRate = 3 * 60 * 60 * 1000;
	
	private boolean mIsAuto = false;
	private boolean mIsManu = false;
	private boolean mTimeSetted = false;
	private int mUpdateCount = 0;
	
	private UpdateThread mUpdateThread;

	private AlarmReceiver mAlarmReceiver;
	private FlamingoTimingReceiver mTimingReceiver;
	
	private String mToastMsg;
	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case SHOW_TOAST:
				if (Utils.sActivityAlive) {
					Utils.showToast(mContext, mToastMsg);
				}
				break;

			default:
				break;
			}
		}
	};

	@Override
	public IBinder onBind(Intent intent) {
		return new MBinder();
	}

	@Override
	public void onCreate() {
		super.onCreate();
		mContext = UpdateService.this;
		Utils.initInfos(mContext);
		mUpdateCount = Utils.getUpdateCount();

		Intent pIntent = new Intent();
		pIntent.setAction(FlamingoTimingReceiver.ACTION_FLAMINGO_TIMING);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(
				mContext, Utils.PENDING_FLAMINGO_TIMING, 
				pIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
		alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, 
				0, Utils.AUTHORIZE_RATE, pendingIntent);

		mTimingReceiver = FlamingoTimingReceiver.getInstance(mContext);
		mTimingReceiver.register();

		Flamingo flamingo = new Flamingo(mContext);
		if (!Utils.sCanAuto) {
//			if (!flamingo.isValidApplication()) {
			if (!true) {
				flamingo.authorize(false, new OnAuthorizeListner() {
					
					@Override
					public void onError(FlamingoError error) {
						setWidgets();
						Utils.sCanAuto = true;
					}
					
					@Override
					public void onComplete(boolean authorizeOk) {
						setWidgets();
						Utils.sCanAuto = true;
					}
					
					@Override
					public void onCancel() {
						setWidgets();
						Utils.sCanAuto = true;
					}
				});
			} else {
				Utils.sCanAuto = true;
				setWidgets();
			}
		}
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		super.onStartCommand(intent, flags, startId);

		if (Utils.sCanAuto) {
			setWidgets();
		}
		
		return START_STICKY;
	}

	private void setTimer() {
		getSetting();
		cancelTimer();
		long next = System.currentTimeMillis() + mUpdateRate;
		if (mUpdateRate != 0) {
			AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
			PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext,
					50, new Intent(Utils.ACTION_TIMER_BROADCAST),
					PendingIntent.FLAG_UPDATE_CURRENT);
			alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, next, mUpdateRate,
					pendingIntent);
			mTimeSetted = true;
		}
	}
	
	public void setWidgets() {
		Flamingo flamingo = new Flamingo(this);
//		boolean isValidApp = flamingo.isValidApplication();
		boolean isValidApp = true;
		if (isValidApp) {
		
			if (!mTimeSetted) {
				mAlarmReceiver = new AlarmReceiver();
				mAlarmReceiver.register();
				setTimer();
			}
			
			if (Utils.needUpdate(mContext)) {
				FirstUpdateThread firstThread = new FirstUpdateThread();
				firstThread.start();
			}
			Utils.updateWidget(mContext);
		} else {
			if (mTimeSetted) {
				cancelTimer();
			}
		}

		int[] ids = Utils.getWidgetIds(mContext);
		for (int id : ids) {
			if (isValidApp) {
				setValidWidget(id);
			} else {
				setInvalidWidget(id);
			}
		}
	}

	private void cancelTimer() {
		AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext, 50,
				new Intent(Utils.ACTION_TIMER_BROADCAST),
				PendingIntent.FLAG_UPDATE_CURRENT);
		alarmManager.cancel(pendingIntent);
		mTimeSetted = false;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		Utils.setUpdateCount(mContext, mUpdateCount);
		if (mAlarmReceiver != null) {
			mAlarmReceiver.unRegister();
		}
		
		if (mTimingReceiver != null) {
			mTimingReceiver.unregister();
		}
		
		cancelTimer();
		mUpdateCount = Utils.getUpdateCount();
		Utils.closeDB();
		
		Intent pIntent = new Intent();
		pIntent.setAction(FlamingoTimingReceiver.ACTION_FLAMINGO_TIMING);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(
				mContext, Utils.PENDING_FLAMINGO_TIMING, 
				pIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		AlarmManager alarmManager = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
		alarmManager.cancel(pendingIntent);
		Utils.sCanAuto = false;
	}
	
	public void requestedDataFromServer() {
		mUpdateThread = new UpdateThread();
		mUpdateThread.start();
	}

	private void getSetting() {
		mCurrCity = Utils.getCity(mContext);
		mUpdateRate = Utils.getUpdateRate();
	}

	private void notifyAllElements(int connCode) {
		Utils.updateWidget(mContext);
		if ((mUpdateCount == 2 || mUpdateCount == 3) && !mIsAuto && !mIsManu 
				&& connCode != Utils.CODE_SUCCESS) {
			// do nothing
		} else {
			showStatusMessage(connCode);
		}
		Intent intent = new Intent();
		intent.setAction(Utils.ACTION_DATA_RECEIVED);
		intent.putExtra(Utils.CONN_CODE, connCode);
		mContext.sendBroadcast(intent);
	}
	
	public void showStatusMessage(int status) {
		mToastMsg = (status == 0 ? getString(R.string.receive_ok_msg)
				: getString(R.string.connect_error_msg));
		mHandler.sendEmptyMessage(SHOW_TOAST);
		mIsAuto = false;
		mIsManu = false;
	}
	
	public void setValidWidget(int id){
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(mContext);

		RemoteViews views = new RemoteViews(mContext.getPackageName(),
				R.layout.widget);
		views.setViewVisibility(R.id.tv_widget_invalidtxt, View.INVISIBLE);
			
		Intent intent = new Intent(mContext, WeatherActivity.class);
		PendingIntent pending = PendingIntent.getActivity(mContext, 0,
				intent, 0);
		views.setOnClickPendingIntent(R.id.root_widget_root, pending);
		appWidgetManager.updateAppWidget(id, views);
	}
	
	public void setInvalidWidget(int id) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(mContext);
		RemoteViews views = new RemoteViews(mContext.getPackageName(),
				R.layout.widget);
		views.setViewVisibility(R.id.tv_widget_invalidtxt, View.VISIBLE);
		
		Intent intent = new Intent();
		intent.setClass(mContext, WidgetFlamingoActivity.class);
		intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
		PendingIntent pending = PendingIntent.getActivity(mContext,
				1, intent, intent.getFlags());
		views.setOnClickPendingIntent(R.id.root_widget_root, pending);
		views.setImageViewResource(R.id.iv_widget_content, R.drawable.img_bg_widget_bg);
		
		appWidgetManager.updateAppWidget(id, views);
		
	}
	
	public class MBinder extends Binder {

		public void update() {
			mIsManu = true;
			requestedDataFromServer();
		}

		public void resetUpdateCount() {
			mUpdateCount = 0;
		}

		public void cancelServiceTimer() {
			cancelTimer();
		}

		public void resetTimer() {
			setTimer();
		}
	}

	private class AlarmReceiver extends BroadcastReceiver {

		public void register() {
			IntentFilter filter = new IntentFilter();
			filter.addAction(Utils.ACTION_TIMER_BROADCAST);
			registerReceiver(this, filter);
		}

		public void unRegister() {
			unregisterReceiver(this);
		}

		@Override
		public void onReceive(Context context, Intent intent) {
			mIsAuto = true;
			requestedDataFromServer();
		}
	}
	
	private class FirstUpdateThread extends Thread {

		@Override
		public void run() {
			while (mUpdateCount < 3) {
				requestedDataFromServer();
				mUpdateCount ++;
				if (mUpdateCount != 3) {
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						// do Nothing
					}
				}
			}
		}
	}

	private class UpdateThread extends Thread {
		@Override
		public void run() {
			getSetting();
			int connCode = 1;
			try {
				if (mCurrCity == null) {
					mCurrCity = Utils.getCity(mContext);
				}
				URL url = new URL(URL_SITE + mCurrCity.getCode());
				HttpURLConnection conn = (HttpURLConnection) url
						.openConnection();
				conn.setConnectTimeout((int) Utils.CONN_FAIL_TIME_OUT);
				conn.setRequestMethod("GET");
				InputStream is = conn.getInputStream();
				Utils.parseWeatherXml(is);
				connCode = Utils.CODE_SUCCESS;
			} catch (MalformedURLException e) {
//				Log.e(TAG, "ERROR 1 - MalformedURLException");
				connCode = Utils.CODE_CONN_ERROR;
			} catch (IOException e) {
//				Log.e(TAG, "ERROR 2 - IOException");
				connCode = Utils.CODE_CONN_ERROR;
			} catch (ParserConfigurationException e) {
//				Log.e(TAG, "ERROR 2 - ParserConfigurationException");
				connCode = Utils.CODE_CONN_ERROR;
			} catch (SAXException e) {
//				Log.e(TAG, "ERROR 2 - SAXException");
				connCode = Utils.CODE_CONN_ERROR;
			} catch (NullPointerException e) {
//				Log.e(TAG, "ERROR 2 - NullPointerException");
				connCode = Utils.CODE_CONN_ERROR;
			}
			
			if (connCode == Utils.CODE_SUCCESS) {
				Utils.saveLastInfo(mContext);
				mUpdateCount = (mIsAuto == false ? 3 : 0);
				Utils.setUpdateCount(mContext, mUpdateCount);
			}
			Utils.setCity(mContext, mCurrCity);
			Utils.getInfosFromDB(mContext);
			notifyAllElements(connCode);
		}
	}
}
