package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.timer;

import java.util.Timer;
import java.util.TimerTask;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;

public class TimerService extends Service 
{
	public static String TIMER_UPDATE_ACTION = "com.taiyo.clock.action.TIMER_UPDATE_ACTION";
	public static String TIMER_START_ACTION = "com.taiyo.clock.action.TIMER_START_ACTION";
	public static String TIMER_STOP_ACTION = "com.taiyo.clock.action.TIMER_STOP_ACTION";
	private int time, hoursInt, minutesInt, secondsInt;
	private boolean isStop = false, isStart = false;
	private Timer mTimer = null;
	private TimerTask mTimerTask = null;
	private AlarmReceiver mAlarmReceiver;
	private Context mContext;

	public IBinder onBind(Intent arg0) 
	{
		return null;
	}

	public void onCreate() 
	{
		super.onCreate();
		mContext = this;
		mAlarmReceiver = new AlarmReceiver();
		mAlarmReceiver.register();
	}
	
	public void onStart(Intent intent, int startId) 
	{
		super.onStart(intent, startId);
	}
	
	public void onDestroy() 
	{
		super.onDestroy();
		mAlarmReceiver.unRegister();
	}
	
	private class AlarmReceiver extends BroadcastReceiver
	{
		public void register() 
		{
			IntentFilter filter = new IntentFilter();
			filter.addAction(TIMER_START_ACTION);
			filter.addAction(TIMER_STOP_ACTION);
			registerReceiver(this, filter);
		}

		public void unRegister() 
		{
			unregisterReceiver(this);
		}

		public void onReceive(Context context, Intent intent) 
		{
			if (intent.getAction().equals(TIMER_START_ACTION)) 
			{
				startTimer();
			}	
			if (intent.getAction().equals(TIMER_STOP_ACTION)) 
			{
				stopTimer();
			}				
		}
	}
	
	private void startTimer() 
	{
		isStart = true;
		hoursInt = Integer.parseInt(Utils.TIMER.split(":")[0]);
		minutesInt = Integer.parseInt(Utils.TIMER.split(":")[1]);
		secondsInt = Integer.parseInt(Utils.TIMER.split(":")[2]);
		
		if (mTimer == null) 
		{
			mTimer = new Timer();
		}

		if (mTimerTask == null) 
		{
			mTimerTask = new TimerTask() 
			{
				public void run() 
				{
					do {
						try {
							
							updateCurrentTime();
							
							Thread.sleep(1000);
						} catch (InterruptedException e) {
						}
					} while (isStop);
				}
			};
		}

		if (mTimer != null && mTimerTask != null)
			mTimer.schedule(mTimerTask, 1000, 1000);
	}

	private void stopTimer() 
	{
		isStart = false;
		if (mTimer != null) 
		{
			mTimer.cancel();
			mTimer = null;
		}

		if (mTimerTask != null) 
		{
			mTimerTask.cancel();
			mTimerTask = null;
		}
	}
	
	private void updateCurrentTime() 
	{
		time = hoursInt * 3600 + minutesInt * 60 + secondsInt;
		
		if (time > 0)
		{
			time--;
			
			if(Utils.TIMER_STATUS.equals("ON") && time <= 0)
			{
				if(isStart)
				{
					if(Utils.MAIN_TAB_ACTIVITY_STATUS.equals("onStop") && 
					   Utils.MAIN_TAB_ACTIVITY_DESTROYED_STATUS == false &&
					   Utils.ALARMLIST_ACTIVITY_DESTROYED_STATUS == true && 
					   Utils.TIMEROPTION_ACTIVITY_DESTROYED_STATUS == true)
					{
						mContext.startService(new Intent(Utils.ACTION_ALARM_SERVICE));
					}
					isStart = false;
					stopTimer();
					Utils.TIMER_STATUS = "OFF";
					Intent intent = new Intent();
					intent.setClass(mContext, TimerAlert.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
					mContext.startActivity(intent);
				}
			}
		} 

		hoursInt   = time / 3600;
		minutesInt = (time - hoursInt * 3600) / 60;
		secondsInt = time - hoursInt * 3600 - minutesInt * 60;
		
		if(Utils.TIMER_STATUS.equals("ON"))
			Utils.TIMER = (Utils.formartDigits(hoursInt) + ":" + Utils.formartDigits(minutesInt) + ":" + Utils.formartDigits(secondsInt));
		else
			Utils.TIMER = "00:00:00";
	}
}
