package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.app.Application;

public class MemoApplication extends Application {
	private String memoPassword;
	private boolean isStartReceiver = false; 
	private boolean isStartShortcut = false;
	private Sort sortName;
	public enum Category {DUCK,BEAR,RABBIT,GIRAFFE,ELEPHANT}; 
	public enum Sort {DATE_ASCENDING,DATE_DESCENDING,CONTENT_ASCENDING,CONTENT_DESCENDING};
	private List<Map<String,String>> shoutCutNameList = new ArrayList<Map<String,String>>();
	
	public boolean isStartReceiver() {
		return isStartReceiver;
	}
	public void setIsStartReceiver(boolean isStartReceiver) {
		this.isStartReceiver = isStartReceiver;
	}
	public List<Map<String, String>> getShoutCutNameList() {
		return shoutCutNameList;
	}
	public void setShoutCutNameList(List<Map<String, String>> shoutCutNameList) {
		this.shoutCutNameList = shoutCutNameList;
	}
	public boolean checkPasswordStatus = false;
	

	public boolean isCheckPasswordStatus() {
		return checkPasswordStatus;
	}
	public void setCheckPasswordStatus(boolean checkPasswordStatus) {
		this.checkPasswordStatus = checkPasswordStatus;
	}
	
	private List<Map<String, Object>> positionMap;
	
	public List<Map<String, Object>> getPositionMap() {
		return positionMap;
	}

	public void setPositionMap(List<Map<String, Object>> positionMap) {
		this.positionMap = positionMap;
	}
	
	public String getMemoPassword() {
		return memoPassword;
	}

	public void setMemoPassword(String memoPassword) {
		this.memoPassword = memoPassword;
	}
	public Sort getSortName() {
		return sortName;
	}

	public void setSortName(Sort sortName) {
		this.sortName = sortName;
	}
	public boolean isStartShortcut() {
		return isStartShortcut;
	}
	public void setStartShortcut(boolean isStartShortcut) {
		this.isStartShortcut = isStartShortcut;
	}
}
