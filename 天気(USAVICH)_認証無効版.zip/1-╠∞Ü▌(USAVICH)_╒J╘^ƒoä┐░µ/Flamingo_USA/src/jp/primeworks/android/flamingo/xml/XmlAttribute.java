package jp.primeworks.android.flamingo.xml;

public class XmlAttribute {

    private String name;

    private String prefix;

    public XmlAttribute(String prefix, String name) {
    	setPrefix(prefix);
    	setName(name);
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

}
