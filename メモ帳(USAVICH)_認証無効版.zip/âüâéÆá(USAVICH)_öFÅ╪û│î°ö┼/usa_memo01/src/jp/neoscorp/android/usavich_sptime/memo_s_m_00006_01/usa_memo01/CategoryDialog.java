package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;


import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.utils.Util;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
public class CategoryDialog extends Dialog {

	private Context mContext;
	private Dialog dialog;
	private Intent intent;
	private String categoryStr;
	public CategoryDialog(Context context,Intent intent) {
		super(context);
		mContext = context;
		this.intent = intent;
	}
	public void showCategoryDialog(int screenWidth,int screenHeight,DisplayMetrics dm, final int type)
	{
		dialog = new Dialog(mContext,R.style.AlertDialog);
        LayoutInflater inflater=(LayoutInflater)mContext.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);  
        inflater =  dialog.getLayoutInflater();
        View view = inflater.inflate(R.layout.memo_category, null);
        final RadioButton radio01 = (RadioButton)view.findViewById(R.id.radio0);
        final RadioButton radio02 = (RadioButton)view.findViewById(R.id.radio1);
        final RadioButton radio03 = (RadioButton)view.findViewById(R.id.radio2);
        final RadioButton radio04 = (RadioButton)view.findViewById(R.id.radio3);
        final RadioButton radio05 = (RadioButton)view.findViewById(R.id.radio4);
        radio01.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio02.setChecked(false);
					radio03.setChecked(false);
					radio04.setChecked(false);
					radio05.setChecked(false);
					intent.putExtra("category", "0");
				}	
			}
		});
        radio02.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio01.setChecked(false);
					radio03.setChecked(false);
					radio04.setChecked(false);
					radio05.setChecked(false);
					intent.putExtra("category", "1");
				}	
			}
		});
        radio03.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio01.setChecked(false);
					radio02.setChecked(false);
					radio04.setChecked(false);
					radio05.setChecked(false);
					intent.putExtra("category", "2");
				}	
			}
		});
        radio04.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio01.setChecked(false);
					radio02.setChecked(false);
					radio03.setChecked(false);
					radio05.setChecked(false);
					intent.putExtra("category", "3");
				}	
			}
		});
        radio05.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio01.setChecked(false);
					radio02.setChecked(false);
					radio03.setChecked(false);
					radio04.setChecked(false);
					intent.putExtra("category", "4");
				}	
			}
		});
        ImageView memo_dialog_chara01 = (ImageView)view.findViewById(R.id.memo_dialog_chara01);
        memo_dialog_chara01.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara01.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				radio01.setChecked(true);
			}
		});
        ImageView memo_dialog_chara02 = (ImageView)view.findViewById(R.id.memo_dialog_chara02);
        memo_dialog_chara02.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara02.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				radio02.setChecked(true);
			}
		});
        
        ImageView memo_dialog_chara03 = (ImageView)view.findViewById(R.id.memo_dialog_chara03);
        memo_dialog_chara03.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara03.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				radio03.setChecked(true);
			}
		});
        
        ImageView memo_dialog_chara04 = (ImageView)view.findViewById(R.id.memo_dialog_chara04);
        memo_dialog_chara04.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara04.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				radio04.setChecked(true);
			}
		});
        ImageView memo_dialog_chara05 = (ImageView)view.findViewById(R.id.memo_dialog_chara05);
        memo_dialog_chara05.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        memo_dialog_chara05.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				radio05.setChecked(true);
			}
		});
        
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
			
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK)
				{
					if(type == 0)
					{
						MemoActivity.mbBackBtnActionStatus = false;
					}
					else
					{
						MemoEditActivity.mbBackanimalAddActionStatus = false;
					}
				}
				return false;
			}
		});
//        final RadioGroup  radioGroup = (RadioGroup)view.findViewById(R.id.radioGroup1);
        Button decisionBtn = (Button)view.findViewById(R.id.decisionBtn);
        decisionBtn.setTypeface(Util.setLightFont(mContext));
        decisionBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
//				switch(radioGroup.getCheckedRadioButtonId())
//				{
//					case  R.id.radio0: intent.putExtra("category", "0");break;
//					case  R.id.radio1: intent.putExtra("category", "1");break;
//					case  R.id.radio2: intent.putExtra("category", "2");break;
//					case  R.id.radio3: intent.putExtra("category", "3");break;
//					case  R.id.radio4: intent.putExtra("category", "4");break;
//				}
				if(intent.getStringExtra("category") == null)
				{
					intent.putExtra("category", "0");
				}
				//single click flag
				if(type == 0)
				{
					MemoActivity.mbBackBtnActionStatus = false;
				}
				else
				{
					MemoEditActivity.mbBackanimalAddActionStatus = false;
					((Activity)mContext).finish();
				}
				mContext.startActivity(intent);
				
				
				dialog.dismiss();
				
			}
		});
        
        dialog.setContentView(view);
        dialog.show();
	}
	public String showCategoryDialog(final String memoId, int screenWidth,int screenHeight,DisplayMetrics dm)
	{
		
		dialog = new Dialog(mContext,R.style.AlertDialog);
//		final Intent shortcutIntent = new Intent(mContext, SCConfimActivity.class);
//		final MemoSharedPreferences shortcutShared = new MemoSharedPreferences(mContext); 
        LayoutInflater inflater=(LayoutInflater)mContext.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);  
        inflater =  dialog.getLayoutInflater();
        View view = inflater.inflate(R.layout.memo_category, null); 
        ImageView memo_dialog_chara01 = (ImageView)view.findViewById(R.id.memo_dialog_chara01);
        memo_dialog_chara01.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        ImageView memo_dialog_chara02 = (ImageView)view.findViewById(R.id.memo_dialog_chara02);
        memo_dialog_chara02.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        ImageView memo_dialog_chara03 = (ImageView)view.findViewById(R.id.memo_dialog_chara03);
        memo_dialog_chara03.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        ImageView memo_dialog_chara04 = (ImageView)view.findViewById(R.id.memo_dialog_chara04);
        memo_dialog_chara04.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        ImageView memo_dialog_chara05 = (ImageView)view.findViewById(R.id.memo_dialog_chara05);
        memo_dialog_chara05.setLayoutParams(Util.getLinearLayoutPararm(80, 120, dm));
        final RadioButton radio01 = (RadioButton)view.findViewById(R.id.radio0);
        final RadioButton radio02 = (RadioButton)view.findViewById(R.id.radio1);
        final RadioButton radio03 = (RadioButton)view.findViewById(R.id.radio2);
        final RadioButton radio04 = (RadioButton)view.findViewById(R.id.radio3);
        final RadioButton radio05 = (RadioButton)view.findViewById(R.id.radio4);
        categoryStr = "0";
        radio01.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio02.setChecked(false);
					radio03.setChecked(false);
					radio04.setChecked(false);
					radio05.setChecked(false);
					categoryStr = "0";
				}	
			}
		});
        radio02.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio01.setChecked(false);
					radio03.setChecked(false);
					radio04.setChecked(false);
					radio05.setChecked(false);
					categoryStr = "1";
				}	
			}
		});
        radio03.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio01.setChecked(false);
					radio02.setChecked(false);
					radio04.setChecked(false);
					radio05.setChecked(false);
					categoryStr = "2";
				}	
			}
		});
        radio04.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio01.setChecked(false);
					radio02.setChecked(false);
					radio03.setChecked(false);
					radio05.setChecked(false);
					categoryStr = "3";
				}	
			}
		});
        radio05.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked)
				{
					radio01.setChecked(false);
					radio02.setChecked(false);
					radio03.setChecked(false);
					radio04.setChecked(false);
					categoryStr = "4";
				}	
			}
		});
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
			
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK)
				{
					MemoEditActivity.mbBackanimalChooseActionStatus = false;
				}
				return false;
			}
		});
        
//        final RadioGroup  radioGroup = (RadioGroup)view.findViewById(R.id.radioGroup1);
        Button decisionBtn = (Button)view.findViewById(R.id.decisionBtn);
        decisionBtn.setTypeface(Util.setLightFont(mContext));
        decisionBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
//				switch(radioGroup.getCheckedRadioButtonId())
//				{
//					case  R.id.radio0: 
//						categoryStr = "0";
////						intent.putExtra("category", "0");
//					break;
//					case  R.id.radio1: 
//						categoryStr = "1";
////						intent.putExtra("category", "1");
//					break;
//					case  R.id.radio2: 
//						categoryStr = "2";
////						intent.putExtra("category", "2");
//					break;
//					case  R.id.radio3: 
//						categoryStr = "3";
////						intent.putExtra("category", "3");
//					break;
//					case  R.id.radio4: 
//						categoryStr = "4";
////						intent.putExtra("category", "4");
//					break;
//				}
//				intent.putExtra("memoId", memoId);
//				intent.putExtra("isCategoryChange", "TRUE");
				
				MemoEditActivity.mbBackanimalChooseActionStatus = false;
				//((Activity)mContext).finish();
				//mContext.startActivity(intent);
				dialog.dismiss();
			}
		});
        dialog.setContentView(view);
        dialog.show();
        return categoryStr;
	}
	
	
	
}
