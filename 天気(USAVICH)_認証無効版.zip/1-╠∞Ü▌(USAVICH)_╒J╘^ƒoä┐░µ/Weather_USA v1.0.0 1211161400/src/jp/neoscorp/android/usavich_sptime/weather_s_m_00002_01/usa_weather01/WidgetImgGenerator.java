package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01;

import java.io.InputStream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.Bitmap.Config;
import android.graphics.Paint.Align;

public class WidgetImgGenerator {
	
	private static WidgetImgGenerator INSTANCE;

	private Paint mPaint;

	private Context mContext;

	public static WidgetImgGenerator getInstance(Context context) {
		if (INSTANCE == null) {
			INSTANCE = new WidgetImgGenerator(context);
		}
		return INSTANCE;
	}

	private WidgetImgGenerator(Context context) {
		mContext = context;
		Typeface btry = Typeface.createFromAsset(mContext.getAssets(),
				"fonts/weather_A-OTF-ShinMGoPro-Medium.otf");
		mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
//		mPaint.setSubpixelText(true);
		mPaint.setTypeface(btry);
		mPaint.setTextAlign(Align.RIGHT);
	}

	public Bitmap getBitmapDraw(Bitmap today, String max, String min, String pop) {
		InputStream is = mContext.getResources().openRawResource(
				R.drawable.img_bg_widget_bg);
		Bitmap bg = BitmapFactory.decodeStream(is).copy(Config.ARGB_8888, true);
		
		Canvas canvas = new Canvas(bg);
		canvas.drawBitmap(today, 40, 95, null);
		today.recycle();
		
		int symOffsetX = -2;

		mPaint.setColor(0xFFf06418);
		mPaint.setTextSize(22);
		canvas.drawText(max, 155, 95, mPaint);
		mPaint.setTextSize(17);
		if (max.equals("-")) {
			symOffsetX = -2;
		}
//		canvas.drawText("℃", 162 + mPaint.measureText(max) - symOffsetX, 120, mPaint);
		canvas.drawText("℃", 170 - symOffsetX, 95, mPaint);
		
		mPaint.setColor(0xFF21a3ed);
		mPaint.setTextSize(22);
		canvas.drawText(min, 155, 128, mPaint);
		mPaint.setTextSize(17);
		if (min.equals("-")) {
			symOffsetX = -2;
		}
//		canvas.drawText("℃", 162 + mPaint.measureText(min) - symOffsetX, 143, mPaint);
		canvas.drawText("℃", 170 - symOffsetX, 128, mPaint);
		
		mPaint.setColor(0xFFffffff);
		mPaint.setTextSize(22);
//		canvas.drawText("0", 162, 166, mPaint);
		canvas.drawText(pop, 155, 163, mPaint);
		mPaint.setTextSize(17);
		if (pop.equals("-")) {
			symOffsetX = -2;
		}
//		canvas.drawText("%", 162 + mPaint.measureText(pop) - symOffsetX, 166, mPaint);
		canvas.drawText("%", 170 - symOffsetX, 163, mPaint);
		
		return bg;
	}
}