package jp.primeworks.android.flamingo.util;


import android.content.Context;
import android.content.SharedPreferences;


/**
 * Flamingo用プリファレンスクラス
 *
 */
public class FlamingoSharedPreferences {

	/**
	 * 自クラスのインスタンス
	 */
	private static FlamingoSharedPreferences mFlamingoSharedPreferences = null;

	/**
	 * 利用権利情報のプリファレンス名
	 */
	public static final String PREF_FLAMINGO = "pref_flamingo";

	/**
	 * プリファレンスデータ - 認証結果のキー
	 */
	public static final String KEY_VALID_APPLICATION_FLAG = "key_valid_application_flag";

	/**
	 * プリファレンスデータ - 期限日時のキー
	 */
	public static final String KEY_VALIDATE_DATE = "key_validate_date";

	/**
	 * プリファレンスデータ - 期限超過後猶予日数のキー
	 */
	public static final String KEY_GRACE_DAYS = "key_grace_days";

	/**
	 * プリファレンスデータ - ユーザ認証時のUUIDのキー
	 */
	public static final String KEY_UUID = "key_uuid";

	/**
	 * プリファレンスデータ - 初回ユーザ認証完了済みフラグ
	 */
	public static final String KEY_AUTHORIZE_COMPLETE = "key_authorize_complete";


	/**
	 * コンストラクタ（プライベート）
	 * <p>
	 * 本クラスの単純生成は禁止する.<BR>
	 * getInstance()メソッドでシングルトンなインスタンスを取得すること.
	 */
	private FlamingoSharedPreferences() {

		// do nothing.
	}


	/**
	 * Flamingo用プリファレンスクラスのインスタンスを生成して取得する.
	 *
	 * @return クラスのインスタンス
	 */
	public static synchronized FlamingoSharedPreferences getInstance() {

		if (mFlamingoSharedPreferences == null) {
			mFlamingoSharedPreferences = new FlamingoSharedPreferences();
		}
		return mFlamingoSharedPreferences;
	}


	/**
	 * Flamingoが扱うすべてのプリファレンスデータを削除する.
	 * <p>
	 * ・認証結果<BR>
	 * ・期限日時<BR>
	 * ・期限超過後猶予日数<BR>
	 * ・認証時のUUID<BR>
	 *
	 * @param context
	 *            コンテキスト
	 */
	public void removeAll(Context context) {

		Logging.d("removeAll() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.remove(KEY_VALID_APPLICATION_FLAG);
		editor.remove(KEY_VALIDATE_DATE);
		editor.remove(KEY_GRACE_DAYS);
		editor.remove(KEY_UUID);
		editor.commit();

	}


	/**
	 * プリファレンスデータ - 認証結果 を取得する.
	 *
	 * @param context
	 *            コンテキスト
	 * @return 認証結果 利用権利があるときtrueを返答する.
	 */
	public boolean getValidApplicationFlag(Context context) {

		Logging.d("getValidApplicationFlag() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		return pref.getBoolean(KEY_VALID_APPLICATION_FLAG, false);
	}


	/**
	 * プリファレンスデータ - 認証結果 を設定する.
	 *
	 * @param context
	 *            コンテキスト
	 * @param hasLicense
	 *            認証結果 利用権利があるときtrue.
	 */
	public void setValidApplicationFlag(Context context, boolean hasLicense) {

		Logging.d("setValidApplicationFlag() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.putBoolean(KEY_VALID_APPLICATION_FLAG, hasLicense);
		editor.commit();
	}


	/**
	 * プリファレンスデータ - 認証結果 を消去する.
	 *
	 * @param context
	 *            コンテキスト
	 */
	public void removeValidApplicationFlag(Context context) {

		Logging.d("removeValidApplicationFlag() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.remove(KEY_VALID_APPLICATION_FLAG);
		editor.commit();
	}


	/**
	 * プリファレンスデータ - 期限日時 を取得する.
	 *
	 * @param context
	 *            コンテキスト
	 * @return 期限日時
	 */
	public String getValidateDate(Context context) {

		Logging.d("getValidateDate() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		return pref.getString(KEY_VALIDATE_DATE, "");
	}


	/**
	 * プリファレンスデータ - 期限日時 を設定する.
	 *
	 * @param context
	 *            コンテキスト
	 * @param date
	 *            期限日時
	 */
	public void setValidateDate(Context context, String date) {

		Logging.d("setValidateDate() called");
		if (date == null) {
			removeValidateDate(context);
			return;
		}
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.putString(KEY_VALIDATE_DATE, date);
		editor.commit();
	}


	/**
	 * プリファレンスデータ - 期限日時 を消去する.
	 *
	 * @param context
	 *            コンテキスト
	 */
	public void removeValidateDate(Context context) {

		Logging.d("removeValidateDate() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.remove(KEY_VALIDATE_DATE);
		editor.commit();
	}


	/**
	 * プリファレンスデータ - 期限超過後猶予日数 を取得する.
	 *
	 * @param context
	 *            コンテキスト
	 * @return 期限超過後猶予日数
	 */
	public String getGraceDays(Context context) {

		Logging.d("getGraceDays() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		return pref.getString(KEY_GRACE_DAYS, "");
	}


	/**
	 * プリファレンスデータ - 期限超過後猶予日数 を設定する.
	 *
	 * @param context
	 *            コンテキスト
	 * @param days
	 *            期限超過後猶予日数
	 */
	public void setGraceDays(Context context, String days) {

		Logging.d("setGraceDays() called");
		if (days == null) {
			removeGraceDays(context);
			return;
		}
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.putString(KEY_GRACE_DAYS, days);
		editor.commit();
	}


	/**
	 * プリファレンスデータ - 期限超過後猶予日数 を消去する.
	 *
	 * @param context
	 *            コンテキスト
	 */
	public void removeGraceDays(Context context) {

		Logging.d("removeGraceDays() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.remove(KEY_GRACE_DAYS);
		editor.commit();
	}


	/**
	 * プリファレンスデータ - ユーザ認証時のUUID を取得する.
	 *
	 * @param context
	 *            コンテキスト
	 * @return ユーザ認証時のUUID
	 */
	public String getUuid(Context context) {

		Logging.d("getUuid() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		return pref.getString(KEY_UUID, "");
	}


	/**
	 * プリファレンスデータ - ユーザ認証時のUUID を設定する.
	 *
	 * @param context
	 *            コンテキスト
	 * @param uuid
	 *            ユーザ認証時のUUID
	 */
	public void setUuid(Context context, String uuid) {

		Logging.d("setUuid() called");
		if (uuid == null) {
			removeUuid(context);
			return;
		}
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.putString(KEY_UUID, uuid);
		editor.commit();
	}


	/**
	 * プリファレンスデータ - ユーザ認証時のUUID を消去する.
	 *
	 * @param context
	 *            コンテキスト
	 */
	public void removeUuid(Context context) {

		Logging.d("removeUuid() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.remove(KEY_UUID);
		editor.commit();
	}


	/**
	 * プリファレンスデータ - 初回ユーザ認証完了済みフラグ を取得する.
	 *
	 * @param context
	 *            コンテキスト
	 * @return  初回ユーザ認証完了済みの場合trueを返答する.
	 */
	public boolean getAuthorizeComplete(Context context) {

		Logging.d("getAuthorizeComplete() called");
		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		return pref.getBoolean(KEY_AUTHORIZE_COMPLETE, false);
	}


	/**
	 * プリファレンスデータ - 初回ユーザ認証完了済みフラグ を設定する.
	 *
	 * @param context
	 *            コンテキスト
	 * @param flag
	 *            初回ユーザ認証完了済みの場合trueを設定する
	 */
	public void setAuthorizeComplete(Context context, boolean flag) {

		Logging.d("setAuthorizeComplete() called");

		SharedPreferences pref = context.getSharedPreferences(PREF_FLAMINGO, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();
		editor.putBoolean(KEY_AUTHORIZE_COMPLETE, flag);
		editor.commit();
	}
}
