package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.wviews;

import java.util.ArrayList;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Date;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Weather;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class WeekView extends LinearLayout {
	public static int WEEK_COUNT = 6;

	private final LayoutParams PARAMS = new LayoutParams(0,
			LayoutParams.WRAP_CONTENT, 1.0f);

	private ArrayList<WeekDayView> mWeekDayViews;

	public WeekView(Context context, AttributeSet attrs) {
		super(context, attrs);
		mWeekDayViews = new ArrayList<WeekDayView>();
		for (int i = 0; i < WEEK_COUNT; i++) {
			WeekDayView weekDayView = new WeekDayView(context);
			weekDayView.setLayoutParams(PARAMS);
			addView(weekDayView);
			mWeekDayViews.add(weekDayView);
		}
	}

	public void setWeather(ArrayList<Weather> weaList, ArrayList<Date> datList) {
		// ensure list size, +1 for list calculate from day 1 not TODAY 0
		ArrayList<Weather> weaList1 = weaList;
		ArrayList<Date> datList1 = datList;
		if (weaList1.size() > WEEK_COUNT + 1 || weaList1.size() <= 0
				|| datList1.size() > WEEK_COUNT + 1 || datList1.size() <= 0) {
//			Log.e("",
//					"WeatherList & DateList size EORROR! Weather="
//							+ weaList1.size() + ", Date=" + datList1.size());
			return;
		} else {
			for (int i = 0; i < WEEK_COUNT; i++) {

				/*
				 * Date date = null; try { date = (Date)datList1.get(i + 1); }
				 * catch (Exception e) {
				 * 
				 * //e.printStackTrace(); System.out.println("date=" +
				 * datList1.size() + ", i=" + i); } Weather weather = null; try
				 * { weather = weaList1.get(i + 1); } catch (Exception e) {
				 * //e.printStackTrace(); System.out.println("weather=" +
				 * weaList1.size() + ", i=" + i); }
				 */

				try {
					mWeekDayViews.get(i).setWeekWeather(weaList1.get(i + 1),
							datList1.get(i + 1));
				} catch (Exception e) {
//					Log.e("WeekView.setWeek",
//							"ERROR - datList1=" + datList1.size() + ", i=" + i);
					// e.printStackTrace();
				}
			}
		}
	}
}