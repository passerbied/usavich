package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.City;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Date;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object.Weather;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.sql.DatabaseAdapter;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.widget.WeatherWidget;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.xml.CityXmlParser;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.xml.IconXmlParser;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.xml.WeatherXmlParser;

import org.xml.sax.SAXException;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
//import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

public class Utils {
	/**  */
	public static final String ACTION_UPDATESERVICE = "jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.ACTION_UPDATESERVICE";;
	/**  */
	public static final String ACTION_DATA_RECEIVED = "jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.ACTION_DATA_RECEIVED";
	/**  */
	public static final String ACTION_TIMER_BROADCAST = "jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.ACTION_TIMER_BROADCAST";
	/**  */
	public static final String ACTION_NET_CONN_CHANGE = "android.net.conn.CONNECTIVITY_CHANGE";
	/**  */
	public static final String STATUS = "update-status";
	/**  */
	public static final String UPDATE_COUNT = "update-count";
	/**  */
	public static final String WEATHER = "pref-weather";
	/**  */
	public static final String CONN_CODE = "connection-status";
	/**  */
	private static final String UPDATE_RATE_VALUE = "update-rate-value";
	/**  */
	public static final String NEED_TO_REFRESH = "need-to-refresh";
	/**  */
	public static final long CONN_FAIL_TIME_OUT = 5000;
	/**  */
	public static final int CODE_SUCCESS = 0;
	/**  */
	public static final int CODE_CONN_ERROR = 1;
	/**  */
	public static final String SETTING_CHANGED = "setting_changed";
	/**  */
	public static final String SETTING_FINISH = "directly_finnish";
	/**  */
	public static ArrayList<Weather> mWeatherList = new ArrayList<Weather>();
	/**  */
	public static City mCurrCity;
	/**  */
	public static ArrayList<City> mCities;
	/**  */
	private static HashMap<Integer, String> mWeatherInfoMap = null;
	/**  */
	private static ArrayList<Date> mDateList = new ArrayList<Date>();
	/**  */
	private static int mUpdateCount = 0;
	/**  */
	private static long mUpdateRate = -1;
	/**  */
	private static boolean mFirstTime = true;
	/**  */
	private static Toast mToast;
	/**  */
	private static DatabaseAdapter mDb;
	
	public static boolean sCanAuto = false;
	
	public static final int PENDING_FLAMINGO_TIMING = 1001;
	
	public static final long AUTHORIZE_RATE = 6 * 60 * 60 * 1000;
	
	/** Is WeatherActivity alive, controlled for "更新完了" Toast popup */
	public static boolean sActivityAlive = false;

	public static void startService(Context context) {
		context.startService(new Intent(ACTION_UPDATESERVICE));
	}

	public static void stopService(Context context) {
		context.stopService(new Intent(ACTION_UPDATESERVICE));
	}

	public static boolean isFirst() {
		return mFirstTime;
	}

	public static boolean needUpdate(Context context) {
		getInfosFromDB(context);
		Weather weather = mWeatherList.get(0);
		if (weather.isNull() && mUpdateRate > 0) {
			return true;
		} else {
			return false;
		}
	}

	public static int getUpdateCount() {
		return mUpdateCount;
	}

	public static void setUpdateCount(Context context, int count) {
		mUpdateCount = count;
		SharedPreferences.Editor editor = context.getSharedPreferences(WEATHER,
				Context.MODE_PRIVATE).edit();
		editor.putInt(UPDATE_COUNT, count);
		editor.commit();
	}

	public static void initInfos(Context context) {
		resetLists(null);

		SharedPreferences sp = context.getSharedPreferences(WEATHER,
				Context.MODE_PRIVATE);
		IconXmlParser icParser = new IconXmlParser(context);
		mWeatherInfoMap = icParser.getWeatherMap();
		CityXmlParser ctParser = new CityXmlParser(context);
		mCities = ctParser.getCities();

		mUpdateCount = sp.getInt(UPDATE_COUNT, 0);

		mCurrCity = new City(sp.getInt(City.ID, 11), sp.getString(City.NAME,
				"東京"), sp.getString(City.CODE, "47662"), sp.getInt(City.AREA, 1));

		mUpdateRate = sp.getLong(UPDATE_RATE_VALUE, 3 * 60 * 60 * 1000);

		openDB(context);
		getInfosFromDB(context);

		mFirstTime = false;
	}

	public static void getInfosFromDB(Context context) {
		if (mWeatherList != null) {
			mWeatherList.clear();
		}
		if (mDateList != null) {
			mDateList.clear();
		}
		openDB(context);
		mCurrCity = getCity(context);
		Cursor cursor = mDb.getInfoByName(mCurrCity.getName());
		if (cursor != null) {
			while (cursor.moveToNext()) {
				mDateList.add(castToDate(cursor.getString(4)));
				mDateList.add(castToDate(cursor.getString(6)));
				mDateList.add(castToDate(cursor.getString(8)));
				mDateList.add(castToDate(cursor.getString(10)));
				mDateList.add(castToDate(cursor.getString(12)));
				mDateList.add(castToDate(cursor.getString(14)));
				mDateList.add(castToDate(cursor.getString(16)));
				mWeatherList.add(castToWeather(cursor.getString(5)));
				mWeatherList.add(castToWeather(cursor.getString(7)));
				mWeatherList.add(castToWeather(cursor.getString(9)));
				mWeatherList.add(castToWeather(cursor.getString(11)));
				mWeatherList.add(castToWeather(cursor.getString(13)));
				mWeatherList.add(castToWeather(cursor.getString(15)));
				mWeatherList.add(castToWeather(cursor.getString(17)));
			}
			cursor.close();
		}

		if (mWeatherList.size() <= 0 || mDateList.size() <= 0) {
			resetLists(null);
		}
	}

	public static void openDB(Context context) {
		if (mDb == null) {
			mDb = DatabaseAdapter.getInstance(context);
			mDb.open();
		}
	}

	public static void closeDB() {
		if (mDb != null) {
			mDb.close();
			mDb = null;
		}
	}

	private static Weather castToWeather(String colmn) {
		String[] weather = colmn.split("/");
		return new Weather(Integer.parseInt(weather[0]),
				Integer.parseInt(weather[1]), Integer.parseInt(weather[2]),
				Integer.parseInt(weather[3]));
	}

	private static Date castToDate(String colmn) {
		String[] date = colmn.split("/");
		return new Date(Integer.parseInt(date[0]), Integer.parseInt(date[1]),
				Integer.parseInt(date[2]), Integer.parseInt(date[3]));
	}
	
	public static int[] getWidgetIds(Context context) {
		AppWidgetManager manager = AppWidgetManager.getInstance(context);
		return manager.getAppWidgetIds(
				new ComponentName(context, WeatherWidget.class));
	}

	public static void saveLastInfo(Context context) {
		ArrayList<String> dateList = new ArrayList<String>();
		ArrayList<String> weatherList = new ArrayList<String>();
		for (int i = 0; i < 7; i++) {
			Date date = mDateList.get(i);
			String d = date.getYear() + "/" + date.getMonth() + "/"
					+ date.getDate() + "/" + date.getDay();
			dateList.add(d);

			Weather weather = mWeatherList.get(i);
			String w = weather.getWeatherId() + "/" + weather.getMax() + "/"
					+ +weather.getMin() + "/" + weather.getPop();
			weatherList.add(w);
		}
		openDB(context);
		mCurrCity = getCity(context);
		mDb.updateWeather(mCurrCity, dateList, weatherList);
	}

	public static void resetLists(Calendar calendar) {
		mDateList.clear();
		mWeatherList.clear();
		if (calendar == null) {
			calendar = Calendar.getInstance();
		}
		for (int i = 0; i < 7; i++) {
			if (i > 0) {
				calendar.add(Calendar.DATE, 1);
			}
			Date date = new Date(calendar.get(Calendar.YEAR),
					calendar.get(Calendar.MONTH) + 1,
					calendar.get(Calendar.DATE),
					calendar.get(Calendar.DAY_OF_WEEK) - 1);
			mDateList.add(date);
			Weather weather = new Weather();
			mWeatherList.add(weather);
		}
		calendar.clear();
	}

	public static ArrayList<City> getAllCities() {
		return mCities;
	}

	public static void setUpdateRate(Context context, long millis) {
		mUpdateRate = millis;
		SharedPreferences.Editor editor = context.getSharedPreferences(WEATHER,
				Context.MODE_PRIVATE).edit();
		editor.putLong(UPDATE_RATE_VALUE, mUpdateRate);
		editor.commit();
	}

	public static long getUpdateRate() {
		return mUpdateRate;
	}

	public static void setCity(Context context, City currCity) {
		mCurrCity = currCity;
		SharedPreferences.Editor editor = context.getSharedPreferences(WEATHER,
				Context.MODE_PRIVATE).edit();
		editor.putInt(City.ID, mCurrCity.getId());
		editor.putString(City.NAME, mCurrCity.getName());
		editor.putString(City.CODE, mCurrCity.getCode());
		editor.putInt(City.AREA, mCurrCity.getArea());
		editor.commit();
	}

	public static City getCity(Context context) {
		SharedPreferences sp = context.getSharedPreferences(WEATHER,
				Context.MODE_PRIVATE);
		if (mCurrCity == null) {
			mCurrCity = new City(sp.getInt(City.ID, 11), sp.getString(
					City.NAME, "東京"), sp.getString(City.CODE, "TOK"),
					sp.getInt(City.AREA, 1));
		}
		return mCurrCity;
	}

	public static ArrayList<Weather> getWeatherList() {
		return mWeatherList;
	}

	public static ArrayList<Date> getDateList() {
		if (mDateList.size() == 0) {
			resetLists(Calendar.getInstance());
		}
		return mDateList;
	}

	public static Bitmap getTinyWeatherById(Context context, int id) {
		String path = (id == -1 ? "def_img_tiny" : ("image/ic_tiny/"
				+ "icon_s_" + mWeatherInfoMap.get(id).split(":")[1] + ".png"));

		return getBitmapFromAsset(context, path);
	}

	public static int getComponentId(Context context, int id) {
		if (id == -1) {
			return -1;
		} else {
			return Integer.valueOf(mWeatherInfoMap.get(id).split(":")[1]);
		}
	}

	public static String getBGWeatherById(Context context, int id) {
		if (mWeatherInfoMap == null) {
			IconXmlParser icParser = new IconXmlParser(context);
			mWeatherInfoMap = icParser.getWeatherMap();
		}
		String name = (id == -1 ? "def_img_bg.png" : mWeatherInfoMap.get(id)
				.split(":")[0]);
		if (name.startsWith("晴れ")) {
			return Weather.SUNNY;
		} else if (name.startsWith("くもり")) {
			return Weather.CLOUDY;
		} else if (name.startsWith("雨")) {
			return Weather.RAINY;
		} else if (name.startsWith("雪")) {
			return Weather.SNOWY;
		} else {
			return "";
		}
	}

	private static Bitmap getBitmapFromAsset(Context context, String path) {
		InputStream is = null;
		Resources res = context.getResources();
		if (path == "def_img_tiny" || path == "def_img_bg") {
			is = res.openRawResource(R.drawable.weather_def);
		} else {
			try {
				is = res.getAssets().open(path);
			} catch (IOException e) {
//				Log.e("GetWeatherImg", "Weather img not found: " + path);
			}
		}
		Bitmap ret = null;
		if (is != null) {
			ret = BitmapFactory.decodeStream(is).copy(
					Bitmap.Config.ARGB_8888, true);;
			try {
				is.close();
			} catch (IOException e) {
//				Log.d("getBitmapFromAsset", "Stream closed...");
			}
		}
		return ret;
	}

	public static String getDayCast(int day) {
		switch (day) {
		case 0:
			return "日";
		case 1:
			return "月";
		case 2:
			return "火";
		case 3:
			return "水";
		case 4:
			return "木";
		case 5:
			return "金";
		case 6:
			return "土";
		default:
			return "-";
		}
	}

	public static void parseWeatherXml(InputStream is)
			throws ParserConfigurationException, SAXException, IOException {
		WeatherXmlParser parser = new WeatherXmlParser();
		parser.parseStream(is);
		mWeatherList = parser.getWeathers();
		mDateList = parser.getDates();
	}

	public static void showToast(Context context, String content) {
		if (mToast == null) {
			mToast = Toast.makeText(context, "", Toast.LENGTH_SHORT);
		}
		mToast.setText(content);
		mToast.show();
	}
	
	// fix //
	public static void updateWidget(final Context context) {
		Weather currWeather = mWeatherList.get(0);
		RemoteViews views = new RemoteViews(context.getPackageName(),
				R.layout.widget);
		Intent intent = new Intent(context, WeatherActivity.class);
		PendingIntent pending = PendingIntent
				.getActivity(context, 0, intent, 0);
		views.setOnClickPendingIntent(R.id.root_widget_root, pending);

		int max = currWeather.getMax();
		String maxTmp = (max == -500 ? "-" :String.valueOf(max));
		int min = currWeather.getMin();
		String minTmp =  (min == -500 ? "-" : String.valueOf(min));
		int pop = currWeather.getPop();
		String popR = (pop == -1 ? "-" : String.valueOf(pop));
		
		Bitmap img_tiny = Utils.getTinyWeatherById(context,
				currWeather.getWeatherId());
		
		WidgetImgGenerator generator = WidgetImgGenerator.getInstance(context);
		Bitmap bmp = generator.getBitmapDraw(img_tiny, maxTmp, minTmp, popR);
//		Bitmap bmp = generator.getBitmapDraw(img_tiny, "-50", "-50", "-50");
		views.setImageViewBitmap(R.id.iv_widget_content, bmp);
		
		ComponentName thisWidget = new ComponentName(context,
				WeatherWidget.class);
		AppWidgetManager manager = AppWidgetManager.getInstance(context);
		int[] widgetIds = manager.getAppWidgetIds(thisWidget);

		manager.updateAppWidget(widgetIds, views);
	}
	
	public static String logBool(boolean b) {
		return b == true ? "TRUE" : "FALSE";
	}

	public static void setScreen(Context context, int screenWidth,
			int screenHeight) {
		SharedPreferences.Editor editor = context.getSharedPreferences(WEATHER,
				Context.MODE_PRIVATE).edit();
		editor.putInt("screen-width", screenWidth);
		editor.putInt("screen-height", screenHeight);
		editor.commit();
	}

	public static int[] getScreen(Context context) {
		SharedPreferences sp = context.getSharedPreferences(WEATHER,
				Context.MODE_PRIVATE);
		int[] screen = new int[2];
		screen[0] = sp.getInt("screen-width", 480);
		screen[1] = sp.getInt("screen-height", 854);
		return screen;
	}

	public static int px2dip(Context context, float px) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (px / scale + 0.5f);
	}

	public static int dip2px(Context context, float dip) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dip / scale + 0.5f);
	}

	public static Typeface getTodayType(Context context) {
		return Typeface.createFromAsset(context.getResources().getAssets(),
				"fonts/weather_A-OTF-ShinMGoPro-Medium.otf");
	}

	public static Typeface getWeekType(Context context) {
		return Typeface.createFromAsset(context.getResources().getAssets(),
				"fonts/weather_A-OTF-ShinMGoPro-Light.otf");
	}

	public static void checkDateMatched(Context context) {
		Calendar calendar = Calendar.getInstance();

		Date today = new Date(calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DATE),
				calendar.get(Calendar.DAY_OF_WEEK) - 1);

		boolean needReset = false;
		int index = 0;
		for (int i = 0; i < mDateList.size(); i++) {
			String dateString = mDateList.get(i).toString();
			if (dateString.equals(today.toString())) {
				index = i;
				needReset = true;
			}
		}
		if (needReset) {
			resetDbFromToday(index, calendar);
		} else {
			resetLists(calendar);
		}
		saveLastInfo(context);
	}

	private static void resetDbFromToday(int index, Calendar today) {
		ArrayList<Weather> weathers = new ArrayList<Weather>();
		ArrayList<Date> dates = new ArrayList<Date>();
		int count = mWeatherList.size();
		if (count != mDateList.size()) {
//			Log.e("Utils.resetDbFromToday", "Length NOT equal: " + "Wea="
//					+ count + "Dat=" + mDateList.size());
			return;
		}
		for (int i = 0; i < count; i++) {
			if (i + index < count) {
				weathers.add(mWeatherList.get(i + index));
				dates.add(mDateList.get(i + index));
				today.add(Calendar.DATE, 1);
			} else {
				dates.add(new Date(today.get(Calendar.YEAR), today
						.get(Calendar.MONTH) + 1, today.get(Calendar.DATE),
						today.get(Calendar.DAY_OF_WEEK) - 1));
				weathers.add(new Weather());
				today.add(Calendar.DATE, 1);
				// today.add(Calendar.DATE, index - i);
			}
		}
		today.clear();
		mWeatherList = weathers;
		mDateList = dates;
	}
}