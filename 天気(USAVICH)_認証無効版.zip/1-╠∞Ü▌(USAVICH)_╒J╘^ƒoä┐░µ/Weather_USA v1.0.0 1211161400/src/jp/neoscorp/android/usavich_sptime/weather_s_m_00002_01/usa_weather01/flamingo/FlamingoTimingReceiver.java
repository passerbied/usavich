package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.flamingo;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.Utils;
import jp.primeworks.android.flamingo.Flamingo;
import jp.primeworks.android.flamingo.FlamingoError;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class FlamingoTimingReceiver extends BroadcastReceiver {
	public static final String TAG = "FlamingoTimingReceiver";

	public static final String ACTION_FLAMINGO_TIMING = "jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.ACTION_FLAMINGO_TIMING";

	private static FlamingoTimingReceiver INSTANCE;

	private boolean mIsRegistered;

	private Context mContext;

	private FlamingoTimingReceiver(Context context) {
		mContext = context;
	}

	public static FlamingoTimingReceiver getInstance(Context context) {
		if (INSTANCE == null) {
			INSTANCE = new FlamingoTimingReceiver(context);
		}
		return INSTANCE;
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		Flamingo flamingo = new Flamingo(context.getApplicationContext());
		if (!flamingo.isValidApplication()) {
			flamingo.authorize(false, new Flamingo.OnAuthorizeListner() {
				@Override
				public void onComplete(boolean authorizeOk) {
					 Utils.startService(mContext);
				}

				@Override
				public void onError(FlamingoError error) {
					Utils.startService(mContext);
				}

				@Override
				public void onCancel() {
					Utils.startService(mContext);
				}
			});
		} else {
			// Here is to do SAVE LOG TO SDCARD.
		}
	}

	public void register() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(ACTION_FLAMINGO_TIMING);
		mContext.registerReceiver(INSTANCE, filter);
		mIsRegistered = true;
	}

	public void unregister() {
		if (mIsRegistered) {
			mContext.unregisterReceiver(INSTANCE);
			mIsRegistered = false;
		}
	}

	public boolean isRegistered() {
		return mIsRegistered;
	}
}