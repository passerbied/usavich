package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.MemoApplication.Sort;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db.MemoDataBaseAdapter;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.utils.Util;
import jp.primeworks.android.flamingo.activity.FlamingoActivity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
public class MemoSettingActivity extends FlamingoActivity implements View.OnCreateContextMenuListener {
	private Button btn_sort;
	private	Button btn_password;
	private Dialog dialog;
	private Dialog sortDialog;
	private Dialog passwordDialog;
	private DialogInterface dialogBtn;
	private Button btn_back;
	private enum Password {CURRENT_PWD , NEW_PWD , NEW_PWD_AGAIN};
	private LinearLayout currentPwdLinear,newPwdLinear,newPwdAgainLinear;
	private Password pwd;
	private String[] sortStr = {"日付：新しいものから","日付：古いものから","内容：あ→ん","内容：ん→あ"};
	private MemoApplication memoApp;
	private SingleChoiceItemsOnClick singleClick;
	private int sortIndex;
	private EditText currentPwdEdit,newPwdEdit,newPwdEditAgain;
	private TextView memoSettingTitle;
	private ImageView memoSettingBg;
	private DisplayMetrics dm;
	private SharedPreferences sp;
	private static final String SETTING_SORT = "setting_SORT"; 
	  @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.memo_setting);
	        memoApp = (MemoApplication)this.getApplication();
	        
	        singleClick = new SingleChoiceItemsOnClick();
	        dm = new DisplayMetrics();
	        getWindowManager().getDefaultDisplay().getMetrics(dm);
	        memoSettingTitle = (TextView)findViewById(R.id.memoSettingTitle);
	        memoSettingTitle.setTypeface(Util.setMediumFont(this));
	        btn_back = (Button)findViewById(R.id.backBtn);
	        memoSettingBg = (ImageView)findViewById(R.id.settingBg);
	        memoSettingBg.setLayoutParams(Util.getLinearLayoutPararm(480, 854, dm));
	        LinearLayout sortLinear = (LinearLayout)findViewById(R.id.sortLinear);
	        sortLinear.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					sortDialog = createSortDialog();
					sortDialog.show();
				}
			});
	        LinearLayout passwordLinear = (LinearLayout)findViewById(R.id.passwordLinear);
	        passwordLinear.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					createPasswordDialog();
				}
			});
	        btn_back.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					MemoSettingActivity.this.finish();
				}
			});
	    }
	  
	  private Dialog createSortDialog(){
		  	Builder	builder = new android.app.AlertDialog.Builder(this);
	        builder.setIcon(null);
	        builder.setTitle("並び替え");
	        builder.setSingleChoiceItems(sortStr, Integer.parseInt(loadSettingSort()), singleClick);
	        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
	        {
	            public void onClick(DialogInterface dialog, int which) 
	            {
	            	dialog.dismiss();     	
	            }
	        });
	        builder.setNegativeButton("OK", new DialogInterface.OnClickListener()
	        {
	            public void onClick(DialogInterface dialog, int which) 
	            {
	            	switch(sortIndex)
	            	{
	            		case 0:memoApp.setSortName(Sort.DATE_DESCENDING);break;
	            		case 1:memoApp.setSortName(Sort.DATE_ASCENDING);break;
	            		case 2:memoApp.setSortName(Sort.CONTENT_ASCENDING);break;
	            		case 3:memoApp.setSortName(Sort.CONTENT_DESCENDING);break;
	            	}
	            	saveSettingSort(String.valueOf(sortIndex));
	            	dialog.dismiss();
	            }
	        });
	        
	        dialog = builder.create();
	        
	        return dialog;
	    }
	  private void createPasswordDialog(){
		  	AlertDialog dialog = null;
	    	final Builder builder = new android.app.AlertDialog.Builder(this);
	    	builder.setIcon(null);
	        builder.setTitle("パスワード");
	       
	        builder.setOnKeyListener(new DialogInterface.OnKeyListener() {
				
				@Override
				public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
					if (keyCode == KeyEvent.KEYCODE_BACK)
				    {
						Field field;
						try {
							if(dialogBtn != null)
							{
								field = dialogBtn.getClass().getSuperclass().getDeclaredField("mShowing");
								field.setAccessible(true);  
			                    field.set(dialogBtn, true); 
			                    dialogBtn.dismiss();
							}
						} catch (SecurityException e) {
							e.printStackTrace();
						} catch (NoSuchFieldException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						}  
				    }
					return false;
				}
			});
	        LayoutInflater inflater=(LayoutInflater)getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);  
	        View view = inflater.inflate(R.layout.memo_password, null); 
	        currentPwdLinear = (LinearLayout)view.findViewById(R.id.currentPwdLinear);
	        newPwdLinear = (LinearLayout)view.findViewById(R.id.newPwdLinear);
	        newPwdAgainLinear = (LinearLayout)view.findViewById(R.id.newPwdAgainLinear);
	        currentPwdEdit = (EditText)view.findViewById(R.id.current_password);
	        newPwdEdit = (EditText)view.findViewById(R.id.new_password);
	        newPwdEditAgain = (EditText)view.findViewById(R.id.new_passwrd_again);
	        pwd = Password.CURRENT_PWD;
	        
	        
	        builder.setPositiveButton("キャンセル", new DialogInterface.OnClickListener()
	        {
	            public void onClick(DialogInterface dialog, int which) 
	            {
	            	try{  dialogBtn = dialog;
	                      Field field = dialogBtn.getClass().getSuperclass().getDeclaredField("mShowing");  
	                      field.setAccessible(true);  
	                      field.set(dialogBtn, true);  
	                      dialogBtn.dismiss();   
	            	}catch(Exception e) {  
	                      e.printStackTrace();  
	                }  
	            }
	        });
	        
	        builder.setNegativeButton("次へ", new DialogInterface.OnClickListener()
	        {
	            public void onClick(DialogInterface dialog, int which) 
	            {
	            	try{  
	            		  TimerReceiver timerRecever  = new TimerReceiver(MemoSettingActivity.this,memoApp);
	            		  dialogBtn = dialog;
	                      Field field = dialogBtn.getClass().getSuperclass().getDeclaredField("mShowing");  
	                      field.setAccessible(true);  
	                      field.set(dialogBtn, false);  
	                  
	            	switch(pwd)
	            	{
	            		case CURRENT_PWD:
	            			
	            			if(memoApp.getMemoPassword() != null)
	            			{
	            				if(currentPwdEdit.getText().toString().equals(memoApp.getMemoPassword()))
	            				{
	            					pwd = Password.NEW_PWD;
	            					currentPwdLinear.setVisibility(View.GONE);
	    	            			newPwdLinear.setVisibility(View.VISIBLE);
	    	            			newPwdAgainLinear.setVisibility(View.GONE);
	            				}
	            				else
	            				{
	            					field.set(dialog, true);
	            					Util.WrongPassword(MemoSettingActivity.this,MemoSettingActivity.this.getResources().getString(R.string.wrong_password));
	            					dialog.dismiss();
	            				}
	            				
	            			}
	            			else
	            			{
	            				if(currentPwdEdit.getText().toString().equals(Util.DEFAULT_PASSWORD))
	            				{
	            					pwd = Password.NEW_PWD;
	            					currentPwdLinear.setVisibility(View.GONE);
	    	            			newPwdLinear.setVisibility(View.VISIBLE);
	    	            			newPwdAgainLinear.setVisibility(View.GONE);
	    	            			builder.setCancelable(true);
	            				}
	            				else
	            				{
	            					field.set(dialog, true);
	            					Util.WrongPassword(MemoSettingActivity.this,MemoSettingActivity.this.getResources().getString(R.string.wrong_password));
	            					dialog.dismiss();
	            				}
	            			}
	            		break;
	            		case NEW_PWD:
	            			
	            			if(newPwdEdit.getText() != null && newPwdEdit.getText().toString().trim().length() == 4)
	            			{
	            				currentPwdLinear.setVisibility(View.GONE);
		            			newPwdLinear.setVisibility(View.GONE);
		            			newPwdAgainLinear.setVisibility(View.VISIBLE);
	            				pwd = Password.NEW_PWD_AGAIN;	
	            			}
	            		break;
	            		case NEW_PWD_AGAIN:
	            			
	            			if(newPwdEdit.getText().toString().equals(newPwdEditAgain.getText().toString()))
	            			{
	            				field.set(dialog, true);
	            				if(memoApp.getMemoPassword() != null)
	            				{
	            					updatePwd(newPwdEdit.getText().toString());
	            					memoApp.setMemoPassword(newPwdEdit.getText().toString());
	            				}
	            				else
	            				{
	            					insertPwd(newPwdEdit.getText().toString());
	            					memoApp.setMemoPassword(newPwdEdit.getText().toString());
	            				}
	            				if(memoApp != null)
	            				{
	            					if(memoApp.isStartReceiver())
	            					{
	            						sendBroadcast(new Intent(TimerReceiver.TIMER_STOP_ACTION));
//	    	            				sendBroadcast(new Intent(TimerReceiver.TIMER_START_ACTION));
	            						
	            					}
	            				}
	            				
	            				dialogBtn.dismiss();
	            			}
	            			else
	            			{
	            				field.set(dialog, true);
            					Util.WrongPassword(MemoSettingActivity.this,MemoSettingActivity.this.getResources().getString(R.string.inconsistent_password));
            					dialog.dismiss();
	            			}
	            		break;
	            	}
	            	}catch(Exception e) {  
	                      e.printStackTrace();  
	                }  
	            }
	        });
	        dialog =  builder.create();
	        dialog.setView(view,0,0,0,0);
	        dialog.show();
	    }
	  private class SingleChoiceItemsOnClick implements DialogInterface.OnClickListener
	  {

		@Override
		public void onClick(DialogInterface dialog, int which) {
			// TODO Auto-generated method stub
			sortIndex = which;
		}
		  
	  }
	  private void insertPwd(String password)
	  {
		  MemoDataBaseAdapter mda = new MemoDataBaseAdapter(this);
		  mda.open();
		  mda.insertPassword(password);
		  mda.close();
	  }
	  private void updatePwd(String password)
	  {
		  MemoDataBaseAdapter mda = new MemoDataBaseAdapter(this);
		  mda.open();
		  mda.updatePassword(password);
		  mda.close();
	  }
	  public String loadSettingSort()
	  {    	
	      	sp = getSharedPreferences(SETTING_SORT, 0);
	      	return sp.getString("settingsort", "0");
	  }
	  public void saveSettingSort(String sort) 
	  {
	  	SharedPreferences sp = getSharedPreferences(SETTING_SORT, 0);
	  	Editor editor = sp.edit();
	  	editor.putString("settingsort", sort);
	  	editor.commit();
	  }
	  
}
