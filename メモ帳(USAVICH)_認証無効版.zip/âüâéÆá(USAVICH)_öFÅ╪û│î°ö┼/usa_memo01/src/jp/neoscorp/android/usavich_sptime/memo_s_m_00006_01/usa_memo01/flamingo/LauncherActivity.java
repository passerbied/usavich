package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.flamingo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.MemoActivity;
import jp.primeworks.android.flamingo.Flamingo;
import jp.primeworks.android.flamingo.activity.FlamingoActivity;
import jp.primeworks.android.flamingo.activity.FlamingoFragmentActivity;

public class LauncherActivity extends FlamingoFragmentActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void onResume() {
		super.onResume();

//		Flamingo flamingo = new Flamingo(this);
//		if (!flamingo.isValidApplication() && !isAuthorizeError()) {
//			showDialog(FlamingoActivity.DIALOG_AUTHORIZE);
//		}

//		else if (flamingo.isValidApplication() || !isAuthorizeError()) {
			Intent resultValue = new Intent();
			resultValue.setClass(this, MemoActivity.class);
			startActivity(resultValue);
			finish();
//		}

	}
}
