package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class MemoDataBaseAdapter {
	private Context mContext = null;
	private SQLiteDatabase mSQLiteDatabase = null;
	private MemoDatabaseHelper mdbHelper = null;
	private final static String TABLE_NAME   = "memo_table";
	private final static String PASSWORD_TABLE_NAME   = "memo_password_table";
	private final static String SORT_TABLE_NAME = "memo_sort_table";
	public final static String MEMO_ID   = "memo_id";
	public final static String MEMO_TITLE   = "memo_title";
	public final static String MEMO_CONTENT   = "memo_content"; 
	public final static String MEMO_DATE   = "memo_date";
	public final static String MEMO_TYPE   = "memo_type";
	public final static String MEMO_PASSWORD_ID   = "memo_password_id"; 
	public final static String MEMO_PASSWORD   = "memo_password"; 
	public final static String MEMO_CLOCK_STATUS   = "memo_clock_status"; 
	public final static String MEMO_SORT_ID   = "memo_sort_id"; 
	public final static String MEMO_SORT_NAME   = "memo_sort_name";
	

	public MemoDataBaseAdapter(Context context)
	{
		mContext = context;
		mdbHelper = new MemoDatabaseHelper(mContext);
	}
	public void open(){
		
		mSQLiteDatabase = mdbHelper.getWritableDatabase();
	}
//	public void openPassword(){
//		mdbHelper = new MemoDatabaseHelper(mContext,DB_NAME,null,DB_VERSION_2,CREATE_PASSWORD_TABLE,PASSWORD_TABLE_NAME);
//		mSQLiteDatabase = mdbHelper.getWritableDatabase();
//	}
	
	public void close(){
		mdbHelper.close();
		mdbHelper = null;
		mSQLiteDatabase.close();
		mSQLiteDatabase = null;
		mContext = null;
	}
	public Cursor select(String sqlWhere)
	{
		try{
			String sql = "SELECT * FROM " + TABLE_NAME  + sqlWhere;
			return mSQLiteDatabase.rawQuery(sql, null);
		}catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	public Cursor selectById(String id)
	{
		try{
			String sql = "SELECT * FROM " + TABLE_NAME + " WHERE MEMO_ID = " + id;
			return mSQLiteDatabase.rawQuery(sql, null);
		}catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	public Cursor selectPassword()
	{
		try{
			String sql = "SELECT * FROM " + PASSWORD_TABLE_NAME ;
			return mSQLiteDatabase.rawQuery(sql, null);
		}catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	}
	public void insert(String title,String content, String date, String clockstatus, String type) 
	{
		try{
			ContentValues cv = new ContentValues();
			cv.put(MEMO_TITLE, title);
			cv.put(MEMO_CONTENT, content);
			cv.put(MEMO_DATE, date);
			cv.put(MEMO_TYPE, type);
			cv.put(MEMO_CLOCK_STATUS, clockstatus);
			mSQLiteDatabase.insert(TABLE_NAME, null, cv);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	public void insertPassword(String password) 
	{
		try{
			ContentValues cv = new ContentValues();
			cv.put(MEMO_PASSWORD, password);
			mSQLiteDatabase.insert(PASSWORD_TABLE_NAME, null, cv);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public void update( String memoid,String title,String content, String date, String clockstatus, String type) 
	{
		try{
			
		String[] args = {memoid};
		ContentValues cv = new ContentValues();
		cv.put(MEMO_TITLE, title);
		cv.put(MEMO_CONTENT, content);
		cv.put(MEMO_TYPE, type);
		cv.put(MEMO_CLOCK_STATUS, clockstatus);
		mSQLiteDatabase.update(TABLE_NAME, cv, MEMO_ID+"=?", args);
		
		}catch(Exception ex){
		ex.printStackTrace();
		}
	}
	public void updateClockstatus(String memoid, String clockstatus)
	{
		try{
			String sql = "UPDATE " + TABLE_NAME + " SET " + 
								MEMO_CLOCK_STATUS + " = '" + clockstatus + "' " +
								" WHERE " + MEMO_ID + " = '" + memoid +"'";
			
			mSQLiteDatabase.execSQL(sql);
			}catch(Exception ex){
			ex.printStackTrace();
			}
	}
	public void updatePassword(String password) 
	{
		try{
			
			ContentValues cv = new ContentValues();
			cv.put(MEMO_PASSWORD, password);
			 
			mSQLiteDatabase.update(PASSWORD_TABLE_NAME, cv, null, null);
			}catch(Exception ex){
			ex.printStackTrace();
			}
	}
	public void deleteById(String id)
	{
		try{
			String sql = "DELETE  FROM " + TABLE_NAME + " WHERE MEMO_ID = " + id;
			mSQLiteDatabase.execSQL(sql);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	public void updateSort(String sortname)
	{
		try{
			String sql = "UPDATE " + SORT_TABLE_NAME + " SET " + 
							MEMO_SORT_NAME + " = '" + sortname + "' ";
			mSQLiteDatabase.execSQL(sql);
			}catch(Exception ex){
			ex.printStackTrace();
			}
	}
	public void insertSort(String sortname) 
	{
		try{
			ContentValues cv = new ContentValues();
			cv.put(MEMO_SORT_NAME, sortname);
			mSQLiteDatabase.insert(SORT_TABLE_NAME, null, cv);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	public Cursor selectSort()
	{
		try{
			String sql = "SELECT * FROM " + SORT_TABLE_NAME ;
			return mSQLiteDatabase.rawQuery(sql, null);
		}catch(Exception ex){
			ex.printStackTrace();
			return null;
		}
	} 
}
