package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.flamingo;

import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.Utils;
import jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.WeatherActivity;
import jp.primeworks.android.flamingo.Flamingo;
import jp.primeworks.android.flamingo.activity.FlamingoActivity;
import jp.primeworks.android.flamingo.activity.FlamingoFragmentActivity;
import android.content.Intent;

public class WidgetFlamingoActivity extends FlamingoFragmentActivity {

	@Override
	protected void onResume() {
		super.onResume();

//		Flamingo flamingo = new Flamingo(this);
//		if (!flamingo.isValidApplication() && !isAuthorizeError()) {
//			showDialog(FlamingoActivity.DIALOG_AUTHORIZE);
//		}
//
//		else if (flamingo.isValidApplication() || !isAuthorizeError()) {
			Utils.sCanAuto = true;

			Intent resultValue = new Intent();
			resultValue.setClass(this, WeatherActivity.class);
			startActivity(resultValue);

			finish();
//		}
	}
}