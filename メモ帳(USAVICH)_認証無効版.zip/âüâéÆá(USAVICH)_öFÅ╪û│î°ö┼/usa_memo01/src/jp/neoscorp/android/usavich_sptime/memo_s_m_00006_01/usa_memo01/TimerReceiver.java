package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;

import java.util.Timer;
import java.util.TimerTask;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

public class TimerReceiver extends BroadcastReceiver
{
	public static String TIMER_UPDATE_ACTION = "jp.neoscorp.android.action.usa.TIMER_UPDATE_ACTION";
	public static String TIMER_START_ACTION = "jp.neoscorp.android.action.usa.TIMER_START_ACTION";
	public static String TIMER_STOP_ACTION = "jp.neoscorp.android.action.usa.TIMER_STOP_ACTION";
	public static  boolean isStop = false, isStart = false;
	private int timer =  5*60 ;
	private Timer mTimer = null;
	private TimerTask mTimerTask = null;
	private Context mContext;
	private MemoApplication memoApp;
	public TimerReceiver(Context context,MemoApplication memoApp)
	{
		mContext = context;
		this.memoApp = memoApp;
	}
	public void register() 
	{
		IntentFilter filter = new IntentFilter();
		filter.addAction(TIMER_START_ACTION);
		filter.addAction(TIMER_STOP_ACTION);
		mContext.registerReceiver(this, filter);
	}

	public void unRegister() 
	{
		mContext.unregisterReceiver(this);
	}

	public void onReceive(Context context, Intent intent) 
	{
		if (intent.getAction().equals(TIMER_START_ACTION)) 
		{
			if(memoApp != null)
			{
				memoApp.setCheckPasswordStatus(true);
				startTimer();
			}
		}	
		if (intent.getAction().equals(TIMER_STOP_ACTION)) 
		{
			stopTimer();
		}				
	}
	
	private void startTimer() 
	{
		isStart = true;
		memoApp.setIsStartReceiver(true);
		if (mTimer == null) 
		{
			mTimer = new Timer();
		}

		if (mTimerTask == null) 
		{
			mTimerTask = new TimerTask() 
			{
				public void run() 
				{
					do {
						try {
							
							updateCurrentTime();
							Thread.sleep(1000);
						} catch (InterruptedException e) {
						}
					} while (isStop);
				}
			};
		}

		if (mTimer != null && mTimerTask != null)
			mTimer.schedule(mTimerTask, 1000, 1000);
	}

	private void stopTimer() 
	{
		isStart = false;
		memoApp.setIsStartReceiver(false); 
		timer = 5*60;
		if (mTimer != null) 
		{
			mTimer.cancel();
			mTimer = null;
		}

		if (mTimerTask != null) 
		{
			mTimerTask.cancel();
			mTimerTask = null;
		}
	}
	private void updateCurrentTime()
	{
		if(memoApp.isCheckPasswordStatus())
		{
			if(timer > 0)
			{
				timer --;
			}
			else
			{
				memoApp.setCheckPasswordStatus(false);
			}
		}
		else
		{
			stopTimer();
		}
	}
}
