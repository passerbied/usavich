package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.wviews;

import android.util.DisplayMetrics;

public class ScreenConfig {
	static int todayWeather;
	static int todayDscp;
	static int todayParam;
	static int weekDate;
	static int weekDay;
	static int weekWeather;
	static int weekParam;
	public static int citySize;
	public static int dateSize;

	static float mScreenH;
	static float mScreenW;

	private ScreenConfig() {
	}

	public static void init(DisplayMetrics dm) {
		mScreenH = dm.heightPixels;
		mScreenW = dm.widthPixels;

		if (mScreenH >= 700 && mScreenH < 880) {
			setParams(13, 22, 120, 13, 11, 50, 13);
			citySize = 15;
			dateSize = 15;
		} else if (mScreenH >= 880 && mScreenH < 1000) {
			setParams(14, 23, 150, 14, 12, 75, 14);
			citySize = 16;
			dateSize = 16;
		} else if (mScreenH >= 1000) {
			setParams(17, 26, 180, 15, 13, 100, 15);
			citySize = 17;
			dateSize = 17;
		}
	}

	private static void setParams(int todayD, int todayP, int todayW,
			int weekD, int weekDa, int weekW, int weekP) {
		todayDscp = todayD;
		todayParam = todayP;
		todayWeather = todayW;

		weekDate = weekD;
		weekDay = weekDa;
		weekWeather = weekW;
		weekParam = weekP;
	}
}