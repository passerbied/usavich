package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class AlarmDatabaseHelper extends SQLiteOpenHelper 
{
	private String str = "";
	private String table = "";

	public AlarmDatabaseHelper(Context context, String name, CursorFactory factory,
			int version, String str, String table) {
		super(context, name, factory, version);
		this.str = str;
		this.table = table;
	}

	public void onCreate(SQLiteDatabase db) {
		db.execSQL(str);
	}

	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS "+table);
		this.onCreate(db);
	}
}

