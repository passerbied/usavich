package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class MemoSharedPreferences {
	 public static final String SETTING_SHORTCUT = "shortcut";
	 public static final String SHORTCUT_CATEGORY = "shortcutcategory";
	 public static final String COLCK_STATUS = "clockstatus";
	 private static SharedPreferences sp;
	 private Context mContext;
	 public MemoSharedPreferences(Context context)
	 {
		  this.mContext = context;
	 }
	 public  String loadShortCut(String key , String spname)
	 {    	
	     sp = mContext.getSharedPreferences(spname, 0);
	     return sp.getString(key, "");
	 }
	 public void saveSettingSort(String key, String value ,String spname) 
	 {
	  	SharedPreferences sp = mContext.getSharedPreferences(spname, 0);
	  	Editor editor = sp.edit();
	  	editor.putString(key, value);
	  	editor.commit();
	 }
	 public void removeSettingSort(String key , String spname) 
	 {
	  	SharedPreferences sp = mContext.getSharedPreferences(spname, 0);
	  	Editor editor = sp.edit();
	  	editor.remove(key);
	  	editor.commit();
	 }
}
