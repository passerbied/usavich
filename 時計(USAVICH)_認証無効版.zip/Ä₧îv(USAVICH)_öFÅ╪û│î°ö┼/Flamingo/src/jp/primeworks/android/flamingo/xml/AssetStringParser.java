package jp.primeworks.android.flamingo.xml;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import jp.primeworks.android.flamingo.R;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.content.Context;
import android.content.res.Resources;

/**
 * Asset String リソースパーサー.
 * 
 * @author takimura
 *
 */
public class AssetStringParser {

    /**
     * コンテキスト.
     */
    private Context mContext = null;

    /**
     * コンストラクタ.
     * @param context
     */
    public AssetStringParser(Context context) {
        mContext = context;
    }

    /**
     * String リソースの解析.
     * @param fileName
     * @return
     */
    public Map<Integer, Object> parseStringResources(String fileName) throws IOException {

        if(fileName == null) {
            throw new FileNotFoundException("null is not file.");
        }

        InputStream is = null;
        try {
            return parseStringResources(mContext.getAssets().open(fileName));
        } catch (XmlPullParserException e) {
            e.printStackTrace();
            throw new IOException(e);
        } finally {
            if(is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * XmlPullParser から String リソースを解析する.
     * @param parser
     * @return
     * @throws IOException 
     * @throws XmlPullParserException 
     */
    private Map<Integer, Object> parseStringResources(InputStream is) throws XmlPullParserException, IOException {
        Map<Integer, Object> map = new HashMap<Integer, Object>();

        XmlPullParser parser = XmlPullParserHelper.getXmlPullParser(is);

        XmlPullParserHelper helper = new XmlPullParserHelper();
        /*
        while(helper.skipUntilStartTagEvent(parser, "resources"));
        if(!helper.isStartTagEvent(parser, "resources")) {
            throw new IOException("not found resources tag");
        }
        */

        // resource タグ以下の解析
        //
        // string, bool タグのみを現在はサポート
        // <string name="name">value</string>
        // <bool name="name">true</bool>
        String type = null;
        String name = null;
        String value = null;
        int event = parser.next();
        do {
            switch(event) {
            case XmlPullParser.START_TAG:
                type = parser.getName();
                name = parser.getAttributeValue(null, "name");
                break;
            case XmlPullParser.TEXT:
                value = parser.getText();
                break;
            case XmlPullParser.END_TAG:
                if(parser.getName().equals(type)) {
                    if(type.equals("bool")) {
                        map.put(getResourceId(name), Boolean.parseBoolean(value));
                    } else {
                        map.put(getResourceId(name), value);
                    }
                }
                break;
            }
            event = parser.next();
        } while(!helper.isEndTagEvent(parser, "resources"));

        return map;
    }

    public int getResourceId(String name) throws Resources.NotFoundException {
        for(Field field : R.string.class.getFields()) {
            if(field.getName().equals(name)) {
                try {
                    return (Integer)field.get(null);
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }

        for(Field field : R.bool.class.getFields()) {
            if(field.getName().equals(name)) {
                try {
                    return (Integer)field.get(null);
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        
        throw new Resources.NotFoundException("invalid name: " + name);
    }

}
