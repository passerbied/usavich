package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.alarm;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.MainTabActivity;
import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.R;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;

public class Alarm
{
	public static NotificationManager mNotificationManager;
	public static String ALARM_UPDATE_ACTION = "com.taiyo.clock.action.ALARM_UPDATE_ACTION";
	
	public static void addAlarm(  Context mContext,
			               String title,		
			               String hour, 
			               String minutes, 
			               String second, 
			               boolean week[],
			               String onoff, 
			               String soundname, 
			               String soundpath,
			               String vibrate, 
				           String snooze) 
	{
		AlarmDataBaseAdapter  alarmDB = new AlarmDataBaseAdapter(mContext);
		alarmDB.open();
		//曜日設定がなし
		if(getWeekText(week).equals(""))
		{
			alarmDB.insert(title, hour, minutes,  "00", "", getWeekText(week), onoff, soundname, soundpath, vibrate, snooze);
		}
		//曜日設定がある
		else
		{
			String weekValue = "";
			for(int i = 0; i < week.length; i++)
			{
				if(week[i] == true)
				{
					weekValue = weekValue + (i + 1) + ":";
				}
			}
			
			alarmDB.insert(title, hour, minutes,  "00", weekValue.substring(0, weekValue.length() - 1), getWeekText(week), onoff, soundname, soundpath, vibrate, snooze);
		}
		
		alarmDB.close();
	}
	
	public static void editAlarm(  Context mContext,
			                int alarmid,
							String title,		
				            String hour, 
				            String minutes, 
				            String second, 
				            boolean week[],
				            String onoff, 
				            String soundname, 
				            String soundpath,
				            String vibrate, 
					        String snooze) 
	{
		AlarmDataBaseAdapter alarmDB = new AlarmDataBaseAdapter(mContext);
		alarmDB.open();
		
		//曜日設定がなし
		if(getWeekText(week).equals(""))
		{
			alarmDB.update(alarmid, title, hour, minutes, second, "", getWeekText(week), onoff, soundname, soundpath, vibrate, snooze);
		}
		//曜日設定がある
		else
		{
			String weekValue = "";
			for(int i = 0; i < week.length; i++)
			{
				if(week[i] == true)
				{
					weekValue = weekValue + (i + 1) + ":";
				}
			}
		
			alarmDB.update(alarmid, title, hour, minutes, second, weekValue.substring(0, weekValue.length() - 1), getWeekText(week), onoff, soundname, soundpath, vibrate, snooze);
		}
		
		alarmDB.close();
	}
	
	public static void sendAlarm(Context mContext, String alarmId, long nextAlarmTime)
	{
		Intent intent = new Intent();
		intent = new Intent(mContext,AlarmReceiver.class);
		intent.putExtra("alarmid", alarmId);
		PendingIntent pendingIntent;
		AlarmManager alarmManager = (AlarmManager)mContext.getSystemService(Context.ALARM_SERVICE); 
		pendingIntent = PendingIntent.getBroadcast(mContext, Integer.parseInt(alarmId), intent, PendingIntent.FLAG_UPDATE_CURRENT);
		
		if(nextAlarmTime != 0){
			alarmManager.set(AlarmManager.RTC_WAKEUP, nextAlarmTime, pendingIntent);
		}
	}
	
	public static void cancelAlarm(Context mContext, String alarmid)
	{
		Intent intent = new Intent(mContext, AlarmReceiver.class);
		AlarmManager alarmManager = (AlarmManager)mContext.getSystemService(Context.ALARM_SERVICE);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(mContext, Integer.parseInt(alarmid), intent, PendingIntent.FLAG_UPDATE_CURRENT);
		alarmManager.cancel(pendingIntent);
	}
	
	public static long getNextAlarmTime(int hour, int minutes) 
	{
		Calendar c = Calendar.getInstance();
		long nexttime = 0;
		
		try 
		{
			SimpleDateFormat fmt = new SimpleDateFormat();
			fmt.applyPattern("HH:mm");
	        Date d = fmt.parse(hour + ":" + minutes);
	        c.set(Calendar.HOUR_OF_DAY, d.getHours());
	        c.set(Calendar.MINUTE, d.getMinutes());
	        c.set(Calendar.SECOND, 0);
	        c.set(Calendar.MILLISECOND, 0);

	        if(c.getTimeInMillis() > System.currentTimeMillis())
			{
	        	nexttime = c.getTimeInMillis();
			}
	        else
	        {
	        	nexttime = c.getTimeInMillis() + 24 * 60 * 60 * 1000;
	        }
		
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		//String nextAlarmTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(nexttime);
		return nexttime;
	}
	
	public static long getNextAlarmTime(int alarmweek, int delayday, int hour, int minutes) 
	{
		int n = 0;
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        int nowweek = c1.get(Calendar.DAY_OF_WEEK) == 1 ? 7 : (c1.get(Calendar.DAY_OF_WEEK) - 1);
        
		if(alarmweek == nowweek) //指定された曜日が　今日の曜日と同じの場合
		{
			try 
			{
				SimpleDateFormat fmt = new SimpleDateFormat();
				fmt.applyPattern("HH:mm");
		        Date d1 = fmt.parse(hour + ":" + minutes);
		        c1.set(Calendar.HOUR_OF_DAY, d1.getHours());
		        c1.set(Calendar.MINUTE, d1.getMinutes());
		        c1.set(Calendar.SECOND, 0);
		        c1.set(Calendar.MILLISECOND, 0);

		        if(c1.getTimeInMillis() >= System.currentTimeMillis())
				{
					n = 0;
				}
				else
				{
					n = 7;
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		else if(alarmweek < nowweek) 
		{
			n = 7 - nowweek + alarmweek;
		}
		else if(alarmweek > nowweek) 
		{
			n = alarmweek - nowweek;
		}
		
	    try {
	    	SimpleDateFormat fmt = new SimpleDateFormat();
            c2.setTimeInMillis(System.currentTimeMillis() + (n + delayday) * 24 * 60 * 60 * 1000);
	        fmt.applyPattern("HH:mm");
	        Date d2 = fmt.parse(hour + ":" + minutes);
	        c2.set(Calendar.HOUR_OF_DAY, d2.getHours());
	        c2.set(Calendar.MINUTE, d2.getMinutes());
	        c2.set(Calendar.SECOND, 0);
	        c2.set(Calendar.MILLISECOND, 0);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    
	    //String nextAlarmTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(c2.getTimeInMillis());
		return c2.getTimeInMillis();
	}
	
	public static ArrayList<String> getNextAlarmTimeData(Context mContext)
	{
		AlarmDataBaseAdapter alarmDB = new AlarmDataBaseAdapter(mContext);
		alarmDB.open();
		String startHour = "", startMinutes = "", alarmtimemin = "", alarmWeek = "", alarmidmin = "";
		long nextAlarmTime = 0, nextAlarmTimeMin = 0;
		ArrayList<String> list = new ArrayList<String>();
		int alarmid = -1;
        final long now = System.currentTimeMillis();
        nextAlarmTimeMin = Long.MAX_VALUE;
		Cursor mCursor  = alarmDB.selectAllByAlarmIdAsc();
		if(mCursor != null && mCursor.getCount() != 0)
		{
			mCursor.moveToFirst();
			for(int i = 0; i < mCursor.getCount(); i++)
			{
				if(mCursor.getString(mCursor.getColumnIndex(alarmDB.ALARM_ONOFF)).equals("ON"))
				{
					alarmid = mCursor.getInt(mCursor.getColumnIndex(alarmDB.ALARM_ID));
					startHour = mCursor.getString(mCursor.getColumnIndex(alarmDB.ALARM_HOUR));
					startMinutes = mCursor.getString(mCursor.getColumnIndex(alarmDB.ALARM_MINUTES));
					alarmWeek = mCursor.getString(mCursor.getColumnIndex(alarmDB.ALARM_WEEK));
					
					//曜日設定なし
					if(alarmWeek.equals(""))
					{
						nextAlarmTime = getNextAlarmTime(Integer.parseInt(startHour), Integer.parseInt(startMinutes));
						
						if(nextAlarmTime != 0 && nextAlarmTime > now && nextAlarmTime < nextAlarmTimeMin)
						{
							nextAlarmTimeMin = nextAlarmTime;
							alarmidmin = "" + alarmid;
						}
					}
					//曜日設定ある
					else 
					{
						for(int j = 0; j < alarmWeek.split(":").length; j++)
						{
							nextAlarmTime = getNextAlarmTime(Integer.parseInt(alarmWeek.split(":")[j]), 0, Integer.parseInt(startHour), Integer.parseInt(startMinutes));
							
							if(nextAlarmTime != 0 && nextAlarmTime > now && nextAlarmTime < nextAlarmTimeMin)
							{
								nextAlarmTimeMin = nextAlarmTime;
								alarmidmin = "" + alarmid;
							}
						}
					}	
				}
				
				mCursor.moveToNext();
			}
		}
		
		if(!alarmidmin.equals(""))
		{
			mCursor = alarmDB.selectByAlarmId(Integer.parseInt(alarmidmin));
			if(mCursor != null && mCursor.getCount() != 0)
			{
				mCursor.moveToFirst();
				alarmtimemin = mCursor.getString(mCursor.getColumnIndex(alarmDB.ALARM_HOUR)) + ":" +
						       mCursor.getString(mCursor.getColumnIndex(alarmDB.ALARM_MINUTES));
			}
		}
		else
		{
			alarmtimemin = "-- : --";
		}
		
		alarmDB.close();
		mCursor.close();
		mCursor = null;
		list.add(alarmtimemin);
		list.add(alarmidmin);
		list.add(Long.toString(nextAlarmTimeMin));
		
		//Log.v("[NEXT ALARM TIME]", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(nextAlarmTimeMin));
		
		return list;
	}
	
	public static void alarmOffToOn(Context mContext, String alarmid, String hour, String minutes, String week)
	{
		// OFF TO ON
		AlarmDataBaseAdapter mAlarmDB = new AlarmDataBaseAdapter(mContext);
		mAlarmDB.open();
		mAlarmDB.updateAlarmOnOffByAlarmId(alarmid, "ON");
		mAlarmDB.close();
		if(!IsHaveSkipIdNotification(mContext, Integer.parseInt(alarmid)))
		{
			setNotification(mContext);
			ArrayList<String> alarm = getNextAlarmTimeData(mContext); 
	        String alarmId   = alarm.get(1);
	        String nextTime  = alarm.get(2);
			if(alarmid.equals(alarmId))
			{
				sendAlarm(mContext, alarmId, Long.parseLong(nextTime));
			}
		}
	}
		
	public static void alarmOnToOff(Context mContext, String alarmid)
	{
		//ON TO OFF
		AlarmDataBaseAdapter mAlarmDB = new AlarmDataBaseAdapter(mContext);
		mAlarmDB.open();
		String alarmId = "", nextAlarm = "", nextTime = ""; 
        alarmId = getNextAlarmTimeData(mContext).get(1);
		if(alarmid.equals(alarmId))
		{
			cancelAlarm(mContext, alarmId);
			mAlarmDB.updateAlarmOnOffByAlarmId(alarmid, "OFF");
			
			ArrayList<String> alarm = getNextAlarmTimeData(mContext); 
	        nextAlarm = alarm.get(0);
	        alarmId   = alarm.get(1);
	        nextTime  = alarm.get(2);
	        if(!nextAlarm.equals("-- : --"))
	        {
	        	sendAlarm(mContext, alarmId, Long.parseLong(nextTime));
	        }
		}
		else
		{
			mAlarmDB.updateAlarmOnOffByAlarmId(alarmid, "OFF");
		}
		
		if(!IsHaveSkipIdNotification(mContext, Integer.parseInt(alarmid)))
		{
			delNotification(mContext);
		}
		mAlarmDB.close();
	}
	
	public static void alarmOnToOn(Context mContext, String alarmid)
	{
		//ON TO ON
		cancelAlarm(mContext, alarmid);
		AlarmDataBaseAdapter mAlarmDB = new AlarmDataBaseAdapter(mContext);
		mAlarmDB.open();
		String nextAlarmId = "", nextAlarm = "", nextTime = ""; 
		
		ArrayList<String> alarm = getNextAlarmTimeData(mContext); 
        nextAlarm    = alarm.get(0);
        nextAlarmId  = alarm.get(1);
        nextTime     = alarm.get(2);
		if(alarmid.equals(nextAlarmId))
		{
	        if(!nextAlarm.equals("-- : --"))
	        {
	        	sendAlarm(mContext, nextAlarmId, Long.parseLong(nextTime));
	        }
		}
		mAlarmDB.close();
	}
	
	public static void alarmAllOff(Context mContext)
	{
		// ALL TO OFF
		String nextAlarm = getNextAlarmTimeData(mContext).get(0);
		if(!nextAlarm.equals("-- : --"))
			cancelAlarm(mContext, getNextAlarmTimeData(mContext).get(1));
		AlarmDataBaseAdapter mAlarmDB = new AlarmDataBaseAdapter(mContext);
		mAlarmDB.open();
		mAlarmDB.updateAllAlarmToOff();
		mAlarmDB.close();
		delNotification(mContext);		
	}	

    public static  void setNotification(Context mContext)
    {      
    	mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);          
    	Notification n = new Notification();  
    	n.icon = R.drawable.status_icon;                                               
    	n.tickerText = "アラーム起動";                                       
    	n.flags |= Notification.FLAG_NO_CLEAR;
    	n.when = 0;                             

    	Intent intent = new Intent(mContext, MainTabActivity.class);    
    	intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
    	PendingIntent pi = PendingIntent.getActivity(mContext, 0,intent, PendingIntent.FLAG_UPDATE_CURRENT  );   
    	n.setLatestEventInfo(mContext, "ウサビッチ 時計アラーム", "アラーム時刻 " + getNextAlarmTimeData(mContext).get(0),pi);     
    	mNotificationManager.notify(0, n);      
    }
    
    public static void delNotification(Context mContext)
    {
    	mNotificationManager = (NotificationManager)mContext.getSystemService(Context.NOTIFICATION_SERVICE);
    	mNotificationManager.cancel(0);  
    }
	
    public static boolean IsHaveSkipIdNotification(Context mContext, int skipAlarmId)
    {
		boolean bIsHaveNotification = false;
		AlarmDataBaseAdapter alarmDB = new AlarmDataBaseAdapter(mContext);
		alarmDB.open();
		if(alarmDB.selectAllDescSkipAlarmIdOnOff(skipAlarmId, "ON"))
		{
			setNotification(mContext);
			bIsHaveNotification = true;
		}
		alarmDB.close();
		return bIsHaveNotification;
	}
    
	public static String getWeekText(boolean week[])
	{
		String alarmweek = "";
		
		if(week[0]){
			alarmweek = alarmweek + "月  ";
		}
		if(week[1]){
			alarmweek = alarmweek + "火  ";
		}	   
		if(week[2]){
			alarmweek = alarmweek + "水  ";
		}	
		if(week[3]){
			alarmweek = alarmweek + "木  ";
		}	
		if(week[4]){
			alarmweek = alarmweek + "金  ";
		}	
		if(week[5]){
			alarmweek = alarmweek + "土  ";
		}	
		if(week[6]){
			alarmweek = alarmweek + "日  ";
		}
		if(alarmweek.trim().equals("")){
			alarmweek = "";
		}
		
		return alarmweek;
	}
	
}
