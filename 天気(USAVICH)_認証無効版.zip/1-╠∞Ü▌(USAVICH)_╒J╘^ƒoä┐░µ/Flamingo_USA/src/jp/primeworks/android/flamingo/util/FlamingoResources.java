package jp.primeworks.android.flamingo.util;

import java.io.IOException;
import java.util.Map;

import jp.primeworks.android.flamingo.xml.AssetStringParser;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/**
 * Flamingo リソース.
 * 
 * @author takimura
 */
public class FlamingoResources {

    /**
     * リソースオブジェクト.
     */
    private static Resources sResources = null;

    /**
     * コンストラクタ.
     */
    private FlamingoResources() {
    }

    /**
     * Resources オブジェクトの取得.
     * 
     * @param context コンテキスト
     * @return Resources オブジェクト
     */
    public static Resources getResources(Context context) {
        if(sResources == null) {
            try {
                DisplayMetrics metrics = new DisplayMetrics();
                ((WindowManager)(context.getSystemService(Context.WINDOW_SERVICE))).getDefaultDisplay().getMetrics(metrics);

                sResources = new FlamingoResources.AssetResources(context, metrics, context.getResources().getConfiguration());
            } catch (IOException e) {
                sResources = context.getResources();
            }
        }

        return sResources;
    }

    /**
     * Asset リソース.
     * 
     * @author takimura
     *
     */
    private static class AssetResources extends Resources {

        private Map<Integer, Object> mMapResources = null;

        private Resources mResources = null;

        public AssetResources(Context context, DisplayMetrics metrics, Configuration config) throws IOException {
            super(context.getAssets(), metrics, config);

            AssetStringParser parser = new AssetStringParser(context);
            mMapResources = parser.parseStringResources("strings_flamingo.xml");
            mResources = context.getResources();
        }

        @Override
        public String getString(int id) {
            Object value = mMapResources.get(id);
            if(value != null && value instanceof String) {
                return value.toString();
            }
            
            return mResources.getString(id);
        }

        @Override
        public boolean getBoolean(int id) {
            Object value = mMapResources.get(id);
            if(value != null && value instanceof Boolean) {
                return (Boolean)value;
            }

            return mResources.getBoolean(id);
        }

    }

}
