package jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.widget;

import jp.neoscorp.android.usavich_sptime.clock_s_m_00003_01.usa_clock01.utils.Utils;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

public class ClockWidget extends AppWidgetProvider 
{
	
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,int[] appWidgetIds) 
	{
		super.onUpdate(context, appWidgetManager, appWidgetIds);
		context.startService(new Intent(Utils.ACTION_WIDGET_SERVICE));
	}
	
	
	public void onDisabled(Context context) {
		context.stopService(new Intent(Utils.ACTION_WIDGET_SERVICE));
		super.onDisabled(context);
	}
}
