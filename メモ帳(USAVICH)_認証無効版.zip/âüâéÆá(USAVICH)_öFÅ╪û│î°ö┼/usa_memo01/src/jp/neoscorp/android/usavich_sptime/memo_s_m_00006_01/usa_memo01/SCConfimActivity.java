package jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01;


import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.db.MemoDataBaseAdapter;
import jp.neoscorp.android.usavich_sptime.memo_s_m_00006_01.usa_memo01.utils.Util;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class SCConfimActivity extends Activity {

	private Builder builder;
	private MemoApplication memoApp;
	private DialogInterface dialogBtn;
	public static String TIMER_START_ACTION = "jp.neoscorp.android.action.usa.TIMER_START_ACTION";
	private final static String DEFAULT_PASSWORD = "0000";
	private Intent shortcutIntent;
	private EditText currentPwdEdit;
	private String category,memoPassword;
	private boolean singleClickFlag;
	private InputMethodManager imm;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.memo_sc_pwd_confirm);
		memoApp = (MemoApplication) this.getApplication();
		searchMemoPassword();
		imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
		shortcutIntent = getIntent();
		String memoId = shortcutIntent.getStringExtra("memoId");
		category = searchMemoCategory(memoId);
		String pwd = null;
		MemoDataBaseAdapter mda = new MemoDataBaseAdapter(this);
		mda.open();
		Cursor mCursor = mda.selectById(memoId);
		if (mCursor != null && mCursor.getCount() != 0) {
			mCursor.moveToFirst();
			for (int i = 0; i < mCursor.getCount(); i++) {
					
				pwd = mCursor.getString(mCursor
					.getColumnIndex(mda.MEMO_CLOCK_STATUS));
				mCursor.moveToNext();
			}
		}
		mda.close();
		if(null != pwd && null != shortcutIntent)
		{
			if (pwd.equals(Util.HAS_PASSWORD_STATUS) && !TimerReceiver.isStart) {
				checkPasswordDialog(memoId, shortcutIntent.getStringExtra("position"),
						category);
			} else {
//				Intent intent2 = getIntent();
//				intent2.setClass(this, MemoEditActivity.class);
//				intent2.putExtras(getIntent().getExtras());
//				intent2.putExtra("category", category);
//				startActivity(intent2);
//				this.finish();
				Intent intent2 = new Intent(this,
						MemoEditActivity.class);
				intent2.putExtra("memoId", memoId);
				intent2.putExtra("position", shortcutIntent.getStringExtra("position"));
				intent2.putExtra("category", category);
				intent2.putExtra("shortcut", "shortcut");
				startActivity(intent2);
				this.finish();
			}
		}
		else
		{
			Intent intent3 = new Intent(this,MemoActivity.class);
			startActivity(intent3);
			this.finish();
		}
		
	}

	private void checkPasswordDialog(final String memoId,
			final String memoPosition, final String memoCategory) {
		AlertDialog alertdialog = null;
		builder = new android.app.AlertDialog.Builder(this);
		builder.setIcon(null);
		builder.setTitle("パスワード");
		LayoutInflater inflater = (LayoutInflater) getApplicationContext()
				.getSystemService(LAYOUT_INFLATER_SERVICE);
		View view = inflater.inflate(R.layout.memo_shortcut_dialog, null);
		 currentPwdEdit = (EditText) view
				.findViewById(R.id.current_password);
		builder.setOnKeyListener(new DialogInterface.OnKeyListener() {
			
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK)
			    {
					dialog.dismiss();
					SCConfimActivity.this.finish();
			    }
				return false;
			}
		});
		
		builder.setPositiveButton("キャンセル",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						try {
							dialog.dismiss();
							SCConfimActivity.this.finish();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});

		builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				try {
					
					Intent intent = new Intent(SCConfimActivity.this,
							MemoEditActivity.class);
					intent.putExtra("memoId", memoId);
					intent.putExtra("position", memoPosition);
					intent.putExtra("category", memoCategory);
					intent.putExtra("shortcut", "shortcut");
					if (null != memoPassword) {
						if (currentPwdEdit.getText().toString()
								.equals(memoPassword)) {
							if(!TimerReceiver.isStart)
							{
								sendBroadcast(new Intent(TIMER_START_ACTION));
							}
							dialog.dismiss();
							startActivity(intent);
							SCConfimActivity.this.finish();
						}
						else
	          			  {
							Util.ShortcutWrongPassword(SCConfimActivity.this);
							imm.hideSoftInputFromWindow(currentPwdEdit.getWindowToken(), 0);
							dialog.dismiss();
	          			  }
					} else {
					
						if (currentPwdEdit.getText().toString()
								.equals(DEFAULT_PASSWORD)) {
							{
								if(!TimerReceiver.isStart)
								{
									sendBroadcast(new Intent(TIMER_START_ACTION));
								}
								dialog.dismiss();
								startActivity(intent);
								SCConfimActivity.this.finish();
							}
						}
						else
	          			{
	          				Util.ShortcutWrongPassword(SCConfimActivity.this);
	          				imm.hideSoftInputFromWindow(currentPwdEdit.getWindowToken(), 0);
	          				dialog.dismiss();
	          			}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		alertdialog = builder.create();
		alertdialog.setCancelable(false);
		alertdialog.setView(view,0,0,0,0);
		alertdialog.show();
	}
	
	
	private void searchMemoPassword() {
		MemoDataBaseAdapter mda = new MemoDataBaseAdapter(this);
		mda.open();
		Cursor mCursor = mda.selectPassword();
		if (mCursor != null && mCursor.getCount() != 0) {
			mCursor.moveToFirst();
			memoPassword = mCursor.getString(mCursor
					.getColumnIndex(mda.MEMO_PASSWORD));
			memoApp.setMemoPassword(memoPassword);
			mCursor.close();
			mCursor = null;
		}
		mda.close();
	}
	private String searchMemoCategory(String memoId) {
		String category = null;
		MemoDataBaseAdapter mda = new MemoDataBaseAdapter(this);
		mda.open();
		Cursor mCursor = mda.selectById(memoId);
		if (mCursor != null && mCursor.getCount() != 0) {
			mCursor.moveToFirst();
			category = mCursor.getString(mCursor
					.getColumnIndex(mda.MEMO_TYPE));
			mCursor.close();
			mCursor = null;
		}
		mda.close();
		return category;
	}
}
