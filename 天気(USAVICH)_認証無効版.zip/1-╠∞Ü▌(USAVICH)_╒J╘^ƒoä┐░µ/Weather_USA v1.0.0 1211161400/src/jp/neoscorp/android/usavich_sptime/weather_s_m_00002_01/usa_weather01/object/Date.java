package jp.neoscorp.android.usavich_sptime.weather_s_m_00002_01.usa_weather01.object;

public class Date {
	public static final String DATE_TAG = "day";

	public static final String YEAR = "year";
	public static final String MONTH = "month";
	public static final String DATE = "date";
	public static final String DAY = "day";

	private int mYear = -1;
	private int mMonth = -1;
	private int mDate = -1;
	private int mDay = -1;

	public Date() {
	}

	public Date(int year, int month, int date, int day) {
		mYear = year;
		mMonth = month;
		mDate = date;
		mDay = day;
	}

	public int getYear() {
		return mYear;
	}

	public void setYear(int year) {
		mYear = year;
	}

	public int getMonth() {
		return mMonth;
	}

	public void setMonth(int month) {
		mMonth = month;
	}

	public int getDate() {
		return mDate;
	}

	public void setDate(int date) {
		mDate = date;
	}

	public int getDay() {
		return mDay;
	}

	public void setDay(int day) {
		mDay = day;
	}

	public boolean isNull() {
		return ((mYear + mMonth + mDate + mDay) == -4 ? true : false);
	}

	@Override
	public String toString() {
		return "Today is:" + getYear() + "/" + getMonth() + "/" + getDate()
				+ "; Weekday: " + getDay();
	}
}